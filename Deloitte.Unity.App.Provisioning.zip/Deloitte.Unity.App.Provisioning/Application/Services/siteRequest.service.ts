﻿module app.services {
    export class siteRequestService {
        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings
        ) { }

        /**
         * Retrieve a list of site requests
         * @param options Request parameters
         */
        get(options?: IGetSiteRequestOptions): ng.IPromise<IPaginatedResult<ISiteRequestResult>> {
            return this.$http
                .get(this.appSettings.apiUrl + "/siteRequests", { params: options || {} })
                .then(result => result.data);
        }

        getSitesDetails(): ng.IPromise<Array<ISiteRequestResult>> {
            return this
                .get({ skip: 0, take: 1000 })
                .then(result => result.items);
        }

        getSitesDetailsOfUser(userEmail: string): ng.IPromise<Array<ISiteRequestResult>> {
            return this
                .get({ skip: 0, take: 1000, requestor: userEmail })
                .then(result => result.items);
        }

        post(data) {
            return this.$http
                .post(this.appSettings.apiUrl + "/siteRequests", data);
        }
    }

    export interface IGetSiteRequestOptions {
        /**
         * Filters results to requests submitted by the specified email address
         */
        requestor?: string;

        /**
         * Format - int32. Number of records to skip
         */
        skip?: number;


        /**
         * Format - int32. Number of records to retrieve
         */
        take?: number;


        /**
         * Filters the results to requests with the specified status
         */
        status?: string;
    }

    export interface ISiteRequestResult {
        additionalAdmin?: string[];
        description?: string;
        exception?: string;
        firm?: string;
        firmValues?: IFirmValue[];
        step?: ISiteRequestStep[];
        id?: string;
        isSearchable?: boolean;
        language?: string;
        omnitureRsid?: string;
        originalRequestor?: string;
        primaryAdministrator?: string;
        requestor?: string;
        requestedDate?: string;
        siteType?: string;
        size?: number;
        status?: string;
        timeZone?: number;
        title?: string;
        url?: string;
    }

    export interface IFirmValue {
        key?: string;
        value?: string;
    }

    export interface ISiteRequestStep {
        status?: string;
        dateTime?: string;
        remarks?: string;
    }

    function spServiceFactory($rootElement): siteRequestService {
        const inj = $rootElement.injector();
        return inj.instantiate(siteRequestService);
    }
    angular.module("SPApp").factory("siteRequestService", ["$rootElement", $rootElement => spServiceFactory($rootElement)]);
}
