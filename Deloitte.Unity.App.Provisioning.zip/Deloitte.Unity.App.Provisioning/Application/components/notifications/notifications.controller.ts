﻿module app.notificationsComponentController {
    
    export class notificationsComponentController {

        static $inject = ['securityService'];

        firms: any;
        userPermissions: security.shared.IFirmPermissions;
        actives: boolean;
        type: string;

        constructor(
            private securityService: security.shared.securityService
        ){}

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                //this.firms = Object.keys(this.userPermissions).sort();
                this.validatePermissionFirms();
            });

            this.actives = this.type === "active";
        }

        validatePermissionFirms() {

            this.firms = [];
            let tmpFirms = Object.keys(this.userPermissions).sort();

            for (let item of tmpFirms) {
                if ( item === "CH" || item === "UK" ) {
                    this.firms.push(item);
                }
            }
        }
    }
}