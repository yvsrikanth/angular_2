var app;
(function (app) {
    var instantFindEditComponentController;
    (function (instantFindEditComponentController_1) {
        var instantFindEditComponentController = (function () {
            function instantFindEditComponentController($routeParams, $filter, $location, $rootScope, instantFindService, securityService, alertService) {
                this.$routeParams = $routeParams;
                this.$filter = $filter;
                this.$location = $location;
                this.$rootScope = $rootScope;
                this.instantFindService = instantFindService;
                this.securityService = securityService;
                this.alertService = alertService;
                this.types = new Array();
                this.memberFirms = new Array();
                this.currentItem = {};
                this.currentTag = '';
                this.isSubmited = false;
                this.isEditing = false;
                var self = this;
                this.initialize(self);
            }
            instantFindEditComponentController.prototype.initialize = function (self) {
                var currentItemId = self.$routeParams.id;
                this.resultType = self.$location.path().split('/')[2].toLowerCase();
                self.types = [this.$filter('translate')('Web application'),
                    this.$filter('translate')('Mobile application')];
                self.securityService.getUserPermissions().then(function (data) {
                    self.userPermissions = data;
                    for (var firm in self.userPermissions) {
                        if (self.userPermissions[firm].instantFind.update) {
                            self.memberFirms.push(firm);
                        }
                    }
                    if (self.resultType === 'person') {
                        self.instantFindService.getPeopleItem(currentItemId).then(function (data) {
                            self.currentItem = data;
                            self.verifyPermissions(self.currentItem);
                        }, function () {
                            self.showErrorMessage();
                        });
                    }
                    else {
                        self.instantFindService.getResultItem(currentItemId).then(function (data) {
                            self.currentItem = data;
                            self.verifyPermissions(self.currentItem);
                        }, function () {
                            self.showErrorMessage();
                        });
                    }
                });
            };
            instantFindEditComponentController.prototype.verifyPermissions = function (item) {
                var _this = this;
                if (item.isUniversal
                    || (this.resultType !== 'person' && this.userPermissions[item.firm]
                        && this.userPermissions[item.firm.trim()].instantFind.update)
                    || (this.resultType === 'person' && this.userPermissions[item.attributes.externalId.memberFirm]
                        && this.userPermissions[item.attributes.externalId.memberFirm.trim()].instantFind.update)) {
                    setTimeout(function () {
                        _this.$rootScope.$apply();
                    }, 1000);
                }
                else {
                    var firm = this.resultType !== 'person' ? item.firm : item.attributes.externalId.memberFirm;
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: 'Action not allowed',
                        message: 'You do not have permissions to perform this action on '
                            + firm + ' member firm.',
                        dismissText: 'Ok',
                        onDismiss: function () {
                            _this.alertService.close();
                            _this.$location.path('/instantFind');
                        }
                    });
                }
            };
            instantFindEditComponentController.prototype.showErrorMessage = function () {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: 'Item not found',
                    message: 'An error has occurred. The item cannot be found.',
                    dismissText: 'Ok',
                    onDismiss: function () {
                        _this.alertService.close();
                        _this.$location.path('/instantFind');
                    }
                });
            };
            instantFindEditComponentController.prototype.showErrorOnSave = function () {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: 'Error',
                    message: 'An error has occurred. Please try again.',
                    dismissText: 'Ok',
                    onDismiss: function () {
                        _this.alertService.close();
                    }
                });
            };
            instantFindEditComponentController.prototype.save = function (form) {
                var _this = this;
                var self = this;
                this.isSubmited = true;
                self.isEditing = true;
                if (form.$invalid || this.noCheckboxSelected()) {
                    self.isEditing = false;
                    return;
                }
                if (this.currentItem.isUniversal
                    || (this.resultType !== 'person' && this.userPermissions[this.currentItem.firm.trim()].instantFind.update)
                    || (this.resultType === 'person'
                        && this.userPermissions[this.currentItem.attributes.externalId.memberFirm.trim()].instantFind.update)) {
                    if (this.currentItem.attributes != null) {
                        this.instantFindService.updatePeopleItem(this.currentItem).then(function () {
                            self.isEditing = false;
                            self.$location.path('/instantFind');
                        }, function () {
                            self.isEditing = false;
                            self.showErrorOnSave();
                        });
                    }
                    else {
                        this.instantFindService.updateResultItem(this.currentItem).then(function () {
                            self.isEditing = false;
                            self.$location.path('/instantFind');
                        }, function () {
                            self.isEditing = false;
                            self.showErrorOnSave();
                        });
                    }
                }
                else {
                    self.isEditing = false;
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: 'Action not allowed',
                        message: 'You do not have permissions to perform this action on '
                            + this.currentItem.firm + ' member firm.',
                        dismissText: 'Ok',
                        onDismiss: function () {
                            _this.alertService.close();
                        }
                    });
                }
            };
            instantFindEditComponentController.prototype.cancel = function () {
                this.$location.path('/instantFind');
            };
            instantFindEditComponentController.prototype.selectedUniversal = function () {
                if (this.currentItem.isUniversal) {
                    this.currentItem.firm = '';
                }
            };
            instantFindEditComponentController.prototype.isSelectedFirm = function (firm) {
                return firm === this.currentItem.firm;
            };
            instantFindEditComponentController.prototype.shouldDisableTestLink = function () {
                return this.currentItem.data == undefined
                    || this.currentItem.data.url == undefined
                    || this.currentItem.data.url === '';
            };
            instantFindEditComponentController.prototype.formatUrl = function () {
                if (this.shouldDisableTestLink()) {
                    return;
                }
                if (this.currentItem.data.url.indexOf('http://') < 0
                    && this.currentItem.data.url.indexOf('https://') < 0) {
                    return 'http://' + this.currentItem.data.url;
                }
                else {
                    return this.currentItem.data.url;
                }
            };
            instantFindEditComponentController.prototype.isEmptyTag = function () {
                return this.currentTag === '';
            };
            instantFindEditComponentController.prototype.addTag = function () {
                if (this.currentItem.tags == null) {
                    this.currentItem.tags = [];
                }
                if (this.currentItem.tags.indexOf(this.currentTag) < 0) {
                    this.currentItem.tags.push(this.currentTag);
                }
                this.currentTag = '';
            };
            instantFindEditComponentController.prototype.addPeopleTag = function () {
                if (this.currentItem.attributes.tags == null) {
                    this.currentItem.attributes.tags = [];
                }
                if (this.currentItem.attributes.tags.indexOf(this.currentTag) < 0) {
                    this.currentItem.attributes.tags.push(this.currentTag);
                }
                this.currentTag = '';
            };
            instantFindEditComponentController.prototype.removeTag = function (index) {
                this.currentItem.tags.splice(index, 1);
            };
            instantFindEditComponentController.prototype.removePeopleTag = function (index) {
                this.currentItem.attributes.tags.splice(index, 1);
            };
            instantFindEditComponentController.prototype.hasError = function (field) {
                return field.$error.required && this.isSubmited;
            };
            instantFindEditComponentController.prototype.shouldDisableSubmitButton = function (form) {
                if (this.isEditing) {
                    return true;
                }
                if (this.resultType && (this.resultType.toLowerCase() === 'application'
                    || this.resultType.toLowerCase() === 'page')) {
                    return this.isSubmited && (form.$invalid || this.noCheckboxSelected());
                }
                return form.$invalid && this.isSubmited;
            };
            instantFindEditComponentController.prototype.noCheckboxSelected = function () {
                if (this.resultType && this.resultType.toLowerCase() !== 'application'
                    && this.resultType.toLowerCase() !== 'page') {
                    return false;
                }
                return this.isSubmited &&
                    (!this.currentItem.isInstantFind && !this.currentItem.isFrequentLink);
            };
            instantFindEditComponentController.prototype.cleanCustomPosition = function () {
                this.currentItem.attributes.job.instantFind = '';
            };
            return instantFindEditComponentController;
        }());
        instantFindEditComponentController.$inject = ['$routeParams', '$filter', '$location', '$rootScope', 'instantFindService', 'securityService', 'alertService'];
        instantFindEditComponentController_1.instantFindEditComponentController = instantFindEditComponentController;
    })(instantFindEditComponentController = app.instantFindEditComponentController || (app.instantFindEditComponentController = {}));
})(app || (app = {}));
;
//# sourceMappingURL=instantFind.edit.controller.js.map