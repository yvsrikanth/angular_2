var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var leadNews;
                (function (leadNews) {
                    var leadNewsCreateEditComponent = {
                        bindings: {},
                        controller: leadNews.leadNewsCreateEditController,
                        templateUrl: "/Application/components/news/homepageNews/leadNews/leadNews-create-edit/leadNews-create-edit.html",
                        controllerAs: "leadNewsEditor"
                    };
                    angular.module("SPApp").component("leadNewsEditor", leadNewsCreateEditComponent);
                })(leadNews = homepageNews.leadNews || (homepageNews.leadNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-create-edit.component.js.map