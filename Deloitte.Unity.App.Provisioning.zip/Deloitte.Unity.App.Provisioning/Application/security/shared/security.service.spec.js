var app;
(function (app) {
    var security;
    (function (security) {
        var shared;
        (function (shared) {
            describe('securityService', function () {
                var $rootScope;
                var securityService;
                var getUserPromise;
                beforeEach(angular.mock.module('ngMockE2E'));
                beforeEach(angular.mock.module('SPApp'));
                beforeEach(angular.mock.module(function (_$provide_) { return _$provide_.constant('hostDirectory', '/base/'); }));
                beforeEach(inject(function (_$rootScope_, _securityService_, _$httpBackend_) {
                    $rootScope = _$rootScope_;
                    securityService = _securityService_;
                    // Mock all $http requests (**/Application/**/*)
                    _$httpBackend_.whenGET(/.*\/Application\/.*/).passThrough();
                }));
                describe('getUserPermissions', function () {
                    beforeEach(inject(function (_$q_, _UserService_) {
                        // Mock 'UserService.getUser' called inside SecurityService
                        getUserPromise = _$q_.defer();
                        spyOn(_UserService_, 'getUser').and.returnValue(getUserPromise.promise);
                    }));
                    it('should return an empty object because permissions array is empty', inject(function (UserService) {
                        // Prepare
                        getUserPromise.resolve({ permissions: [] });
                        // Do
                        securityService.getUserPermissions().then(function (result) {
                            // Check
                            expect(UserService.getUser).toHaveBeenCalled();
                            expect(result).toEqual({});
                        }, function (error) {
                            console.log(error);
                        });
                        $rootScope.$apply();
                    }));
                    it('should return permissions on US and UK firms because permissions array contains both', inject(function (UserService) {
                        // Prepare
                        getUserPromise.resolve({
                            permissions: [
                                { firm: 'US', key: 'x-x' },
                                { firm: 'UK', key: 'x-x' }
                            ]
                        });
                        // Do
                        securityService.getUserPermissions().then(function (result) {
                            // Check
                            expect(UserService.getUser).toHaveBeenCalled();
                            expect(result['US']).toBeDefined();
                            expect(result['UK']).toBeDefined();
                            expect(Object.keys(result).length).toBe(2);
                        }, function (error) {
                            console.log(error);
                        });
                        $rootScope.$apply();
                    }));
                });
            });
        })(shared = security.shared || (security.shared = {}));
    })(security = app.security || (app.security = {}));
})(app || (app = {}));
//# sourceMappingURL=security.service.spec.js.map