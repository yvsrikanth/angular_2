﻿module app.components.itemsWithOrdinal {


    export interface IItemWithOrdinalOrPosition {
        ordinal?: number;
        position?: number;
    }

// ReSharper disable once InconsistentNaming
    export class RearrangeUtils {

        rearrangeGeneric(changed: any, targetArray: any[], attr: string) {

            if (!changed[attr]) {
                return;
            }

            var originalLength = targetArray.length;
            var originIndex = targetArray.indexOf(changed);
            var stop = changed[attr] - 1;
            var fromUpToDown = originIndex < (changed[attr] - 1);

            var auxIndex = originIndex;
            if (fromUpToDown) {
                do {
                    var indx = (auxIndex === 0 ? originalLength : auxIndex) - 1;
                    targetArray[auxIndex] = targetArray[indx];
                    targetArray[auxIndex][attr] = targetArray[auxIndex][attr]
                        ? (auxIndex + 1)
                        : targetArray[auxIndex][attr];

                    auxIndex--;

                    if (auxIndex < 0)
                        auxIndex = originalLength - 1;

                } while (auxIndex !== stop);
            } else {
                do {
                    var indx = auxIndex === (originalLength - 1) ? 0 : auxIndex + 1;
                    targetArray[auxIndex] = targetArray[indx];
                    targetArray[auxIndex][attr] = targetArray[auxIndex][attr]
                        ? (auxIndex + 1)
                        : targetArray[auxIndex][attr];

                    auxIndex++;

                    if (auxIndex > (originalLength - 1))
                        auxIndex = 0;

                } while (auxIndex !== stop);
            }
            targetArray[changed[attr] - 1] = changed;
        }

        rearrangeOrdinals(changed: IItemWithOrdinalOrPosition, targetArray: IItemWithOrdinalOrPosition[]) {
            this.rearrangeGeneric(changed, targetArray, "ordinal");
        }
        rearrangePositions(changed: IItemWithOrdinalOrPosition, targetArray: IItemWithOrdinalOrPosition[]) {
            this.rearrangeGeneric(changed, targetArray, "position");
        }
    }

    angular.module("SPApp").service('rearrangeUtils', RearrangeUtils);
}