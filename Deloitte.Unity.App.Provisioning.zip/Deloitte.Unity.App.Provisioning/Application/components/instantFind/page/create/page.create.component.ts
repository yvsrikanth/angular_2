﻿module app.directives {

    class pageCreateComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
            this.templateUrl = '/Application/components/instantFind/page/create/page.create.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('pageCreate', new pageCreateComponent());
}