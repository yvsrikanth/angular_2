var app;
(function (app) {
    var directives;
    (function (directives) {
        var pageCreateComponent = (function () {
            function pageCreateComponent() {
                this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
                this.templateUrl = '/Application/components/instantFind/page/create/page.create.html';
                this.controllerAs = "instantFindCtrl";
            }
            return pageCreateComponent;
        }());
        angular.module('SPApp').component('pageCreate', new pageCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=page.create.component.js.map