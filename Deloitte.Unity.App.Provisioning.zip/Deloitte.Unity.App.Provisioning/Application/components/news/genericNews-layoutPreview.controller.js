var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news_1) {
            var genericNewsLayoutPreviewController = (function () {
                function genericNewsLayoutPreviewController() {
                }
                genericNewsLayoutPreviewController.prototype.$onChanges = function (changes) {
                    if (!this.skipSort) {
                        this.news = news_1.genericNewsCreateEditController.processOrdinalSoring(this.news);
                    }
                    if (!this.selectedNew && this.news && this.news.length)
                        this.selectedNew = genericNewsLayoutPreviewController.firtsWithId(this.news);
                    this.setMaxItems();
                };
                genericNewsLayoutPreviewController.firtsWithId = function (news) {
                    if (!news.length)
                        return null;
                    for (var i = 0; i < news.length; i++) {
                        if (news[i].id)
                            return news[i];
                    }
                    return news[0];
                };
                genericNewsLayoutPreviewController.prototype.onSetSelectedPreviewItem = function (item) {
                    this.selectedNew = item;
                };
                genericNewsLayoutPreviewController.prototype.getSrc = function (item, attr) {
                    if (!attr)
                        attr = "image";
                    var attrUrl = attr + "Url";
                    if (item && item.items && item.items.length)
                        return item.items[0][attr] || item.items[0][attrUrl];
                    return null;
                };
                genericNewsLayoutPreviewController.prototype.hasSrc = function (item, attr) {
                    return this.getSrc(item, attr);
                };
                genericNewsLayoutPreviewController.prototype.setMaxItems = function () {
                    if (!angular.isDefined(this.maxItems)) {
                        return;
                    }
                    var newsTemp = [this.maxItems];
                    for (var index = 0; index < this.maxItems; index++) {
                        newsTemp[index] = {};
                    }
                    for (var _i = 0, _a = this.news; _i < _a.length; _i++) {
                        var item = _a[_i];
                        newsTemp[item.ordinal - 1] = item;
                    }
                    this.news = newsTemp;
                };
                return genericNewsLayoutPreviewController;
            }());
            news_1.genericNewsLayoutPreviewController = genericNewsLayoutPreviewController;
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=genericNews-layoutPreview.controller.js.map