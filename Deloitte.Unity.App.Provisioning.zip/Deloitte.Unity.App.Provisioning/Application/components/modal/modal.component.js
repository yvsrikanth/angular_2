var app;
(function (app) {
    var components;
    (function (components) {
        var modal;
        (function (modal) {
            var modalComponent = (function () {
                function modalComponent() {
                    this.bindings = {
                        title: "@",
                        message: "@",
                        onConfirm: "&?",
                        onDismiss: "&?",
                        confirmText: "@?",
                        dismissText: "@",
                        noDismiss: "@?",
                        buttons: "<?",
                        modalId: "@",
                        accent: "@?",
                        size: "@?",
                        submitDisabled: "@?"
                    };
                    this.controller = modal.modalComponentController;
                    this.templateUrl = "/Application/components/modal/modal.component.html";
                    this.controllerAs = "modal";
                    this.transclude = true;
                }
                return modalComponent;
            }());
            modal.modalComponent = modalComponent;
            angular.module("SPApp").component("modal", new modalComponent());
        })(modal = components.modal || (components.modal = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=modal.component.js.map