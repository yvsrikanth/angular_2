var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var headlineNews;
                (function (headlineNews) {
                    var headlineNewsThumbnailsPreviewComponent = {
                        bindings: {
                            news: "<",
                            selectedNew: "=?",
                            skipSort: "<"
                        },
                        controller: news.genericNewsLayoutPreviewController,
                        templateUrl: "/Application/components/news/homepageNews/headlineNews/headlineNews-thumbnailsPreview/headlineNews-thumbnailsPreview.html",
                        controllerAs: "vm"
                    };
                    angular.module("SPApp").component("headlineNewsThumbnailsPreview", headlineNewsThumbnailsPreviewComponent);
                })(headlineNews = homepageNews.headlineNews || (homepageNews.headlineNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-thumbnailsPreview.component.js.map