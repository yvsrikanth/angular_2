var app;
(function (app) {
    var bannerAdNewsPreviewController;
    (function (bannerAdNewsPreviewController) {
        var bannerAdNewsPreviewComponentController = (function () {
            function bannerAdNewsPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
            }
            bannerAdNewsPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setParams();
                this.bannerAdNewsItem = [];
                for (var itemIndex = 0; itemIndex < 6; itemIndex++) {
                    this.bannerAdNewsItem.push(app.components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "BannerAd"));
                }
                this.getDetailsBannerAdNewsItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            bannerAdNewsPreviewComponentController.prototype.moreThanOneWithId = function (news) {
                var idCounter = 0;
                for (var i = 0; i < news.length; i++) {
                    if (news[i].id) {
                        idCounter++;
                    }
                }
                return idCounter !== 1;
            };
            bannerAdNewsPreviewComponentController.prototype.setParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                    this.resourceTitle = "Banner ad preview";
                    this.buttonText = "Edit news";
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                    this.resourceTitle = "Banner ad layout preview";
                    this.buttonText = "Edit layout";
                }
            };
            bannerAdNewsPreviewComponentController.prototype.setItemsOnPositions = function (items) {
                app.components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.bannerAdNewsItem);
            };
            bannerAdNewsPreviewComponentController.prototype.getDetailsBannerAdNewsItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllBannerAdNewsData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestBannerAdNewsItem();
                    return;
                }
            };
            bannerAdNewsPreviewComponentController.prototype.requestAllBannerAdNewsData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "BannerAd", take: 6 }).then(function (result) {
                    _this.setItemsOnPositions(result.items);
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            bannerAdNewsPreviewComponentController.prototype.requestBannerAdNewsItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.setItemsOnPositions([data]);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.setItemsOnPositions([item]);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            bannerAdNewsPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.bannerAdNewsItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.bannerAdNewsItem.length > 1;
            };
            bannerAdNewsPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/homepageNews/bannerAdNews");
            };
            return bannerAdNewsPreviewComponentController;
        }());
        bannerAdNewsPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];
        bannerAdNewsPreviewController.bannerAdNewsPreviewComponentController = bannerAdNewsPreviewComponentController;
    })(bannerAdNewsPreviewController = app.bannerAdNewsPreviewController || (app.bannerAdNewsPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-preview.controller.js.map