var app;
(function (app) {
    var directives;
    (function (directives) {
        var pageTitleComponent = (function () {
            function pageTitleComponent() {
                this.bindings = {
                    pageTitleItem: '@'
                };
                this.controller = app.pageTitleController.pageTitleComponentController;
                this.templateUrl = '/Application/components/news/expandedpageNews/pageTitle/pageTitle.html';
                this.controllerAs = "pageTitle";
            }
            return pageTitleComponent;
        }());
        angular.module('SPApp').component('pageTitle', new pageTitleComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle.component.js.map