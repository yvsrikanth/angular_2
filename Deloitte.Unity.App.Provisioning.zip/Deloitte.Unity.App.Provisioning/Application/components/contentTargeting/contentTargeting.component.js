var app;
(function (app) {
    var directives;
    (function (directives) {
        var contentTargetingComponent = (function () {
            function contentTargetingComponent() {
                this.bindings = {
                    contentTargetItem: '@'
                };
                this.controller = app.contentTargetingController.contentTargetingComponentController;
                this.templateUrl = '/Application/components/contentTargeting/contentTargeting.html';
                this.controllerAs = "contentTarget";
            }
            return contentTargetingComponent;
        }());
        angular.module('SPApp').component('contentTarget', new contentTargetingComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting.component.js.map