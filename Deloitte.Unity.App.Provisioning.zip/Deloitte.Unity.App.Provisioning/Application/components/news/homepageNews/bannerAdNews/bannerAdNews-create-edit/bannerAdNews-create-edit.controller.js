var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var bannerAdNews;
                (function (bannerAdNews) {
                    var bannerAdNewsCreateEditController = (function (_super) {
                        __extends(bannerAdNewsCreateEditController, _super);
                        function bannerAdNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            return _super.call(this, rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "Edit banner ad layout", "Edit banner ad", "Create banner ad", 6, "BannerAd", "/news/homepageNews/bannerAdNews") || this;
                        }
                        return bannerAdNewsCreateEditController;
                    }(news.genericNewsCreateEditController));
                    bannerAdNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    bannerAdNews.bannerAdNewsCreateEditController = bannerAdNewsCreateEditController;
                })(bannerAdNews = homepageNews.bannerAdNews || (homepageNews.bannerAdNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-create-edit.controller.js.map