﻿module app.directives {

    class moduleAccessPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = moduleAccessPreviewController.moduleAccessPreviewComponentController;
            this.templateUrl = "/Application/components/moduleAccess/moduleAccess-preview/moduleAccess-preview.html";
            this.controllerAs = "moduleAccessPreview";
        }

    }

    angular.module("SPApp").component("moduleAccessPreview", new moduleAccessPreviewComponent());

}