var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var bannerAdNews;
                (function (bannerAdNews) {
                    var bannerAdNewsThumbnailsPreviewComponent = {
                        bindings: {
                            news: "<",
                            selectedNew: "=?",
                            showAll: "<",
                            skipSort: "<"
                        },
                        controller: news.genericNewsLayoutPreviewController,
                        templateUrl: "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-thumbnailsPreview/bannerAdNews-thumbnailsPreview.html",
                        controllerAs: "vm"
                    };
                    angular.module("SPApp").component("bannerAdNewsThumbnailsPreview", bannerAdNewsThumbnailsPreviewComponent);
                })(bannerAdNews = homepageNews.bannerAdNews || (homepageNews.bannerAdNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-thumbnailsPreview.component.js.map