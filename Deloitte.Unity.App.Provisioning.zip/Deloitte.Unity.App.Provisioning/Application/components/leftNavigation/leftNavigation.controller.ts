﻿module app.leftNavigationController {

    export class leftNavigationController {
        static $inject = ["$location", "$routeParams", "$route", "$templateCache", "securityService"];
        currentActive: any;
        newsParams: any;
        mergedPermissions: security.shared.IModulePermissions;

        constructor(
            private $location,
            private $routeParams,
            private $route,
            private $templateCache,
            private securityService: security.shared.securityService) {
            this.newsParams = $routeParams.one;
        }

        $onInit() {
            this.mergedPermissions = {};
            this.securityService
                .getMergedPermissions()
                .then(permissions => {
                    this.mergedPermissions = permissions;
                });
        }

        hasAnyPermission(module: string) {
            return this.mergedPermissions[module]
                && (this.mergedPermissions[module].create ||
                    this.mergedPermissions[module].read ||
                    this.mergedPermissions[module].delete ||
                    this.mergedPermissions[module].update ||
                    this.mergedPermissions[module].disable);
        }

        hasAnyHomePageNewsPermission() {
            return this.hasAnyPermission("homePageLeadnews") ||
                this.hasAnyPermission("homeHeadlineNews") ||
                this.hasAnyPermission("homePageBannerAd") ||
                this.hasAnyPermission("homePageHiddenNews");
        }

        hasAnyExtendedPageNewsPermission() {
            return this.hasAnyPermission("extendedPageLeadNews") ||
                this.hasAnyPermission("extendedPageHeadlineNews") ||
                this.hasAnyPermission("extendedPageThumbnailNews") ||
                this.hasAnyPermission("extendedPageExternalResources") ||
                this.hasAnyPermission("extendedPageTitle");
        }

        hasAnyNewsPermission() {
            return this.hasAnyHomePageNewsPermission() ||
                this.hasAnyExtendedPageNewsPermission();
        }

        isActive(viewLocation) {
            let active = false;
            const actualUrl = this.$location.path();
            if (actualUrl.indexOf(viewLocation) >= 0) {
                active = true;
            }
            return active;
        }

        toggle(event: MouseEvent) {

            localStorage.removeItem("accordion-tab-open");
            var index = $(event.currentTarget).index();
            this.currentActive = index + 1;

        }

        goTo(path) {
            var currentPageTemplate = this.$route.current.templateUrl;
            this.$templateCache.remove(currentPageTemplate);
            this.$route.reload();
            this.$location.path(path);
        }
    }
}