﻿module app.components.siteProvisioning {
    export class siteProvisioningCreateController {
        firmData: services.ISiteRequestResult;
        firmFields: services.ISiteRequestFieldResponseItem;
        siteTypes: services.ISiteType[];
        userName: string;

        request: services.ISiteType = {
            additionalAdmin: [''],
            isSearchable: false
        };

        static $inject = ["$location", "$rootScope", "siteRequestService", "siteTypeService", "firmService", "alertService", "siteRequestFieldService"];

        constructor(
            private $location: ng.ILocationService,
            private $rootScope: ng.IScope,
            private siteRequestService: services.siteRequestService,
            private siteTypeService: services.siteTypeService,
            private firmService: services.firmService,
            private alertService: components.alert.alertService,
            private siteRequestFieldService: services.siteRequestFieldService
        ) {

        }

        $onInit() {
            var profile = this.$rootScope["userInfo"].profile;
            this.userName = profile.given_name + ' ' + profile.family_name;

            this.siteTypeService
                .get()
                .then(siteTypes => {
                    this.siteTypes = siteTypes.items;

                    if (siteTypes.items.length)
                        this.request.siteType = siteTypes.items[0].id;
                });
        }

        isTeamSiteAndUk() {
            return this.isSiteType("Team Site") && sessionStorage.getItem("firmKey") === "UK";
        }

        isSiteType(type: string) {
            if (this.siteTypes) {
                for (var i = 0; i < this.siteTypes.length; i++) {
                    var siteType = this.siteTypes[i];
                    if (siteType.id === this.request.siteType) {
                        return siteType.description.toLowerCase() === type.toLowerCase();
                    }
                }
            }
        }

        onSave() {
            this.save();
        }

        save() {
            this.siteRequestService
                .post(this.request)
                .then((): void => {
                    this.$location.path("siteProvisioning");
                })
                .catch(error => {
                    this.alertService.show({
                        buttons: 1,
                        dismissText: "Close",
                        title: "Error",
                        message: (error.data ? error.data.message : null) || "Server error"
                    });
                });
        }

    }
}