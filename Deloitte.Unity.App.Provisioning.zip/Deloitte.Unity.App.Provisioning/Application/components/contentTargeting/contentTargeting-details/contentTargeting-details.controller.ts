﻿module app.contentTargetingDetailsController {
    export class contentTargetingDetailsComponentController {
        static $inject = ['$scope', '$rootScope', 'contentTargetingService', '$http', 'userAttributesService'];

        public url: any;
        public contentTargetingId: any;
        public contentTargetDetail: any;
        public dateForToday: any;

        http: ng.IHttpService;

        constructor(private $scope,
            private $rootScope,
            private contentTargetingService: services.contentTargetingService, $http: ng.IHttpService,
            private userAttributesService: services.userAttributesService) {

            let self = this;
            self.http = $http;
            self.url = window.location.href;
            self.contentTargetingId = self.url.substring(self.url.lastIndexOf('/') + 1);
        }

        $onInit() {
            var rightNow = new Date();
            this.dateForToday = rightNow.toISOString().slice(0, 10);
            this.contentTargetingService.getContentTargetById(this.contentTargetingId)
                .then((response: any) => {
                    this.contentTargetDetail = response;
                    this.userAttributesService.get()
                        .then(response => {
                            let allAttributes = response['items'];
                            for (let rule of this.contentTargetDetail.rules) {
                                let filteredAttribute = allAttributes.filter(a => a.id === rule.attribute)[0];
                                if (filteredAttribute) {
                                    rule.attribute = filteredAttribute.displayName;
                                }
                            }
                        })
                    this.contentTargetDetail.created =
                        new Date(this.contentTargetDetail.created).toISOString().slice(0, 10);
                    
                });
        };

        goToEdit(data) {
            window.location.href = "#/contentTargeting/edit/" + data;
        }
    }

}