﻿module app.security.shared {

    describe('securityService', () => {
        var $rootScope: ng.IScope;
        var securityService: securityService;
        var getUserPromise: ng.IDeferred<services.IUser>;

        beforeEach(angular.mock.module('ngMockE2E'));
        beforeEach(angular.mock.module('SPApp'));
        beforeEach(angular.mock.module(_$provide_ => _$provide_.constant('hostDirectory', '/base/')));
        beforeEach(inject((_$rootScope_, _securityService_, _$httpBackend_) => {
            $rootScope = _$rootScope_;
            securityService = _securityService_;
            // Mock all $http requests (**/Application/**/*)
            _$httpBackend_.whenGET(/.*\/Application\/.*/).passThrough();
        }));


        describe('getUserPermissions', () => {

            beforeEach(inject(function (_$q_, _UserService_) {
                // Mock 'UserService.getUser' called inside SecurityService
                getUserPromise = _$q_.defer();
                spyOn(_UserService_, 'getUser').and.returnValue(getUserPromise.promise);
            }));


            it('should return an empty object because permissions array is empty',
                inject(function (UserService) {
                    // Prepare
                    getUserPromise.resolve(<services.IUser>{ permissions: [] });

                    // Do
                    securityService.getUserPermissions().then(result => {

                        // Check
                        expect(UserService.getUser).toHaveBeenCalled();
                        expect(result).toEqual({});
                    }, error => {
                        console.log(error);
                    });
                    $rootScope.$apply();
                }));

            it('should return permissions on US and UK firms because permissions array contains both',
                inject(function (UserService) {
                    // Prepare
                    getUserPromise.resolve(<services.IUser>{
                        permissions: [
                            { firm: 'US', key: 'x-x' },
                            { firm: 'UK', key: 'x-x' }
                        ]
                    });

                    // Do
                    securityService.getUserPermissions().then(result => {

                        // Check
                        expect(UserService.getUser).toHaveBeenCalled();
                        expect(result['US']).toBeDefined();
                        expect(result['UK']).toBeDefined();
                        expect(Object.keys(result).length).toBe(2);
                    }, error => {
                        console.log(error);
                    });
                    $rootScope.$apply();
                }));
        });
    });
}