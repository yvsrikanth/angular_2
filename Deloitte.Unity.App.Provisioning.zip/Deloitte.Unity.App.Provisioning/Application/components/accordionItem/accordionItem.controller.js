var app;
(function (app) {
    var components;
    (function (components) {
        var accordionItem;
        (function (accordionItem) {
            var accordionItemComponentController = (function () {
                function accordionItemComponentController($scope) {
                    this.$scope = $scope;
                }
                accordionItemComponentController.prototype.$onInit = function () {
                    this.openTab();
                };
                accordionItemComponentController.prototype.closeTabs = function (idTab) {
                    var elements = angular.element(".panel-collapse");
                    for (var i = elements.length - 1; i >= 0; i--) {
                        if (elements[i].id !== ("collapse" + idTab)) {
                            angular.element(elements[i]).removeClass("in");
                            angular.element("a[aria-controls='" + elements[i].id + "']").attr("aria-expanded", "false");
                            angular.element("a[aria-controls='" + elements[i].id + "']").addClass("collapsed");
                        }
                    }
                    localStorage.setItem("accordion-tab-open", idTab);
                };
                accordionItemComponentController.prototype.openTab = function () {
                    if (!angular.isDefined(localStorage.getItem("accordion-tab-open")))
                        return;
                    var tab = localStorage.getItem("accordion-tab-open");
                    if (tab === this.id && !this.expanded) {
                        this.expanded = true;
                    }
                };
                return accordionItemComponentController;
            }());
            accordionItemComponentController.$inject = ["$scope"];
            accordionItem.accordionItemComponentController = accordionItemComponentController;
        })(accordionItem = components.accordionItem || (components.accordionItem = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=accordionItem.controller.js.map