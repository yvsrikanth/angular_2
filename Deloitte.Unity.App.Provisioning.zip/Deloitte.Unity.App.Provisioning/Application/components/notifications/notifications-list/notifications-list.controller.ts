﻿module app.notificationsListComponentController {
    
    export class notificationsListComponentController {
        static $inject = ['newsService', 'securityService', '$location', "alertService"];

        firm: any;
        actives: boolean;

        itemsPerPage: number;
        query: any;
        totalCount: number;
        dateForToday: any;
        userPermissions: security.shared.IModulePermissions;
        permissionName: string = 'systemNotifications';
        notificationItems: any;
        allNotificationItems: any;

        constructor(
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $location,
            private alertService: components.alert.alertService
        ) {}

        $onInit() {

            this.itemsPerPage = 8;
            this.getNotifications();
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
        }

        getNotifications() {

            let self = this;

            self.newsService.getNewsByFirmAndRegion(self.firm,"homepage-notifications", 1000, 0)
                .then(response => {
                    
                    self.allNotificationItems = response.items
                        .filter(n => {
                            return n.firm === self.firm && n.isEnabled === self.actives;
                        })
                        .map(n => {
                            for (var property in n.items[0]) {
                                if (n.items[0].hasOwnProperty(property)) {
                                    n[property] = n.items[0][property];
                                }
                            }
                            return n;
                        });

                    this.query = {
                        skip: 0, take: this.itemsPerPage
                    };
                    self.totalCount = self.allNotificationItems.length;
                    self.getNotificationItems(0, self.itemsPerPage);
                });
        }

        getNotificationItems(skip: number, take: number) {
            this.query = {
                skip: skip, take: take
            };
            this.notificationItems = this.allNotificationItems.slice(skip, skip + take);
        }

        disable(item) {

            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: "Disable an entry ",
                message: "The selected entry will be disabled.",
                dismissText: "Cancel",
                confirmText: "Disable",
                onConfirm: () => {

                    this.onConfirmDisable(item);
                    this.alertService.close();
                }
            });
        }

        onConfirmDisable(item) {

            item.isEnabled = false;
            this.newsService.put(item).then(() => {
                this.notificationItems.splice(this.notificationItems.indexOf(item), 1);
                this.allNotificationItems.splice(this.allNotificationItems.indexOf(item), 1);
                this.totalCount = this.allNotificationItems.length;
                this.getNotificationItems(0, this.itemsPerPage);
                
            });
        }

        delete(item) {

            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: "Delete an entry ",
                message: "The selected entry will be deleted.",
                dismissText: "Cancel",
                confirmText: "Delete",
                onConfirm: () => {

                    this.onConfirmDelete(item);
                    this.alertService.close();
                }
            });
        }

        onConfirmDelete(item) {

            this.newsService.delete(item.id).then(() => {
                this.notificationItems.splice(this.notificationItems.indexOf(item), 1);
                this.allNotificationItems.splice(this.allNotificationItems.indexOf(item), 1);
                this.totalCount = this.allNotificationItems.length;
                this.getNotificationItems(0, this.itemsPerPage);
            });
        }
       
    }
}