﻿module app.directives {

    class hamburgerMenuComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = hamburgerMenuController.hamburgerMenuComponentController;
            this.templateUrl = '/Application/components/hamburgerMenu/hamburgerMenu.html';
            this.controllerAs = "hamburgerMenu";
        }
    }

    angular.module('SPApp').component('hamburgerMenu', new hamburgerMenuComponent());

}