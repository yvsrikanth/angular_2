﻿module app.directives {

    export class leadBannerSpotCreateEditComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<",
                id: "<"
            };

            this.controller = components.news.leadBannerSpotCreateEditComponentController;
            this.templateUrl =
                '/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot-create-edit/leadBannerSpot-create-edit.html';
            this.controllerAs = "leadBannerSpotCreateEdit";
        }
    }

    angular.module('SPApp').component('leadBannerSpotCreateEdit', new leadBannerSpotCreateEditComponent());

}