var app;
(function (app) {
    var dashboardController;
    (function (dashboardController) {
        var operator = ["Less than", "Equal", "Greater than", "Not Equal"];
        var dashboardComponentController = (function () {
            function dashboardComponentController($location, contentTargetingService, securityService, newsService, applicationLauncherService, moduleAccessService, alertService, pageTitleService) {
                this.$location = $location;
                this.contentTargetingService = contentTargetingService;
                this.securityService = securityService;
                this.newsService = newsService;
                this.applicationLauncherService = applicationLauncherService;
                this.moduleAccessService = moduleAccessService;
                this.alertService = alertService;
                this.pageTitleService = pageTitleService;
                this.joinFirm = "Deloitte ";
                this.cardsPermissions = {
                    homePageNews: null,
                    expandedPageNews: null,
                    contentTargeting: null,
                    applicationLauncher: null,
                    hamburgerMenu: null,
                    notifications: null,
                    moduleAccess: null,
                    instantFind: null
                };
                this.errorMsg = '';
                this.showErrorMsg = false;
                this.requestedPermissions = {
                    homepageNews: [
                        "homePageLeadnews",
                        "homeHeadlineNews",
                        "homePageBannerAd",
                        "homePageHiddenNews"
                    ],
                    expandedpageNews: [
                        "extendedPageTitle",
                        "extendedPageLeadNews",
                        "extendedPageHeadlineNews",
                        "extendedPageThumbnailNews",
                        "extendedPageExternalResources"
                    ]
                };
                this.availableNewsTypes = {
                    homepageNews: [
                        {
                            text: "Lead news",
                            value: "leadNews"
                        },
                        {
                            text: "Headline news",
                            value: "headlineNews"
                        },
                        {
                            text: "Banner ad",
                            value: "bannerAdNews"
                        },
                        {
                            text: "Lead banner spot",
                            value: "leadBannerSpot"
                        }
                    ],
                    expandedpageNews: [
                        {
                            text: "Page title",
                            value: "pageTitle"
                        },
                        {
                            text: "Lead news",
                            value: "leadNews"
                        },
                        {
                            text: "Headline news",
                            value: "headlineNews"
                        },
                        {
                            text: "Thumbnail news",
                            value: "thumbnailNews"
                        },
                        {
                            text: "External resource",
                            value: "externalResources"
                        }
                    ],
                    contentTargeting: [
                        {
                            text: "Audiences",
                            value: "contentTargeting"
                        }
                    ]
                };
                this.moduleContentTargeting = "contentTargeting";
                this.moduleSystemNotifications = "systemNotifications";
                this.moduleHamburgerMenu = "hamburgerMenu";
                this.moduleApplicationLauncher = "applicationLauncher";
                this.moduleModuleAccess = "moduleAccess";
                this.moduleInstantFind = "instantFind";
                this.cardsData = {
                    contentTargeting: {},
                    notifications: {}
                };
                this.itemLeadBanner = [];
                this.MAX_ITEMS = 99999999;
            }
            dashboardComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions()
                    .then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.initializeCardPermissions();
                    _this.firmWithPermissions = Object.keys(permissions).sort();
                    _this.setAudiencesByFirm();
                    _this.setCurrentNotifications();
                    _this.getModulesToDisplay();
                    _this.setLeadBannerSpotItem();
                });
            };
            dashboardComponentController.prototype.initializeCardPermissions = function () {
                for (var key in this.cardsPermissions) {
                    this.cardsPermissions[key] = {
                        create: false,
                        edit: false,
                        preview: false
                    };
                }
            };
            dashboardComponentController.prototype.getModulesToDisplay = function () {
                for (var _i = 0, _a = this.firmWithPermissions; _i < _a.length; _i++) {
                    var firm = _a[_i];
                    this.displayModuleContentTargeting(firm);
                    this.displayModuleHomePageNews(firm);
                    this.displayModuleExpandedPageNews(firm);
                    this.displayModuleHeader(firm);
                    this.displayModuleNotifications(firm);
                    this.displayModuleAccess(firm);
                    this.displayModuleInstantFind(firm);
                }
                this.setCardsToDisplay();
            };
            dashboardComponentController.prototype.displayModuleContentTargeting = function (firm) {
                if (this.userPermissions[firm][this.moduleContentTargeting].create) {
                    this.cardsPermissions.contentTargeting.create = true;
                }
                if (this.userPermissions[firm][this.moduleContentTargeting].update) {
                    this.cardsPermissions.contentTargeting.edit = true;
                }
            };
            dashboardComponentController.prototype.displayModuleHomePageNews = function (firm) {
                for (var _i = 0, _a = this.requestedPermissions.homepageNews; _i < _a.length; _i++) {
                    var permission = _a[_i];
                    if (this.userPermissions[firm][permission].create) {
                        this.cardsPermissions.homePageNews.create = true;
                    }
                }
                for (var _b = 0, _c = this.requestedPermissions.homepageNews; _b < _c.length; _b++) {
                    var permission = _c[_b];
                    if (this.userPermissions[firm][permission].update) {
                        this.cardsPermissions.homePageNews.edit = true;
                    }
                }
                for (var _d = 0, _e = this.requestedPermissions.homepageNews; _d < _e.length; _d++) {
                    var permission = _e[_d];
                    if (this.userPermissions[firm][permission].read) {
                        this.cardsPermissions.homePageNews.preview = true;
                    }
                }
            };
            dashboardComponentController.prototype.displayModuleExpandedPageNews = function (firm) {
                for (var _i = 0, _a = this.requestedPermissions.expandedpageNews; _i < _a.length; _i++) {
                    var permission = _a[_i];
                    if (this.userPermissions[firm][permission].create) {
                        this.cardsPermissions.expandedPageNews.create = true;
                    }
                }
                for (var _b = 0, _c = this.requestedPermissions.expandedpageNews; _b < _c.length; _b++) {
                    var permission = _c[_b];
                    if (this.userPermissions[firm][permission].update) {
                        this.cardsPermissions.expandedPageNews.edit = true;
                    }
                }
                for (var _d = 0, _e = this.requestedPermissions.expandedpageNews; _d < _e.length; _d++) {
                    var permission = _e[_d];
                    if (this.userPermissions[firm][permission].read) {
                        this.cardsPermissions.expandedPageNews.preview = true;
                    }
                }
            };
            dashboardComponentController.prototype.displayModuleHeader = function (firm) {
                if (this.userPermissions[firm][this.moduleApplicationLauncher].create) {
                    this.cardsPermissions.applicationLauncher.create = true;
                }
                if (this.userPermissions[firm][this.moduleApplicationLauncher].update) {
                    this.cardsPermissions.applicationLauncher.edit = true;
                }
                if (this.userPermissions[firm][this.moduleApplicationLauncher].read) {
                    this.cardsPermissions.applicationLauncher.preview = true;
                }
                if (this.userPermissions[firm][this.moduleHamburgerMenu].create) {
                    this.cardsPermissions.hamburgerMenu.create = true;
                }
            };
            dashboardComponentController.prototype.displayModuleNotifications = function (firm) {
                if (this.userPermissions[firm][this.moduleSystemNotifications].create) {
                    this.cardsPermissions.notifications.create = true;
                }
                if (this.userPermissions[firm][this.moduleSystemNotifications].update) {
                    this.cardsPermissions.notifications.edit = true;
                }
            };
            dashboardComponentController.prototype.displayModuleAccess = function (firm) {
                if (this.userPermissions[firm][this.moduleModuleAccess].create) {
                    this.cardsPermissions.moduleAccess.create = true;
                }
                if (this.userPermissions[firm][this.moduleModuleAccess].update) {
                    this.cardsPermissions.moduleAccess.edit = true;
                }
                if (this.userPermissions[firm][this.moduleModuleAccess].read) {
                    this.cardsPermissions.moduleAccess.preview = true;
                }
            };
            dashboardComponentController.prototype.displayModuleInstantFind = function (firm) {
                if (this.userPermissions[firm][this.moduleInstantFind].read ||
                    this.userPermissions[firm][this.moduleInstantFind].update) {
                    this.cardsPermissions.instantFind.card = true;
                }
            };
            dashboardComponentController.prototype.setAudiencesByFirm = function () {
                var _this = this;
                if (!angular.isDefined(this.firmWithPermissions)) {
                    return;
                }
                var _loop_1 = function (firm) {
                    this_1.contentTargetingService.getAudiencesByKey(firm)
                        .then(function (res) {
                        _this.cardsData.contentTargeting[firm] = res["totalCount"];
                    });
                };
                var this_1 = this;
                for (var _i = 0, _a = this.firmWithPermissions; _i < _a.length; _i++) {
                    var firm = _a[_i];
                    _loop_1(firm);
                }
            };
            dashboardComponentController.prototype.setCurrentNotifications = function () {
                var _this = this;
                var options = {
                    take: this.MAX_ITEMS
                };
                var activeCounter = 0;
                var disabledCounter = 0;
                for (var _i = 0, _a = this.firmWithPermissions; _i < _a.length; _i++) {
                    var firm = _a[_i];
                    this.newsService.getNewsByFirmAndRegion(firm, "homepage-notifications", options.take)
                        .then(function (res) {
                        for (var _i = 0, _a = res.items; _i < _a.length; _i++) {
                            var notification = _a[_i];
                            if (notification
                                .isEnabled &&
                                (notification.firm === "CH" || notification.firm === "UK"))
                                activeCounter++;
                            if (!notification
                                .isEnabled &&
                                (notification.firm === "CH" || notification.firm === "UK"))
                                disabledCounter++;
                        }
                        _this.cardsData.notifications["active"] = activeCounter;
                        _this.cardsData.notifications["disabled"] = disabledCounter;
                    });
                }
            };
            dashboardComponentController.prototype.setLeadBannerSpotItem = function () {
                var _this = this;
                var _loop_2 = function (firm) {
                    this_2.newsService.get({ firm: firm, region: "hiddenNews" }).then(function (result) {
                        for (var _i = 0, _a = result.items; _i < _a.length; _i++) {
                            var lead = _a[_i];
                            if (lead.isEnabled) {
                                _this.itemLeadBanner[firm] = lead;
                            }
                        }
                    });
                };
                var this_2 = this;
                for (var _i = 0, _a = this.firmWithPermissions; _i < _a.length; _i++) {
                    var firm = _a[_i];
                    _loop_2(firm);
                }
            };
            dashboardComponentController.prototype.setCardsToDisplay = function () {
                for (var key in this.cardsPermissions) {
                    for (var perm in this.cardsPermissions[key]) {
                        if (this.cardsPermissions[key][perm]) {
                            this.cardsPermissions[key].card = true;
                        }
                    }
                }
            };
            dashboardComponentController.prototype.select = function (type, value) {
                this.showErrorMsg = false;
                if (type === "firm" && this.selectedOptions["target"]) {
                    var target = this.selectedOptions["target"];
                    switch (target) {
                        case "contentTargeting":
                            this.setFirmAudiences(value);
                            break;
                        case "notifications":
                            this.setFirmNotifications(value);
                            break;
                        case "applicationLauncher":
                            this.setFirmApplications(value);
                            break;
                        case "moduleAccess":
                            this.setFirmModuleAccess(value);
                            break;
                        default:
                            break;
                    }
                }
                this.selectedOptions[type] = value;
            };
            dashboardComponentController.prototype.getAllowedFirms = function (requestedPermissions, action) {
                var _this = this;
                return this.firmWithPermissions
                    .filter(function (f) {
                    for (var _i = 0, requestedPermissions_1 = requestedPermissions; _i < requestedPermissions_1.length; _i++) {
                        var req = requestedPermissions_1[_i];
                        var permission = _this.userPermissions[f][req];
                        if (action === "edit") {
                            action = "update";
                        }
                        if (action === "preview") {
                            action = "read";
                        }
                        if (permission && permission[action]) {
                            return true;
                        }
                    }
                })
                    .map(function (f) {
                    return {
                        text: _this.joinFirm + " " + f,
                        value: f
                    };
                });
            };
            dashboardComponentController.prototype.setFirmAudiences = function (firm) {
                var _this = this;
                this.contentTargetingService.getAudiencesByKey(firm)
                    .then(function (audiences) {
                    _this.firmAudiences = audiences["items"];
                });
            };
            dashboardComponentController.prototype.setFirmModuleAccess = function (firm) {
                var _this = this;
                this.moduleAccessService.getModuleAccess(0, this.MAX_ITEMS, firm)
                    .then(function (response) {
                    _this.moduleAccessByFirm = response["items"];
                });
            };
            dashboardComponentController.prototype.setFirmNotifications = function (firm) {
                var _this = this;
                this.newsService.getNewsByFirmAndRegion(firm, null, this.MAX_ITEMS, 0)
                    .then(function (notifications) {
                    _this.firmNotifications = notifications["items"].map(function (n) {
                        if (n.items.length) {
                            return {
                                name: n.items[0].description,
                                id: n.id
                            };
                        }
                    });
                });
            };
            dashboardComponentController.prototype.setFirmApplications = function (firm) {
                var _this = this;
                this.applicationLauncherService.getPageList(0, this.MAX_ITEMS, firm)
                    .then(function (applications) {
                    _this.firmApplications = applications["items"][0].navigation.appLauncher.map(function (a) {
                        return {
                            name: a.title,
                            id: a.title
                        };
                    });
                });
            };
            dashboardComponentController.prototype.redirectNews = function () {
                var self = this;
                if (!this.selectedOptions) {
                    return;
                }
                try {
                    var path_1;
                    var search_1;
                    var region = this.selectedOptions["region"];
                    var action = this.selectedOptions["action"];
                    var firm = this.selectedOptions["firm"];
                    var newsType = this.selectedOptions["newsType"]["value"];
                    var item = this.itemLeadBanner[firm];
                    if (action === "preview") {
                        if (newsType === "pageTitle" || (newsType === "leadBannerSpot" && !item)) {
                            this.errorMsg = newsType === "pageTitle" ? "Preview is not available for this news type." : "There is not an active lead banner spot to preview.";
                            this.showErrorMsg = true;
                            return;
                        }
                        else {
                            path_1 = (newsType !== "leadBannerSpot") ? "/news/" + region + "/" + newsType + "/preview/all/" + firm : path_1 = "/news/" + region + "/" + newsType + "/preview/" + item.id;
                            this.navigateToLocation(path_1, search_1);
                        }
                    }
                    else if (action === "create" && region === "expandedpageNews" && newsType === "pageTitle") {
                        path_1 = "/news/" + region + "/" + newsType + "/" + action;
                        search_1 = { firm: firm };
                        this.pageTitleService.getPageList(0, 8, firm).then(function (response) {
                            self.validateExpandedpageNewsPageTitle(path_1, search_1, response);
                        });
                    }
                    else if (action === "edit") {
                        if (newsType === 'leadBannerSpot' && !item) {
                            this.errorMsg = "There is not an active lead banner spot to edit.";
                            this.showErrorMsg = true;
                            return;
                        }
                        action = (newsType !== "leadBannerSpot") ? "edit/all" : "edit/" + item.id;
                        path_1 = "/news/" + region + "/" + newsType + "/" + action;
                        if (!firm) {
                            path_1 = "";
                        }
                        search_1 = { firm: firm };
                        if (region === "expandedpageNews" && newsType === "pageTitle") {
                            this.pageTitleService.getPageList(0, 8, firm).then(function (response) {
                                self.validateExpandedpageNewsPageTitleForEdit(path_1, search_1, response);
                            });
                        }
                        else {
                            this.navigateToLocation(path_1, search_1);
                        }
                    }
                    else {
                        path_1 = "/news/" + region + "/" + newsType + "/" + action;
                        if (!firm) {
                            path_1 = "";
                        }
                        search_1 = { firm: firm };
                        this.navigateToLocation(path_1, search_1);
                    }
                }
                catch (error) {
                    $("body").removeClass("modal-open");
                    this.alertService.show({
                        title: "Something went wrong",
                        buttons: app.components.alert.AlertButtons.Accept
                    });
                }
            };
            dashboardComponentController.prototype.navigateToLocation = function (path, search) {
                $("body").removeClass("modal-open");
                if (!search) {
                    search = "";
                }
                this.$location.path(path).search(search);
            };
            dashboardComponentController.prototype.validateExpandedpageNewsPageTitle = function (path, search, response) {
                this.pageTitleService.setFirmObj(response.items[0]);
                if (response.items[0].newsPageTitle === "*" || response.items[0].newsPageTitle === "") {
                    this.navigateToLocation(path, search);
                }
                else {
                    this.navigateToLocation(path.replace("create", "edit/all"), search);
                }
            };
            dashboardComponentController.prototype.validateExpandedpageNewsPageTitleForEdit = function (path, search, response) {
                this.pageTitleService.setFirmObj(response.items[0]);
                if (response.items[0].newsPageTitle === "*" || response.items[0].newsPageTitle === "") {
                    this.errorMsg = "Page title does not exists. Create a new one.";
                    this.showErrorMsg = true;
                    return false;
                }
                else {
                    this.navigateToLocation(path, search);
                }
            };
            dashboardComponentController.prototype.redirect = function () {
                if (!this.selectedOptions) {
                    return;
                }
                var path;
                var search;
                try {
                    var target = this.selectedOptions["target"];
                    var action = this.selectedOptions["action"];
                    var firm = this.selectedOptions["firm"];
                    path = "/" + target + "/" + action + "/";
                    switch (this.selectedOptions["target"]) {
                        case "contentTargeting":
                            {
                                if (action === "create") {
                                    path += firm;
                                }
                                else {
                                    var id = this.selectedOptions["audience"]["id"];
                                    path += id;
                                }
                                break;
                            }
                        case "notifications":
                            {
                                if (action === "create") {
                                    path += firm;
                                }
                                else {
                                    var id = this.selectedOptions["notification"]["id"];
                                    path += id;
                                }
                                break;
                            }
                        case "hamburgerMenu":
                            {
                                if (action === "create") {
                                    path += firm + "/new/1";
                                }
                                break;
                            }
                        case "applicationLauncher":
                            {
                                if (action === "create") {
                                    search = { firm: firm };
                                }
                                if (action === "edit") {
                                    var id = this.selectedOptions["application"]["id"];
                                    path += id;
                                    search = { firm: firm };
                                }
                                if (action === "preview") {
                                    var id = this.selectedOptions["application"]["id"];
                                    path += id;
                                }
                                break;
                            }
                        case "moduleAccess":
                            {
                                if (action === "create") {
                                    path += firm;
                                }
                                if (action === "edit") {
                                    var id = this.selectedOptions["permission"]["id"];
                                    path += id + "/" + firm;
                                }
                                if (action === "preview") {
                                    var id = this.selectedOptions["permission"]["id"];
                                    path += id;
                                }
                                break;
                            }
                        default:
                            break;
                    }
                    $("body").removeClass("modal-open");
                    if (!search) {
                        search = "";
                    }
                    this.$location.path(path).search(search);
                }
                catch (error) {
                    $("body").removeClass("modal-open");
                    this.alertService.show({
                        title: "Something went wrong",
                        buttons: app.components.alert.AlertButtons.Accept
                    });
                }
            };
            dashboardComponentController.prototype.createEditPreviewNews = function (region, action, title) {
                this.showErrorMsg = false;
                this.modalTitle = title;
                var requestedPermissions = this.requestedPermissions[region];
                this.currentAvailableNewsTypes = this.availableNewsTypes[region];
                this.selectedOptions = {
                    action: action,
                    region: region,
                    firm: "",
                    newsType: ""
                };
                this.availableFirms = this.getAllowedFirms(requestedPermissions, action);
            };
            dashboardComponentController.prototype.setupModal = function (type, action, title) {
                this.modalTitle = title;
                this.selectedOptions = {
                    action: action,
                    target: type,
                    firm: ""
                };
                switch (type) {
                    case "contentTargeting":
                        this.selectedOptions["audience"] = "";
                        this.availableFirms = this.getAllowedFirms([this.moduleContentTargeting], action);
                        break;
                    case "moduleAccess":
                        this.selectedOptions["permission"] = "";
                        this.availableFirms = this.getAllowedFirms([this.moduleModuleAccess], action);
                        break;
                    case "notifications":
                        this.selectedOptions["notification"] = "";
                        this.availableFirms = this.getAllowedFirms([this.moduleSystemNotifications], action);
                        break;
                    case "applicationLauncher":
                        this.selectedOptions["application"] = "";
                        this.availableFirms = this.getAllowedFirms([this.moduleApplicationLauncher], action);
                        break;
                    case "hamburgerMenu":
                        this.availableFirms = this.getAllowedFirms([this.moduleHamburgerMenu], action);
                        break;
                    default:
                        break;
                }
            };
            dashboardComponentController.prototype.submitDisabled = function (modal) {
                if (typeof this.selectedOptions === "undefined") {
                    return true;
                }
                var firm = this.selectedOptions["firm"];
                if (firm == null || firm === "") {
                    return true;
                }
                switch (modal) {
                    case "newsModal":
                        if (this.selectedOptions["newsType"] == null) {
                            return true;
                        }
                        var newtypetext = this.selectedOptions["newsType"]["text"];
                        return newtypetext == null ||
                            newtypetext === "";
                    case "contentTargeting":
                        if (this.selectedOptions["audience"] == null) {
                            return true;
                        }
                        var audiencedisplayname = this.selectedOptions["audience"]["displayName"];
                        return audiencedisplayname == null ||
                            audiencedisplayname === "";
                    case "notificationsModal":
                        if (this.selectedOptions["notification"] == null) {
                            return true;
                        }
                        var notificationName = this.selectedOptions["notification"]["name"];
                        return notificationName == null ||
                            notificationName === "";
                    case "applicationModal":
                        if (this.selectedOptions["application"] == null) {
                            return true;
                        }
                        var applicationname = this.selectedOptions["application"]["name"];
                        return applicationname == null ||
                            applicationname === "";
                    case "moduleAccess":
                        if (this.selectedOptions["permission"] === null) {
                            return true;
                        }
                    default:
                        return false;
                }
            };
            return dashboardComponentController;
        }());
        dashboardComponentController.$inject = [
            "$location", "contentTargetingService", "securityService", "newsService", "applicationLauncherService",
            "moduleAccessService", "alertService", "pageTitleService"
        ];
        dashboardController.dashboardComponentController = dashboardComponentController;
    })(dashboardController = app.dashboardController || (app.dashboardController = {}));
})(app || (app = {}));
//# sourceMappingURL=dashboard.controller.js.map