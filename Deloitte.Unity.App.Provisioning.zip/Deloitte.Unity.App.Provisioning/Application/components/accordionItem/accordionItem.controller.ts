﻿module app.components.accordionItem {
    export class accordionItemComponentController {

        static $inject = ["$scope"];

        expanded: boolean;
        id: string;

        constructor(
            private $scope: ng.IScope
        ) {}


        $onInit() {
            this.openTab();
        }

        closeTabs(idTab: string) {

            let elements = angular.element(".panel-collapse");

            for (let i = elements.length - 1; i >= 0; i--) {

                if (elements[i].id !== ("collapse" + idTab)) {
                    angular.element(elements[i]).removeClass("in");
                    angular.element("a[aria-controls='" + elements[i].id + "']").attr("aria-expanded", "false");
                    angular.element("a[aria-controls='" + elements[i].id + "']").addClass("collapsed");
                }

            }

            localStorage.setItem("accordion-tab-open", idTab);
        }

        openTab() {

            if (!angular.isDefined(localStorage.getItem("accordion-tab-open"))) return;

            let tab = localStorage.getItem("accordion-tab-open");
            if (tab === this.id && !this.expanded) {
                this.expanded = true;
            }
        }

    }
}