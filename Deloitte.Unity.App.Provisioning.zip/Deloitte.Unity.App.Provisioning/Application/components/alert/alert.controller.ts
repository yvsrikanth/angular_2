﻿module app.components.alert {
    export class alertComponentController {
        
        options: alert.IAlertOptions;
        
    }
}