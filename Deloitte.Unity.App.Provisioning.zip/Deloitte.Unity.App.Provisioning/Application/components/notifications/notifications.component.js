var app;
(function (app) {
    var directives;
    (function (directives) {
        var notificationsComponent = (function () {
            function notificationsComponent() {
                this.bindings = {
                    notificationsData: '@',
                    type: '@'
                };
                this.controller = app.notificationsComponentController.notificationsComponentController;
                this.templateUrl = '/Application/components/notifications/notifications.html';
                this.controllerAs = "notificationsCtrl";
            }
            return notificationsComponent;
        }());
        angular.module('SPApp').component('systemNotifications', new notificationsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=notifications.component.js.map