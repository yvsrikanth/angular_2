var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedHeadlineNewsComponent = (function () {
            function expandedHeadlineNewsComponent() {
                this.controller = app.components.expandedHeadlineNews.headlineNewsComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews.component.html";
                this.controllerAs = "headlineNews";
            }
            return expandedHeadlineNewsComponent;
        }());
        angular.module("SPApp").component("expandedHeadlineNews", new expandedHeadlineNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews.component.js.map