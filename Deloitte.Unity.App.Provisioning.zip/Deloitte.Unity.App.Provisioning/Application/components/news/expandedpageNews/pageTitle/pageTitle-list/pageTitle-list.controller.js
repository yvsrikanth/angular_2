var app;
(function (app) {
    var pageTitleListController;
    (function (pageTitleListController) {
        var pageTitleListComponentController = (function () {
            function pageTitleListComponentController($scope, $rootScope, contentTargetingService, securityService, $attrs, alertService, pageTitleService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.contentTargetingService = contentTargetingService;
                this.securityService = securityService;
                this.$attrs = $attrs;
                this.alertService = alertService;
                this.pageTitleService = pageTitleService;
                this.displayOneList = [];
                var self = this;
                self.attrs = $attrs;
                self.itemsPerPage = 8;
                self.query = {
                    skip: 0,
                    take: self.itemsPerPage
                };
            }
            pageTitleListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                });
                this.getPageListData(0, this.itemsPerPage);
            };
            pageTitleListComponentController.prototype.getPageListData = function (skip, take) {
                var _this = this;
                var self = this;
                var rightNow = new Date();
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.pageTitleService.getPageList(skip, take, self.firm).then(function (data) {
                    self.pageListItems = data.items;
                    if (self.pageListItems.length > 0) {
                        self.displayOneList = [];
                        self.displayOneList.push(self.pageListItems[0]);
                        _this.isNew = self.displayOneList[0].newsPageTitle ? false : true;
                    }
                });
            };
            pageTitleListComponentController.prototype.deletePageTitle = function (data) {
                var _this = this;
                var self = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: 'Delete an entry',
                    message: 'The selected entry will be deleted. This action cannot be undone',
                    dismissText: 'Cancel',
                    confirmText: 'Delete',
                    onConfirm: function () {
                        data.newsPageTitle = '*';
                        self.pageTitleService.deletePageTitle(data.id, data).then(function () {
                            _this.getPageListData(0, _this.itemsPerPage);
                            _this.alertService.close();
                        }, function (response) {
                            if (response.status === 400) {
                                _this.errorMessage = response.data.message;
                            }
                            else {
                                _this.alertService.show({
                                    buttons: app.components.alert.AlertButtons.Accept,
                                    title: response.statusText,
                                    message: response.data.message,
                                    dismissText: "Ok"
                                });
                            }
                        });
                    }
                });
            };
            pageTitleListComponentController.prototype.gotoPageTitleCreateEdit = function (params) {
                if (params.firm) {
                    this.contentTargetingService.setFirm(params.firm);
                }
                if (params.audienceID) {
                    this.contentTargetingService.setAudienceId(params.audienceID);
                }
            };
            pageTitleListComponentController.prototype.setFirm = function () {
                var self = this;
                this.contentTargetingService.setFirm(self.firm);
            };
            pageTitleListComponentController.prototype.setFirmObj = function (item) {
                this.pageTitleService.setFirmObj(item[0]);
            };
            return pageTitleListComponentController;
        }());
        pageTitleListComponentController.$inject = ['$scope', '$rootScope', 'contentTargetingService', 'securityService', '$attrs', 'alertService', 'pageTitleService'];
        pageTitleListController.pageTitleListComponentController = pageTitleListComponentController;
    })(pageTitleListController = app.pageTitleListController || (app.pageTitleListController = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle-list.controller.js.map