﻿module app.directives {

    class expandedThumbnailNewsPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = expandedThumbnailNewsPreviewController.thumbnailNewsPreviewComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-preview/thumbnailNews-preview.component.html";
            this.controllerAs = "thumbnailPreview";
        }

    }

    angular.module("SPApp").component("expandedThumbnailNewsPreview", new expandedThumbnailNewsPreviewComponent());

}