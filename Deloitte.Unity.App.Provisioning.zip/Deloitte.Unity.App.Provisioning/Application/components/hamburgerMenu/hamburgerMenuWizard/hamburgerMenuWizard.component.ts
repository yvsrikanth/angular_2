﻿module app.directives {
    class hamburgerMenuWizardComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                currentLevel: "=",
                isPreview: "<"
            };
            this.controller = hamburgerMenuWizardController.hamburgerMenuWizardComponentController;
            this.templateUrl = "/Application/components/hamburgerMenu/hamburgerMenuWizard/hamburgerMenuWizard.html";
            this.controllerAs = "hamburgerMenuWizard";
        }
    }

    angular.module("SPApp").component("hamburgerMenuWizard", new hamburgerMenuWizardComponent());

}