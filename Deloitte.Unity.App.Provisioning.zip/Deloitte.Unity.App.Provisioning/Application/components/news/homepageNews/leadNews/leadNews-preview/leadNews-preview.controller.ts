﻿module app.leadNewsPreviewController {

    export class leadNewsPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];

        id: string;
        firm: string;
        edit: boolean;
        leadNewsItem: any[];
        selectedItem: any;
        showTitle: boolean;
        pageTitle: string;
        buttonText: string;
        userPermissions: security.shared.IModulePermissions;


        constructor(private $scope, private $rootScope, private $routeParams, private newsService: services.newsService, private $location, private alertService: components.alert.alertService,
            private securityService: security.shared.securityService) {

        }

        $onInit() {
            this.setLeadNewsParams();
            this.leadNewsItem = [];
            for (var itemIndex = 0; itemIndex < 4; itemIndex++) {
                this.leadNewsItem.push(components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "Carousal"));
            }

            this.getDetailsLeadNewsItem();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setLeadNewsParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
                this.pageTitle = "Lead news preview";
                this.buttonText = "Edit news";
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
                this.pageTitle = "Lead news layout preview";
                this.buttonText = "Edit layout";
            }

            if (angular.isDefined(this.$routeParams.edit)) {
                this.edit = this.$routeParams.edit;
            }
        }

        getDetailsLeadNewsItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllLeadNewsData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestLeadNewsItem();
                return;
            }

        }

        requestAllLeadNewsData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "Carousal", take: 4 }).then(result => {
                this.setItemsOnPositions(result.items);
            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        setItemsOnPositions(items: components.news.INewsArticleData[]) {
            components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.leadNewsItem);
        }

        requestLeadNewsItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.setItemsOnPositions([data]);
                this.setSelectedItem();
            } else {


                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.setItemsOnPositions([item]);
                }, response => {
                    this.redirectToHome(response.statusText);
                });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {

            this.selectedItem = this.leadNewsItem[0];
            if (!angular.isDefined(this.firm)) { this.firm = this.selectedItem.firm; }
            this.showTitle = this.leadNewsItem.length > 1;
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: app.components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/homepageNews/leadNews");
        }

    }
}