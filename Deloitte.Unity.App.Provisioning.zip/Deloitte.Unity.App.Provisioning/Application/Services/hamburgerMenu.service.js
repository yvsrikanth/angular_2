var app;
(function (app) {
    var services;
    (function (services) {
        var hamburgerMenuService = (function () {
            function hamburgerMenuService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
                this.firms = [];
            }
            hamburgerMenuService.prototype.deleteHamburgerMenuItem = function (firmKey, hamburgerMenuItem) {
                var self = this;
                return self.getFirmByKey(firmKey).then(function (result) {
                    var firm = result.items[0];
                    if (firm) {
                        var mainMenu = firm.navigation.mainMenu;
                        for (var index = 0; index < mainMenu.length; index++) {
                            if (mainMenu[index].title === hamburgerMenuItem.title) {
                                mainMenu.splice(index, 1);
                                break;
                            }
                        }
                        firm.navigation.mainMenu = mainMenu;
                        self.saveFirm(firm).then(function () {
                            return firm;
                        });
                    }
                });
            };
            hamburgerMenuService.prototype.getFirm = function (firmKey) {
                var self = this;
                for (var _i = 0, _a = self.firms; _i < _a.length; _i++) {
                    var firm = _a[_i];
                    if (firm.key === firmKey) {
                        return firm.value;
                    }
                }
                return null;
            };
            hamburgerMenuService.prototype.getFirmByKey = function (firmKey) {
                var self = this;
                var promise = this.$http
                    .get(this.appSettings.apiUrl + "/firms/?key=" + firmKey)
                    .then(function (result) { return result.data; });
                self.firms.push({
                    key: firmKey,
                    value: promise
                });
                return promise;
            };
            hamburgerMenuService.prototype.saveFirm = function (data) {
                return this.$http
                    .put(this.appSettings.apiUrl + "/firms/" + data.id, data);
            };
            return hamburgerMenuService;
        }());
        hamburgerMenuService.$inject = ['$http', 'appSettings'];
        services.hamburgerMenuService = hamburgerMenuService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(hamburgerMenuService);
        }
        angular.module("SPApp").factory('hamburgerMenuService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu.service.js.map