﻿module app.components.bannerAdNews {

    export class bannerAdNewsComponentController {

        static $inject = ["$scope", "$rootScope", "$compile", "securityService"];
        userPermissions: security.shared.IFirmPermissions;
        firms: any;

        constructor(private $scope, private $rootScope, private $compile, private securityService: security.shared.securityService) {
        }

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firms = Object.keys(this.userPermissions).sort();
            });
        }
    }

}