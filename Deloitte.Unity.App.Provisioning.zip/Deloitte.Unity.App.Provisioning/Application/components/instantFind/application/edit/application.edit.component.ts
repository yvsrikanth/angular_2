﻿module app.directives {

    class applicationEditComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
            this.templateUrl = '/Application/components/instantFind/application/edit/application.edit.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('applicationEdit', new applicationEditComponent());
}