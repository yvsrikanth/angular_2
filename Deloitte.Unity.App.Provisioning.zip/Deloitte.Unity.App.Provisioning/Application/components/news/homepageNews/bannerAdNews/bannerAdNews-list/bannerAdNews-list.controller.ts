﻿module app.bannerAdNewsListController {

    export class bannerAdNewsListComponentController {

        static $inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];

        firm: string;

        bannerAdItems: any;
        userPermissions: security.shared.IModulePermissions;
        columns: any;

        constructor(
            private $scope,
            private $rootScope,
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $routeParams
        ) {}

        $onInit() {

            this.setColumns();
            this.setMemberFirm();
            this.bannerAdNews();
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
        }

        bannerAdNews() {

             this.newsService.get({ firm: this.firm, region: "BannerAd", take: 6 }).then(result => {
                 this.bannerAdItems = result.items;
             });
        }

        setColumns() {
            this.columns = ["News title", "Audience", "Author", "Updated date"];
        }

        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm)  && !angular.isDefined(this.firm) ) {
                this.firm = this.$routeParams.firm;
            }
        }

    }
}