﻿module app.components.alert {
    var alertComponent = <ng.IComponentOptions>{
        controller: alert.alertComponentController,
        templateUrl: "/Application/components/alert/alert.component.html",
        controllerAs: "alert"
    }
    angular.module("SPApp").component("alertDialog", alertComponent);
}