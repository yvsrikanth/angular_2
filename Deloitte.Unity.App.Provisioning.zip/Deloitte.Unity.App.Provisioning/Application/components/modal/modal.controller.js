var app;
(function (app) {
    var components;
    (function (components) {
        var modal;
        (function (modal) {
            var modalComponentController = (function () {
                function modalComponentController($timeout) {
                    this.$timeout = $timeout;
                }
                modalComponentController.prototype.$onInit = function () {
                    var _this = this;
                    $("#" + this.modalId).on("hidden.bs.modal", function () {
                        if (_this.onDismiss) {
                            _this.$timeout(_this.onDismiss());
                        }
                    });
                };
                modalComponentController.prototype.onClickDismiss = function (modalId) {
                    $("#" + modalId).modal("hide");
                };
                return modalComponentController;
            }());
            modalComponentController.$inject = ["$timeout"];
            modal.modalComponentController = modalComponentController;
        })(modal = components.modal || (components.modal = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=modal.controller.js.map