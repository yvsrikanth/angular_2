﻿module app.components.accordion {
    export class accordionComponent implements ng.IComponentController {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;
        transclude: boolean;

        constructor() {
            this.bindings = {
                accordionId: "@"
            };
            this.controller = accordion.accordionComponentController;
            this.templateUrl = "/Application/components/accordion/accordion.component.html";
            this.controllerAs = "accordion";
            this.transclude = true;
        }
    }
    angular.module("SPApp").component("accordion", new accordionComponent());
}