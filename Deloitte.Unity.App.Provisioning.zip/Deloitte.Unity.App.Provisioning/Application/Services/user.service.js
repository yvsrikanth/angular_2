var app;
(function (app) {
    var services;
    (function (services) {
        var userService = (function () {
            function userService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            userService.prototype.getUser = function (id) {
                return this.$http
                    .get(this.appSettings.apiUrl + "/users/" + (id || "current"))
                    .then(function (response) { return response.data; });
            };
            userService.prototype.getUserPermissions = function (id) {
                return this.$http
                    .get(this.appSettings.apiUrl + ("/users/" + (id || 'current') + "/permissions"))
                    .then(function (response) { return response.data; });
            };
            userService.prototype.getUserList = function (id) {
                return this.$http
                    .get(this.appSettings.apiUrl + "/users/?id=" + id)
                    .then(function (response) { return response.data; });
            };
            return userService;
        }());
        userService.$inject = ["$http", "appSettings"];
        services.userService = userService;
        angular.module("SPApp").service("userService", userService);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=user.service.js.map