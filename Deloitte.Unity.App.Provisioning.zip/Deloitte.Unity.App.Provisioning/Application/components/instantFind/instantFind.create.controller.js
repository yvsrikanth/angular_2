var app;
(function (app) {
    var instantFindCreateComponentController;
    (function (instantFindCreateComponentController_1) {
        var instantFindCreateComponentController = (function () {
            function instantFindCreateComponentController($filter, $location, instantFindService, alertService, securityService) {
                this.$filter = $filter;
                this.$location = $location;
                this.instantFindService = instantFindService;
                this.alertService = alertService;
                this.securityService = securityService;
                this.types = new Array();
                this.memberFirms = new Array();
                this.isSubmited = false;
                this.isCreating = false;
                var self = this;
                var currentType = $location.path().split('/')[2].toLowerCase();
                self.securityService.getUserPermissions().then(function (data) {
                    self.userPermissions = data;
                    self.checkUserPermissions();
                });
                self.types = [this.$filter('translate')('Web application'),
                    this.$filter('translate')('Mobile application')];
                this.currentItem = {
                    data: {
                        subtext: ''
                    },
                    firm: currentType === 'ddt' ? 'US' : '',
                    isUniversal: currentType === 'office',
                    resultType: currentType,
                    requestor: {
                        name: currentType === 'office' || currentType === 'ddt' ? '-' : '',
                        email: currentType === 'office' || currentType === 'ddt' ? '-' : ''
                    },
                    isInstantFind: true,
                    tags: []
                };
                this.currentTag = '';
            }
            instantFindCreateComponentController.prototype.create = function (form) {
                var _this = this;
                var self = this;
                this.isSubmited = true;
                self.isCreating = true;
                if (form.$invalid || this.noCheckboxSelected()) {
                    self.isCreating = false;
                    return;
                }
                if (this.currentItem.isUniversal && this.currentItem.resultType !== 'office') {
                    this.currentItem.firm = 'Universal';
                }
                if (this.currentItem.isUniversal || this.userPermissions[this.currentItem.firm.trim()].instantFind.create) {
                    this.instantFindService.saveResultItem(this.currentItem).then(function () {
                        self.isCreating = false;
                        self.$location.path('/instantFind');
                    }, function () {
                        self.isCreating = false;
                        self.showErrorOnSave();
                    });
                }
                else {
                    self.isCreating = false;
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: 'Action not allowed',
                        message: 'You do not have permissions to perform this action on '
                            + this.currentItem.firm + ' member firm.',
                        dismissText: 'Ok',
                        onDismiss: function () {
                            _this.alertService.close();
                        }
                    });
                }
            };
            instantFindCreateComponentController.prototype.checkUserPermissions = function () {
                var _this = this;
                var count = 0;
                for (var firm in this.userPermissions) {
                    if (this.userPermissions[firm].instantFind.create) {
                        this.memberFirms.push(firm);
                        count++;
                    }
                }
                if (count === 0) {
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: 'Action not allowed',
                        message: 'You do not have permissions to perform this action.',
                        dismissText: 'Ok',
                        onDismiss: function () {
                            _this.alertService.close();
                            _this.$location.path('/instantFind');
                        }
                    });
                }
            };
            instantFindCreateComponentController.prototype.cancel = function () {
                this.$location.path('/instantFind');
            };
            instantFindCreateComponentController.prototype.showErrorOnSave = function () {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: 'Error',
                    message: 'An error has occurred. Please try again.',
                    dismissText: 'Ok',
                    onDismiss: function () {
                        _this.alertService.close();
                    }
                });
            };
            instantFindCreateComponentController.prototype.selectedUniversal = function () {
                if (this.currentItem.isUniversal) {
                    this.currentItem.firm = '';
                }
            };
            instantFindCreateComponentController.prototype.shouldDisableTestLink = function () {
                return this.currentItem.data == undefined
                    || this.currentItem.data.url == undefined
                    || this.currentItem.data.url === '';
            };
            instantFindCreateComponentController.prototype.formatUrl = function () {
                if (this.shouldDisableTestLink()) {
                    return;
                }
                if (this.currentItem.data.url.indexOf('http://') < 0
                    && this.currentItem.data.url.indexOf('https://') < 0) {
                    return 'http://' + this.currentItem.data.url;
                }
                else {
                    return this.currentItem.data.url;
                }
            };
            instantFindCreateComponentController.prototype.isEmptyTag = function () {
                return this.currentTag === '';
            };
            instantFindCreateComponentController.prototype.addTag = function () {
                if (this.currentItem.tags.indexOf(this.currentTag) < 0) {
                    this.currentItem.tags.push(this.currentTag);
                }
                this.currentTag = '';
            };
            instantFindCreateComponentController.prototype.removeTag = function (index) {
                this.currentItem.tags.splice(index, 1);
            };
            instantFindCreateComponentController.prototype.hasError = function (field) {
                return field.$error.required && this.isSubmited;
            };
            instantFindCreateComponentController.prototype.shouldDisableSubmitButton = function (form) {
                if (this.isCreating) {
                    return true;
                }
                if (this.currentItem.resultType === 'application'
                    || this.currentItem.resultType === 'page') {
                    return this.isSubmited && (form.$invalid || this.noCheckboxSelected());
                }
                return form.$invalid && this.isSubmited;
            };
            instantFindCreateComponentController.prototype.noCheckboxSelected = function () {
                if (this.currentItem.resultType !== 'application'
                    && this.currentItem.resultType !== 'page') {
                    return false;
                }
                return this.isSubmited &&
                    (!this.currentItem.isInstantFind && !this.currentItem.isFrequentLink);
            };
            return instantFindCreateComponentController;
        }());
        instantFindCreateComponentController.$inject = ['$filter', '$location', 'instantFindService', 'alertService', 'securityService'];
        instantFindCreateComponentController_1.instantFindCreateComponentController = instantFindCreateComponentController;
    })(instantFindCreateComponentController = app.instantFindCreateComponentController || (app.instantFindCreateComponentController = {}));
})(app || (app = {}));
;
//# sourceMappingURL=instantFind.create.controller.js.map