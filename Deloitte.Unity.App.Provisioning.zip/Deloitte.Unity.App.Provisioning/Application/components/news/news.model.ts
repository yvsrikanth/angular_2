﻿module app.components.news {
    export interface INewsArticleData {
        audiences?: string[];
        firm?: string;
        isEnabled?: boolean;
        items?: INewsArticleDataItem[],
        layout?: string;
        ordinal?: number;
        region?: string;
        priority?: string;
    }

    export interface INewsArticleDataItem {
        content?: string;
        description?: string;
        image?: string;
        imageUrl?: string;
        language?: string;
        thumbnail?: string;
        thumbnailUrl?: string;
        title?: string;
        subtitle?: string;
        thumbnailTitle?: string;
        url?: string;
    }


    export interface INewsArticleResult extends INewsArticleData {
        modified?: string;
        modifiedBy?: string;
        created?: string;
        createdBy?: string;
        id?: string;
    }
}