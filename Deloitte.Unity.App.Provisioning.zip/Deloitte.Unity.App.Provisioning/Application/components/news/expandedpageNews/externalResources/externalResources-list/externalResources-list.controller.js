var app;
(function (app) {
    var expandedExternalResourcesListController;
    (function (expandedExternalResourcesListController) {
        var externalResourcesListComponentController = (function () {
            function externalResourcesListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            externalResourcesListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setMemberFirm();
                this.externalResources();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
                this.setColumns();
            };
            externalResourcesListComponentController.prototype.externalResources = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "external-links", take: 8 }).then(function (result) {
                    _this.externalResourcesItems = result.items;
                });
            };
            externalResourcesListComponentController.prototype.setColumns = function () {
                this.columns = ["Resource name", "Audience", "Author", "Updated date"];
            };
            externalResourcesListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return externalResourcesListComponentController;
        }());
        externalResourcesListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        expandedExternalResourcesListController.externalResourcesListComponentController = externalResourcesListComponentController;
    })(expandedExternalResourcesListController = app.expandedExternalResourcesListController || (app.expandedExternalResourcesListController = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-list.controller.js.map