﻿module app.security.shared {
    export interface IPermissions {
        create: boolean;
        read: boolean;
        update: boolean;
        delete: boolean;
        disable: boolean;
    }

    export interface IModulePermissions {
        [module: string]: IPermissions;
    }

    export interface IFirmPermissions {
        [firm: string]: IModulePermissions;
    }
}