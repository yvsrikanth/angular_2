var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var leadNews;
                (function (leadNews) {
                    var leadNewsCreateEditController = (function (_super) {
                        __extends(leadNewsCreateEditController, _super);
                        function leadNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            return _super.call(this, 
                            // Injected dependencies
                            rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "Edit lead news layout", "Edit lead news", "Create lead news", 4, "Carousal", "/news/homepageNews/leadNews") || this;
                        }
                        leadNewsCreateEditController.prototype.onSave = function (invalid) {
                            this.setItemsToPreview(this.items);
                            if (!this.validateOrdinal(this.previewItems))
                                return;
                            this.save(this.previewItems, null, invalid);
                            //Removed modal to maintain consistency
                            //$("#previewConfirmModal").modal("show");
                        };
                        return leadNewsCreateEditController;
                    }(news.genericNewsCreateEditController));
                    leadNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    leadNews.leadNewsCreateEditController = leadNewsCreateEditController;
                })(leadNews = homepageNews.leadNews || (homepageNews.leadNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-create-edit.controller.js.map