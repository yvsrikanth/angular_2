var app;
(function (app) {
    var components;
    (function (components) {
        var alert;
        (function (alert) {
            var alertComponent = {
                controller: alert.alertComponentController,
                templateUrl: "/Application/components/alert/alert.component.html",
                controllerAs: "alert"
            };
            angular.module("SPApp").component("alertDialog", alertComponent);
        })(alert = components.alert || (components.alert = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=alert.component.js.map