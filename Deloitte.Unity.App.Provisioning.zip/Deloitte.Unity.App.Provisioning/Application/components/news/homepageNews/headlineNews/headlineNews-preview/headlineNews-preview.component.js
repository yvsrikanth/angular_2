var app;
(function (app) {
    var directives;
    (function (directives) {
        var headlineNewsPreviewComponent = (function () {
            function headlineNewsPreviewComponent() {
                this.controller = app.headlineNewsPreviewController.headlineNewsPreviewController;
                this.templateUrl =
                    '/Application/components/news/homepageNews/headlineNews/headlineNews-preview/headlineNews-preview.html';
                this.controllerAs = "headlineNewsPreview";
            }
            return headlineNewsPreviewComponent;
        }());
        directives.headlineNewsPreviewComponent = headlineNewsPreviewComponent;
        angular.module('SPApp').component('headlineNewsPreview', new headlineNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-preview.component.js.map