﻿module app.directives {

    class expandedThumbnailNewsComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.expandedThumbnailNews.thumbnailNewsComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews.component.html";
            this.controllerAs = "thumbnailNews";
        }

    }

    angular.module("SPApp").component("expandedThumbnailNews", new expandedThumbnailNewsComponent());

}