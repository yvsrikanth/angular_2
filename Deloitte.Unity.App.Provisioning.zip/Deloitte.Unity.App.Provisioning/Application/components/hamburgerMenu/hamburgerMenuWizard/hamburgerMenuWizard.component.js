var app;
(function (app) {
    var directives;
    (function (directives) {
        var hamburgerMenuWizardComponent = (function () {
            function hamburgerMenuWizardComponent() {
                this.bindings = {
                    currentLevel: "=",
                    isPreview: "<"
                };
                this.controller = app.hamburgerMenuWizardController.hamburgerMenuWizardComponentController;
                this.templateUrl = "/Application/components/hamburgerMenu/hamburgerMenuWizard/hamburgerMenuWizard.html";
                this.controllerAs = "hamburgerMenuWizard";
            }
            return hamburgerMenuWizardComponent;
        }());
        angular.module("SPApp").component("hamburgerMenuWizard", new hamburgerMenuWizardComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenuWizard.component.js.map