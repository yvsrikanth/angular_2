var app;
(function (app) {
    var directives;
    (function (directives) {
        var ddtEditComponent = (function () {
            function ddtEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/ddt/edit/ddt.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return ddtEditComponent;
        }());
        angular.module('SPApp').component('ddtEdit', new ddtEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=ddt.edit.component.js.map