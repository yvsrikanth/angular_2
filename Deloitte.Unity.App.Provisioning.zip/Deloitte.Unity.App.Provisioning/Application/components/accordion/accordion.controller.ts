﻿module app.components.accordion {
    export class accordionComponentController {


        static $inject = ['$scope'];
        constructor(private $scope: ng.IScope) {
        }

    }
}