var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadNewsComponent = (function () {
            function leadNewsComponent() {
                this.controller = app.components.leadNews.leadNewsComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews.html";
                this.controllerAs = "leadNews";
            }
            return leadNewsComponent;
        }());
        angular.module("SPApp").component("leadNews", new leadNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews.component.js.map