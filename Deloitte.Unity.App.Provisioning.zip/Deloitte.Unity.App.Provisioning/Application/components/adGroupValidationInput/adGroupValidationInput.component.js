var app;
(function (app) {
    var components;
    (function (components) {
        var adGroupValidationInputComponent = (function () {
            function adGroupValidationInputComponent(adGraphService) {
                this.adGraphService = adGraphService;
                this.loadingAd = false;
                this.required = false;
            }
            adGroupValidationInputComponent.prototype.$onInit = function () {
                this.setGroupName();
            };
            adGroupValidationInputComponent.prototype.setGroupName = function () {
                this.temporalGroupName = this.groupName || "";
                this.takedGroupName = this.groupName;
                this.onBlurAdGroup();
            };
            adGroupValidationInputComponent.prototype.$doCheck = function () {
                if (this.groupName !== this.takedGroupName) {
                    this.setGroupName();
                }
            };
            adGroupValidationInputComponent.prototype.onBlurAdGroup = function () {
                var _this = this;
                this.groupName = "";
                this.takedGroupName = this.groupName;
                if (this.temporalGroupName === this.lastAdGroupSearch) {
                    return;
                }
                this.adInputMsg = "";
                this.lastAdGroupSearch = this.temporalGroupName;
                if (!this.temporalGroupName) {
                    return;
                }
                this.loadingAd = true;
                this.adGraphService
                    .getGroups(this.temporalGroupName)
                    .then(function (groups) {
                    _this.loadingAd = false;
                    if (!groups || !groups.length) {
                        _this.adInputMsg = "The AD Group is not valid";
                    }
                    else {
                        _this.groupName = _this.temporalGroupName;
                        _this.takedGroupName = _this.temporalGroupName;
                        if (_this.hamburgerMenuItem !== undefined) {
                            if (!_this.hamburgerMenuItem.hasOwnProperty("groups")) {
                                _this.hamburgerMenuItem.groups = [_this.temporalGroupName];
                            }
                            else {
                                var groups_1 = _this.hamburgerMenuItem.groups.map(function (g) { return g.toLowerCase(); });
                                if (groups_1.indexOf(_this.temporalGroupName.toLowerCase()) === -1)
                                    _this.hamburgerMenuItem.groups.push(_this.temporalGroupName);
                            }
                            _this.temporalGroupName = "";
                        }
                    }
                })
                    .catch(function () {
                    _this.loadingAd = false;
                    _this.adInputMsg = "Could not validate AD Group '" + _this.temporalGroupName + "'. Server error";
                });
            };
            return adGroupValidationInputComponent;
        }());
        adGroupValidationInputComponent.$inject = ["adGraphService"];
        components.adGroupValidationInputComponent = adGroupValidationInputComponent;
        var adGroupValidationInputComponentOptions = {
            bindings: {
                groupName: "=",
                required: "@",
                placeholder: "@",
                inputClass: "@",
                inputId: "@",
                hamburgerMenuItem: "="
            },
            templateUrl: "/Application/components/adGroupValidationInput/adGroupValidationInput.component.html",
            controller: adGroupValidationInputComponent,
            controllerAs: "vm"
        };
        angular.module("SPApp").component("adGroupValidationInput", adGroupValidationInputComponentOptions);
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=adGroupValidationInput.component.js.map