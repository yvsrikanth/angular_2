var app;
(function (app) {
    var headlineNewsPreviewController;
    (function (headlineNewsPreviewController_1) {
        var headlineNewsPreviewController = (function () {
            function headlineNewsPreviewController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
            }
            headlineNewsPreviewController.prototype.$onInit = function () {
                var _this = this;
                this.setParams();
                this.headlineNewsItem = [];
                for (var itemIndex = 0; itemIndex < 8; itemIndex++) {
                    this.headlineNewsItem.push(app.components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "Thumbnail"));
                }
                this.getDetailsHeadlineNewsItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            headlineNewsPreviewController.prototype.setItemsOnPositions = function (items) {
                app.components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.headlineNewsItem);
            };
            headlineNewsPreviewController.prototype.setParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                    this.resourceTitle = "Headline news preview";
                    this.buttonText = "Edit news";
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                    this.resourceTitle = "Headline news layout preview";
                    this.buttonText = "Edit layout";
                }
            };
            headlineNewsPreviewController.prototype.getDetailsHeadlineNewsItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllHeadlineNewsData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestBannerAdNewsItem();
                    return;
                }
            };
            headlineNewsPreviewController.prototype.requestAllHeadlineNewsData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "Thumbnail", take: 8 }).then(function (result) {
                    _this.setItemsOnPositions(result.items);
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            headlineNewsPreviewController.prototype.requestBannerAdNewsItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.setItemsOnPositions([data]);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.setItemsOnPositions([item]);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            headlineNewsPreviewController.prototype.setSelectedItem = function () {
                this.selectedItem = this.headlineNewsItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.headlineNewsItem.length > 1;
            };
            headlineNewsPreviewController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/homepageNews/headlineNews");
            };
            return headlineNewsPreviewController;
        }());
        headlineNewsPreviewController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];
        headlineNewsPreviewController_1.headlineNewsPreviewController = headlineNewsPreviewController;
    })(headlineNewsPreviewController = app.headlineNewsPreviewController || (app.headlineNewsPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-preview.controller.js.map