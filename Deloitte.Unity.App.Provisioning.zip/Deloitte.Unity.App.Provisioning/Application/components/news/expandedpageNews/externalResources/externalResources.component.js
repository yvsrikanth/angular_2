var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedExternalResourcesComponent = (function () {
            function expandedExternalResourcesComponent() {
                this.controller = app.components.expandedExternalResources.externalResourcesComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources.component.html";
                this.controllerAs = "externalResources";
            }
            return expandedExternalResourcesComponent;
        }());
        angular.module("SPApp").component("expandedExternalResources", new expandedExternalResourcesComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources.component.js.map