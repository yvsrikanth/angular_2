var app;
(function (app) {
    var services;
    (function (services) {
        var data = {
            "skip": "0",
            "take": "10"
        };
        var applicationLauncherService = (function () {
            function applicationLauncherService($http, appSettings) {
                this.appSettings = appSettings;
                this.http = $http;
            }
            applicationLauncherService.prototype.deleteApplicationItem = function (newsId, reData) {
                return this.http.put(this.appSettings.apiUrl + "/firms/" + newsId, reData);
            };
            applicationLauncherService.prototype.createEditPageTitle = function (newsId, reData) {
                console.log("Sent request");
                return this.http.put(this.appSettings.apiUrl + "/firms/" + newsId, reData);
            };
            applicationLauncherService.prototype.getPageList = function (skip, take, firm) {
                var configList = {
                    params: {
                        "skip": skip,
                        "take": take,
                        "key": firm
                    }
                };
                return this.http.get(this.appSettings.apiUrl + "/firms", configList).then(function (result) { return result.data; });
            };
            applicationLauncherService.prototype.getSelectedPageTitleData = function (firmId) {
                return this.http.get(this.appSettings.apiUrl + "/firms/" + firmId).then(function (result) { return result.data; });
            };
            applicationLauncherService.prototype.setFirm = function (firm) {
                this.selectedFirm = firm;
            };
            applicationLauncherService.prototype.setFirmObj = function (item) {
                this.selectedFirmObj = item;
            };
            applicationLauncherService.prototype.getFirmObj = function () {
                return this.selectedFirmObj;
            };
            applicationLauncherService.prototype.getFirmName = function () {
                return this.selectedFirm;
            };
            return applicationLauncherService;
        }());
        applicationLauncherService.$inject = ['$http', 'appSettings'];
        services.applicationLauncherService = applicationLauncherService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(applicationLauncherService);
        }
        angular.module("SPApp").factory('applicationLauncherService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher.service.js.map