﻿module app.directives {

    class expandedLeadNewsComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.expandedLeadNews.leadNewsComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews.component.html";
            this.controllerAs = "leadNews";
        }

    }

    angular.module("SPApp").component("expandedLeadNews", new expandedLeadNewsComponent());

}