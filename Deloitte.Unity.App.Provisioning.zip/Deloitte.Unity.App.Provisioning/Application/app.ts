module app {
    export class translateConfig {
        static $inject = ["$translateProvider"];

        constructor($translateProvider) {
            // configures staticFilesLoader
            $translateProvider.useStaticFilesLoader({
                prefix: "/Application/i18n/strings/locale-",
                suffix: ".json"
            });

            // load "en" table on startup
            $translateProvider.preferredLanguage("en");
            $translateProvider.forceAsyncReload(true);

            // Enable escaping of HTML
            $translateProvider.useSanitizeValueStrategy("escape");
        }
    }
    export class httpInterceptorConfig {
        static $inject = ["$httpProvider"];

        constructor($httpProvider) {
            //initialize get if not there
            if (!$httpProvider.defaults.headers.get) {
                $httpProvider.defaults.headers.get = {};
            }

            // Disable IE ajax request caching
            $httpProvider.defaults.headers.get["If-Modified-Since"] = "Mon, 26 Jul 1997 05:00:00 GMT";

            // Extra
            $httpProvider.defaults.headers.get["Cache-Control"] = "no-cache";
            $httpProvider.defaults.headers.get["Pragma"] = "no-cache";

            // Interceptor
            $httpProvider.interceptors.push((appSettings: IAppSettings) => {
                return {
                    request: config => {
                        if (appSettings.subscriptionId)
                            config.headers["Ocp-Apim-Subscription-Key"] = appSettings.subscriptionId;

                        //In development time on localhost uncomment this line and get the token from the generated request on web api page
                        config.headers["Authorization"] = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6InowMzl6ZHNGdWl6cEJmQlZLMVRuMjVRSFlPMCIsImtpZCI6InowMzl6ZHNGdWl6cEJmQlZLMVRuMjVRSFlPMCJ9.eyJhdWQiOiJodHRwczovL2RlbG9pdHRldW5pdHlwb2N1c2VyYXBpLmF6dXJld2Vic2l0ZXMubmV0LyIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzM2ZGE0NWYxLWRkMmMtNGQxZi1hZjEzLTVhYmU0NmI5OTkyMS8iLCJpYXQiOjE0OTUxMjU3NDksIm5iZiI6MTQ5NTEyNTc0OSwiZXhwIjoxNDk1MTI5NjQ5LCJhY3IiOiIxIiwiYWlvIjoiWTJaZ1lIRDV1L3Zwc2YvNy81bExDT1Uxdm9vemI3UjZITnZhSk1qT3BCQXJzR3YxR1RFQSIsImFtciI6WyJ3aWEiXSwiYXBwaWQiOiJmMDJlZDcxNS02NTcyLTRlMjgtODRkNi04OTdjM2U0NjcwYTAiLCJhcHBpZGFjciI6IjEiLCJmYW1pbHlfbmFtZSI6IktvbW1hIiwiZ2l2ZW5fbmFtZSI6IlN1c2htaXRoYSIsImlwYWRkciI6IjEwNC4xODguMTgwLjc0IiwibmFtZSI6IktvbW1hLCBTdXNobWl0aGEgKFVTIC0gSGVybWl0YWdlKSIsIm9pZCI6IjU3NWRhZmVmLWEwMjAtNDJlMC1iODZkLTA2NDY5MjNlNGE3NyIsIm9ucHJlbV9zaWQiOiJTLTEtNS0yMS0yMzg0NDcyNzYtMTA0MDg2MTkyMy0xODUwOTUyNzg4LTE5Mzk5MzgiLCJwbGF0ZiI6IjMiLCJzY3AiOiJ1c2VyX2ltcGVyc29uYXRpb24iLCJzdWIiOiJTTjBQQzdRaEFYSkVfb0pKMzZyMHhuU0Qyd0VWcko3QWREeEN3Q1A4NmlRIiwidGlkIjoiMzZkYTQ1ZjEtZGQyYy00ZDFmLWFmMTMtNWFiZTQ2Yjk5OTIxIiwidW5pcXVlX25hbWUiOiJzdWtvbW1hQGRlbG9pdHRlLmNvbSIsInVwbiI6InN1a29tbWFAZGVsb2l0dGUuY29tIiwidmVyIjoiMS4wIn0.iFfoFFaQb-5qsau4V7p8U2rm6Z_5N1CrvYEAOVndDZUNIh1LbKnA6D5rIVrcV7rpJRRmrRApAfd9cy6WbHEIfd0krt4HhgsR8tCSXL2fvgUaT4v5y1Sq8-9wmniIGbcclG7WvygeaTCXO2ipC8O2lzLZsLfBhevbV5tA8uE_nwACO1GxZigcqPrOr8w9ITh1wpGqdTUUJjG3_wJII6zzf3_0-ozppfMXQlrbOZOYAh5yFezu76FmtLHf2x8Z7OFht-i9TUNNkOThVngi1LDh27pD3K25sC5C1vKh0efLO77cQn-nC0Mw-7GJfCUg1RvvBZmKVQ8dSYgszFd8ir7Xuw";

                        //Also comment the Adal initialization (After routes)
                        //Don't commit those changes

                        return config;
                    },
                    response: response => {
                        return response;
                    }
                };
            });
        }
    }

    angular
        .module("SPApp", [
            "SPApp.headerFooter",
            "ngResource",
            "ngTouch",
            "ngRoute",
            "ngSanitize",
            "ui.grid",
            "ui.grid.pagination",
            "ui.grid.expandable",
            "ui.grid.selection",
            "ui.grid.pinning",
            "ui.grid.resizeColumns", ,
            "ng-file-model",
            "angular.filter",
            "pascalprecht.translate",
            "AdalAngular"
        ])
        .config(translateConfig)
        .config(httpInterceptorConfig)
        .constant("hostDirectory", "/")
        .config(($routeProvider, $locationProvider, hostDirectory, $httpProvider, appSettings, adalAuthenticationServiceProvider) => {
            $routeProvider
                .when("/dashboard", {
                    templateUrl: hostDirectory + "Application/templates/dashboard/dashboardTemplate.html",
                    requireADLogin: true
                })
                .when("/notifications/active", {
                    templateUrl: hostDirectory + "Application/templates/notifications/activeNotificationsTemplate.html",
                    requireADLogin: true
                })
                .when("/notifications/disabled", {
                    templateUrl: hostDirectory + "Application/templates/notifications/disabledNotificationsTemplate.html",
                    requireADLogin: true
                })
                .when("/notifications/create/:firm", {
                    templateUrl: hostDirectory + "Application/templates/notifications/createNotificationTemplate.html",
                    requireADLogin: true
                })
                .when("/notifications/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/notifications/editNotificationTemplate.html",
                    requireADLogin: true
                })
                .when("/contentTargeting", {
                    templateUrl: hostDirectory + "Application/templates/contentTargeting/contentTargetingTemplate.html",
                    requireADLogin: true
                })
                .when("/contentTargeting/view/:id", {
                    templateUrl: hostDirectory + "Application/templates/contentTargeting/contentTargeting-detailsTemplate.html",
                    requireADLogin: true
                })
                .when("/contentTargeting/create/:firm", {
                    templateUrl: hostDirectory + "Application/templates/contentTargeting/contentTargeting-createTemplate.html",
                    requireADLogin: true
                })
                .when("/contentTargeting/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/contentTargeting/contentTargeting-createTemplate.html",
                    requireADLogin: true
                })
                .when("/moduleAccess", {
                    templateUrl: hostDirectory + "Application/templates/moduleAccess/moduleAccessTemplate.html",
                    requireADLogin: true
                })
                .when("/moduleAccess/create/:firm", {
                    templateUrl: hostDirectory + "Application/templates/moduleAccess/moduleAccessCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/moduleAccess/edit/:id/:firm", {
                    templateUrl: hostDirectory + "Application/templates/moduleAccess/moduleAccessCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/moduleAccess/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/moduleAccess/moduleAccessPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadNews", {
                    templateUrl: hostDirectory + "Application/templates/leadNews/leadNewsTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/leadNews/leadNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/leadNews/leadNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/instantFindTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/ddt/create", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/ddt/ddtCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/application/create", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/application/applicationCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/page/create", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/page/pageCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/office/create", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/office/officeCreateTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/ddt/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/ddt/ddtEditTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/application/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/application/applicationEditTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/page/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/page/pageEditTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/office/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/office/officeEditTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/person/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/people/peopleEditTemplate.html",
                    requireADLogin: true
                })
                .when("/instantFind/subissue/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/instantFind/issue/issueEditTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews/create", {
                    templateUrl: hostDirectory + "Application/templates/news/headlineNews/headlineNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews/edit", {
                    templateUrl: hostDirectory + "Application/templates/news/headlineNews/headlineNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/headlineNews/headlineNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews", {
                    templateUrl: hostDirectory + "Application/templates/news/homepageNews/headlineNews.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/homepageNews/headlineNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/headlineNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/news/homepageNews/headlineNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadNews/create", {
                    templateUrl: hostDirectory + "Application/templates/leadNews/leadNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/leadNews/leadNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/bannerAdNews", {
                    templateUrl: hostDirectory + "Application/templates/news/bannerAdNews/bannerAdNewsTemplate.html",
                    requireADLogin: true
                })
                .when("/hamburgerMenu", {
                    templateUrl: hostDirectory + "Application/templates/hamburgerMenu/hamburgerMenuTemplate.html",
                    requireADLogin: true
                })
                .when("/hamburgerMenu/create/:firm/:code/:level", {
                    templateUrl: hostDirectory + "Application/templates/hamburgerMenu/hamburgerMenuCreateEditTemplate.html",
                    requireADLogin: true
                })
                .when("/hamburgerMenu/edit/:firm/:code/:level", {
                    templateUrl: hostDirectory + "Application/templates/hamburgerMenu/hamburgerMenuCreateEditTemplate.html",
                    requireADLogin: true
                })
                .when("/hamburgerMenu/preview/:firm/:code/:level", {
                    templateUrl: hostDirectory + "Application/templates/hamburgerMenu/hamburgerMenuPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/bannerAdNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/news/bannerAdNews/bannerAdNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/bannerAdNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/bannerAdNews/bannerAdNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/bannerAdNews/create", {
                    templateUrl: hostDirectory + "Application/templates/news/bannerAdNews/bannerAdNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/bannerAdNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/bannerAdNews/bannerAdNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadBannerSpot", {
                    templateUrl: hostDirectory + "Application/templates/news/leadBannerSpot/leadBannerSpotTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadBannerSpot/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/leadBannerSpot/leadBannerSpot-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadBannerSpot/create", {
                    templateUrl: hostDirectory + "Application/templates/news/leadBannerSpot/leadBannerSpot-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/homepageNews/leadBannerSpot/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/leadBannerSpot/leadBannerSpot-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/leadNews", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/leadNews/leadNewsTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/leadNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/leadNews/leadNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/leadNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/leadNews/leadNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/pageTitle", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/pageTitle/pageTitleTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/pageTitle/create", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/pageTitle/pageTitle-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/pageTitle/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/pageTitle/pageTitle-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/leadNews/create", {
                    templateUrl: hostDirectory + "Application/templates/expandedLeadNews/leadNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/leadNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/expandedLeadNews/leadNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/thumbnailNews", {
                    templateUrl: hostDirectory + "Application/templates/expandedThumbnailNews/thumbnailNewsTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/thumbnailNews/create", {
                    templateUrl: hostDirectory + "Application/templates/expandedThumbnailNews/thumbnailNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/thumbnailNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/expandedThumbnailNews/thumbnailNewsEditorTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/thumbnailNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/expandedThumbnailNews/thumbnailNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/thumbnailNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/expandedThumbnailNews/thumbnailNewsPreviewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/headlineNews", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/headlineNews/headlineNewsTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/headlineNews/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/headlineNews/headlineNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/headlineNews/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/headlineNews/headlineNews-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/headlineNews/create", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/headlineNews/headlineNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/headlineNews/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/headlineNews/headlineNews-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/externalResources", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/externalResources/externalResourcesTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/externalResources/preview/all/:firm", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/externalResources/externalResources-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/externalResources/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/externalResources/externalResources-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/externalResources/create", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/externalResources/externalResources-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/news/expandedpageNews/externalResources/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/news/expandedpageNews/externalResources/externalResources-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/applicationLauncher", {
                    templateUrl: hostDirectory + "Application/templates/applicationLauncher/applicationLauncherTemplate.html",
                    requireADLogin: true
                })
                .when("/applicationLauncher/preview", {
                    templateUrl: hostDirectory + "Application/templates/applicationLauncher/applicationLauncher-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/applicationLauncher/preview/:id", {
                    templateUrl: hostDirectory + "Application/templates/applicationLauncher/applicationLauncher-previewTemplate.html",
                    requireADLogin: true
                })
                .when("/applicationLauncher/create", {
                    templateUrl: hostDirectory + "Application/templates/applicationLauncher/applicationLauncher-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/applicationLauncher/edit/:id", {
                    templateUrl: hostDirectory + "Application/templates/applicationLauncher/applicationLauncher-create-editTemplate.html",
                    requireADLogin: true
                })
                .when("/siteProvisioning", {
                    templateUrl: hostDirectory + "Application/templates/siteProvisioning/siteProvisioningTemplate.html",
                    requireADLogin: true,
                    hideSidebar: true
                })
                .when("/siteProvisioning/create", {
                    templateUrl: hostDirectory + "Application/templates/siteProvisioning/siteProvisioning-createTemplate.html",
                    requireADLogin: true,
                    hideSidebar: true
                })
                .otherwise({ redirectTo: "/dashboard" });

         /*   adalAuthenticationServiceProvider.init({
                instance: appSettings.adal.instance,
                tenant: appSettings.adal.tenant,
                clientId: appSettings.adal.clientId,
                endpoints: appSettings.adal.aadEndpoints,
                extraQueryParameter: "nux=1&domain_hint=deloitte.com",
                redirectUri: appSettings.adal.redirectUrl
            }, $httpProvider); */
        })
        .run(($rootScope, $anchorScroll) => {
            $rootScope.$on('$routeChangeSuccess', (event, current) => {
                $rootScope.showSidebar = !current.$$route.hideSidebar;
                $anchorScroll('mainView');
            });
        })
        .config($sceDelegateProvider => {
            $sceDelegateProvider.resourceUrlWhitelist([
                // Allow same origin resource loads.
                "self",
                // Allow loading from outer templates domain.
                "http://deloitteunitydevhomepageapp.azurewebsites.net/app/templates/**"
            ]);
        });
}
