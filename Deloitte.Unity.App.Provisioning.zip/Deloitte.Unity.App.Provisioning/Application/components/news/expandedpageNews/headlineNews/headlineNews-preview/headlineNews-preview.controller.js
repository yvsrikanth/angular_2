var app;
(function (app) {
    var expandedHeadlineNewsPreviewController;
    (function (expandedHeadlineNewsPreviewController) {
        var headlineNewsPreviewComponentController = (function () {
            function headlineNewsPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService, firmService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
                this.firmService = firmService;
            }
            headlineNewsPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setHeadLineNewsParams();
                this.headlineNewsItem = [];
                for (var itemIndex = 0; itemIndex < 10; itemIndex++) {
                    this.headlineNewsItem.push(app.components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "headline"));
                }
                this.getDetailsHeadLineNewsItem();
                this.getFirmData();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            headlineNewsPreviewComponentController.prototype.setHeadLineNewsParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                    this.resourceTitle = "Headline news preview";
                    this.buttonText = "Edit news";
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                    this.resourceTitle = "Headline news layout preview";
                    this.buttonText = "Edit layout";
                }
            };
            headlineNewsPreviewComponentController.prototype.setItemsOnPositions = function (items) {
                app.components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.headlineNewsItem);
            };
            headlineNewsPreviewComponentController.prototype.getDetailsHeadLineNewsItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllHeadlineNewsData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestHeadlineNewsItem();
                    return;
                }
            };
            headlineNewsPreviewComponentController.prototype.requestAllHeadlineNewsData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "headline", take: 10 }).then(function (result) {
                    _this.setItemsOnPositions(result.items);
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            headlineNewsPreviewComponentController.prototype.requestHeadlineNewsItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.setItemsOnPositions([data]);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.setItemsOnPositions([item]);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            headlineNewsPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.headlineNewsItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.headlineNewsItem.length > 1;
            };
            headlineNewsPreviewComponentController.prototype.getFirmData = function () {
                var _this = this;
                this.firmService.getFirmByKey(this.firm).then(function (data) {
                    _this.firmData = data.items[0];
                });
            };
            headlineNewsPreviewComponentController.prototype.sortByPosition = function () {
                if (!angular.isObject(this.headlineNewsItem))
                    return;
                this.headlineNewsItem = app.components.news.genericNewsCreateEditController.processOrdinalSoring(this.headlineNewsItem);
            };
            headlineNewsPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/expandedpageNews/headlineNews");
            };
            return headlineNewsPreviewComponentController;
        }());
        headlineNewsPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService", "hamburgerMenuService"];
        expandedHeadlineNewsPreviewController.headlineNewsPreviewComponentController = headlineNewsPreviewComponentController;
    })(expandedHeadlineNewsPreviewController = app.expandedHeadlineNewsPreviewController || (app.expandedHeadlineNewsPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-preview.controller.js.map