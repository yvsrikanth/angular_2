var app;
(function (app) {
    var services;
    (function (services) {
        var siteRequestFieldService = (function () {
            function siteRequestFieldService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            /**
             * Retrieve a list of site requests
             * @param options Request parameters
             */
            siteRequestFieldService.prototype.get = function (options) {
                return this.$http
                    .get(this.appSettings.apiUrl + "/siteRequestFields", { params: options || {} })
                    .then(function (result) { return result.data; });
            };
            return siteRequestFieldService;
        }());
        siteRequestFieldService.$inject = ["$http", "appSettings"];
        services.siteRequestFieldService = siteRequestFieldService;
        function siteRequestFieldServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(siteRequestFieldService);
        }
        angular.module("SPApp").factory("siteRequestFieldService", ["$rootElement", function ($rootElement) { return siteRequestFieldServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=siteRequestField.service.js.map