﻿module app.directives {

    class dashboardComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                contentTargetItem: '@'
            };
            this.controller = dashboardController.dashboardComponentController;
            this.templateUrl = '/Application/components/dashboard/dashboard.html';
            this.controllerAs = "dashboard";
        }
    }

    angular.module('SPApp').component('dashboard', new dashboardComponent());

}