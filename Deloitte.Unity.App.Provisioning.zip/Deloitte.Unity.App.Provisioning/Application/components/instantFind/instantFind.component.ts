﻿module app.directives {

    class instantFindComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindComponentController.instantFindComponentController;
            this.templateUrl = '/Application/components/instantFind/instantFind.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('instantFind', new instantFindComponent());
}