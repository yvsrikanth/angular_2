﻿﻿module app.services {
    export class newsService {

        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings) {
        }

        resourcePath = "/news/";

        /**
         * Retrieve a list of news articles
         * @param options Request parameters
         */
        get(options?: IGetNewsOptions): ng.IPromise<IPaginatedResult<components.news.INewsArticleResult>> {
            return this.$http
                .get<IPaginatedResult<components.news.INewsArticleResult>>(this.appSettings.apiUrl + this.resourcePath, { params: options || {} })
                .then(result => {
                    var queryResult = result.data;

                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }

                    return queryResult;
                });;
        }

        /**
         * Retrieves a single news article by id
         * @param id Unique identifier or key for the news article
         * @param include Requests that optional fields or data be embedded in the response
         */
        getById(id: string, ...include: string[]): ng.IPromise<components.news.INewsArticleResult> {
            var includes = include ? include.join(",") : "";
            return this.$http
                .get(this.appSettings.apiUrl + this.resourcePath + id, { params: { include: includes } })
                .then(result => result.data);
        }

        /**
         * Create a news article
         * @param data Request body
         */
        post(data: components.news.INewsArticleResult): ng.IPromise<components.news.INewsArticleResult> {
            return this.$http
                .post(this.appSettings.apiUrl + this.resourcePath, data)
                .then(result => result.data);
        }

        /**
         * Replaces the attributes in a news article
         * @param data Request body
         */
        put(data: components.news.INewsArticleResult): ng.IPromise<components.news.INewsArticleResult> {
            return this.$http
                .put(this.appSettings.apiUrl + this.resourcePath + data.id, data)
                .then(result => result.data);
        }

        /**
         * Deletes a news article
         * @param id Unique identifier or key for the news article
         */
        delete(id: string): ng.IPromise<components.news.INewsArticleResult> {
            return this.$http
                .delete(this.appSettings.apiUrl + this.resourcePath + id)
                .then(result => result.data);
        }

        save(data: any, isNew: boolean) {
            return isNew ? this.post(data) : this.put(data);
        }

        getNewsByFirmAndRegion(firm: string, region: string, take: number, skip: number = 0) {
            var queryParams = { firm, region, take, skip };
            return this.get(queryParams);
        }

        getRegionList() {
            return this.$http.get("/Application/components/news/jsonDataNewsRegion/newsRegion.json").then(result => result.data);
        }
    }

    /**
     * Request parameters
     */
    export interface IGetNewsOptions {
        /**
         * 'yes' to apply personalization through content targeting, otherwise omit.
         */
        personalize?: string;

        /**
         * Unique key for the firm
         */
        firm?: string;

        /**
         * Requests that optional fields or data be embedded in the response
         */
        include?: string;

        /**
         * Comma delimited list of regions used to filter the news articles to only display items for a purpose
         */
        region?: string;

        /**
         * Format - int32. Number of records to skip
         */
        skip?: number;

        /**
         * Format - int32. Number of records to retrieve
         */
        take?: number;
    }

    function myServiceFactory($rootElement): newsService {
        const inj = $rootElement.injector();
        return inj.instantiate(newsService);
    }
    angular.module("SPApp").factory('newsService',
        ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}
