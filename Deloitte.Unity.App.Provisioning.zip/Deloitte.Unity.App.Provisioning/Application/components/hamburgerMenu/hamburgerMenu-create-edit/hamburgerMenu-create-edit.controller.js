var app;
(function (app) {
    var hamburgerMenuCreateEditController;
    (function (hamburgerMenuCreateEditController) {
        var hamburgerMenuCreateEditComponentController = (function () {
            function hamburgerMenuCreateEditComponentController(rearrangeUtils, $routeParams, $location, hamburgerMenuService, securityService, contentTargetingService, alertService, adGraphService, $rootScope) {
                this.rearrangeUtils = rearrangeUtils;
                this.$routeParams = $routeParams;
                this.$location = $location;
                this.hamburgerMenuService = hamburgerMenuService;
                this.securityService = securityService;
                this.contentTargetingService = contentTargetingService;
                this.alertService = alertService;
                this.adGraphService = adGraphService;
                this.$rootScope = $rootScope;
                this.isSubmited = false;
                this.livePositionChange1 = true;
                this.livePositionChange2 = true;
                this.livePositionChange3 = true;
                this.regex = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
            }
            hamburgerMenuCreateEditComponentController.prototype.$onInit = function () {
                var self = this;
                self.labels = [];
                self.currentLevel = '1';
                self.firmKey = self.$routeParams.firm;
                self.page = self.$location.path().split('/')[2];
                self.initHamburgerMenuItems();
                self.securityService.getUserPermissions().then(function (permissions) {
                    self.userPermissions = permissions[self.firmKey];
                });
            };
            hamburgerMenuCreateEditComponentController.prototype.checkUrlFilter = function (s) {
                if (s) {
                    if (!s.match(/^[a-zA-Z]+:\/\//)) {
                        s = 'http://' + s;
                    }
                    return s;
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.initHamburgerMenuItems = function () {
                var _this = this;
                this.hamburgerMenuService.getFirmByKey(this.firmKey).then(function (result) {
                    _this.firm = result.items[0];
                    _this.hamburgerMenuItems = _this.firm.navigation.mainMenu;
                    var index = 1;
                    for (var _i = 0, _a = _this.hamburgerMenuItems; _i < _a.length; _i++) {
                        var item = _a[_i];
                        if (item.code === _this.$routeParams.code) {
                            _this.hamburgerMenuItem = item;
                            _this.hamburgerMenuItem.position = index;
                            break;
                        }
                        index++;
                    }
                    if (!_this.hamburgerMenuItem) {
                        _this.hamburgerMenuItem = {};
                    }
                    if (_this.hamburgerMenuItems.indexOf(_this.hamburgerMenuItem) < 0)
                        _this.hamburgerMenuItems.push(_this.hamburgerMenuItem);
                    if (!_this.hamburgerMenuItem.position)
                        _this.hamburgerMenuItem.position = _this.hamburgerMenuItems.length;
                    _this.setSubcategoryPositions();
                    _this.setLabels();
                });
            };
            hamburgerMenuCreateEditComponentController.prototype.onChangeMainCategoryName = function (item) {
                this.updateCode(item);
            };
            hamburgerMenuCreateEditComponentController.prototype.countCode = function (code) {
                var counter = 0;
                if (this.hamburgerMenuItems && code) {
                    for (var i = 0; i < this.hamburgerMenuItems.length; i++) {
                        if (this.hamburgerMenuItems[i] &&
                            this.hamburgerMenuItems[i].code &&
                            this.hamburgerMenuItems[i].code.toLocaleLowerCase() === code.toLocaleLowerCase()) {
                            counter++;
                        }
                    }
                }
                return counter;
            };
            hamburgerMenuCreateEditComponentController.prototype.itemWithDuplicatedCode = function () {
                return this.countCode(this.hamburgerMenuItem.code) > 1;
            };
            hamburgerMenuCreateEditComponentController.prototype.onPositionChanged = function (livePositionChange, changed, array) {
                if (livePositionChange)
                    this.rearrangeUtils.rearrangePositions(changed, array || this.hamburgerMenuItem.items);
            };
            hamburgerMenuCreateEditComponentController.prototype.getPositionText = function (Position) {
                return 'Position ' + (+Position + 1);
            };
            hamburgerMenuCreateEditComponentController.prototype.saveFirm = function () {
                this.hamburgerMenuItem = this.updateCode(this.hamburgerMenuItem);
                if (this.livePositionChange1) {
                    this.onPositionChanged(this.livePositionChange1, this.hamburgerMenuItem, this.hamburgerMenuItems);
                }
                else {
                    this.sortMainCategory();
                    this.sortSubCategory();
                }
                return this.hamburgerMenuService.saveFirm(this.firm);
            };
            hamburgerMenuCreateEditComponentController.prototype.sortMainCategory = function () {
                if (!angular.isObject(this.hamburgerMenuItems))
                    return;
                for (var index = 0; index < this.hamburgerMenuItems.length; index++) {
                    if (this.hamburgerMenuItems[index].hasOwnProperty("position")) {
                        var pos = this.hamburgerMenuItems[index].position;
                        var tmp = this.hamburgerMenuItems[pos - 1];
                        this.hamburgerMenuItems[pos - 1] = this.hamburgerMenuItems[index];
                        this.hamburgerMenuItems[index] = tmp;
                    }
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.sortSubCategory = function () {
                if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items))
                    return;
                var array = [];
                for (var item in this.hamburgerMenuItem.items) {
                    this.hamburgerMenuItem.items[item].items = this.sortSubCategoryLink(this.hamburgerMenuItem.items[item].items);
                    array.push(this.hamburgerMenuItem.items[item]);
                }
                array.sort(function (a, b) {
                    return (a["position"] > b["position"] ? 1 : -1);
                });
                this.hamburgerMenuItem.items = array;
            };
            hamburgerMenuCreateEditComponentController.prototype.sortSubCategoryLink = function (items) {
                if (!angular.isObject(items))
                    return items;
                var array = [];
                for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
                    var item = items_1[_i];
                    array.push(item);
                }
                array.sort(function (a, b) {
                    return (a["position"] > b["position"] ? 1 : -1);
                });
                return array;
            };
            hamburgerMenuCreateEditComponentController.prototype.setSubcategoryPositions = function () {
                if (!angular.isDefined(this.hamburgerMenuItem || !angular.isDefined(this.hamburgerMenuItem.items)))
                    return;
                if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items))
                    return;
                var index = 1;
                for (var _i = 0, _a = this.hamburgerMenuItem.items; _i < _a.length; _i++) {
                    var item = _a[_i];
                    item.position = index;
                    if (angular.isDefined(item.items)) {
                        var subIndex = 1;
                        for (var _b = 0, _c = item.items; _b < _c.length; _b++) {
                            var subItem = _c[_b];
                            subItem["position"] = subIndex;
                            subIndex++;
                        }
                    }
                    index++;
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.updateCode = function (menuItem) {
                var self = this;
                if (menuItem.title)
                    menuItem.code = menuItem.title.replace(/ /g, "");
                if (menuItem.items) {
                    for (var _i = 0, _a = menuItem.items; _i < _a.length; _i++) {
                        var item = _a[_i];
                        self.updateCode(item);
                    }
                }
                return menuItem;
            };
            hamburgerMenuCreateEditComponentController.prototype.delete = function (hamburgerMenuItem) {
                var self = this;
                self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, hamburgerMenuItem);
            };
            hamburgerMenuCreateEditComponentController.prototype.onRemoveGroup = function (group, category) {
                var groupIndex = category.groups.indexOf(group);
                if (groupIndex !== -1) {
                    category.groups.splice(groupIndex, 1);
                }
                this.saveFirm().then(function () {
                });
            };
            hamburgerMenuCreateEditComponentController.prototype.countPosition = function (position, items) {
                var counter = 0;
                if (items) {
                    for (var i = 0; i < items.length; i++) {
                        if (items[i] && items[i].position && items[i].position === position)
                            counter++;
                    }
                }
                return counter;
            };
            hamburgerMenuCreateEditComponentController.prototype.goTo = function (location) {
                var _this = this;
                var self = this;
                self.isSubmited = true;
                if (location === 'MainList') {
                    if (self.page === "create") {
                        self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, self.hamburgerMenuItem)
                            .then(function () {
                            self.$location.path('hamburgerMenu');
                        });
                    }
                    else {
                        self.$location.path('hamburgerMenu');
                    }
                }
                else if (location === 'Save') {
                    self.saveFirm()
                        .then(function () {
                        self.$location.path('hamburgerMenu');
                    }, function (error) {
                        self.isSubmited = false;
                        _this.alertService.show({
                            buttons: app.components.alert.AlertButtons.Accept,
                            title: error.statusText,
                            message: error.data.message,
                            dismissText: "Ok"
                        });
                    });
                }
                else {
                    self.saveFirm().then(function () {
                        self.$location.path('hamburgerMenu/' + self.page + '/' + self.$routeParams.firm + '/' + self.hamburgerMenuItem.code + '/' + location);
                    });
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.addNewItem = function (category) {
                if (!category.items) {
                    category.items = [];
                }
                category.items.push({ position: category.items.length + 1 });
                this.labels[this.labels.length] = "Sub - category " + (this.labels.length + 1);
            };
            hamburgerMenuCreateEditComponentController.prototype.deleteItem = function (category, subcategory, labelIndex) {
                for (var index = 0; index < category.items.length; index++) {
                    if (category.items[index].title === subcategory.title) {
                        category.items.splice(index, 1);
                        this.labels.splice(labelIndex, 1);
                        this.setLabels();
                        this.updateSubcategory(category, index, subcategory.position);
                        break;
                    }
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.setLabels = function () {
                if (!angular.isDefined(this.hamburgerMenuItem.items)) {
                    return;
                }
                this.labels = [this.hamburgerMenuItem.items.length > 0 ? this.hamburgerMenuItem.items.length : 1];
                if (this.hamburgerMenuItem.items.length === 0)
                    this.labels[0] = "Sub - category 1";
                for (var i = 0; i < this.hamburgerMenuItem.items.length; i++) {
                    this.labels[i] = "Sub - category " + (i + 1);
                }
            };
            hamburgerMenuCreateEditComponentController.prototype.updateSubcategory = function (category, subIndex, position) {
                var initialPosition = position;
                for (var index = subIndex; index < category.items.length; index++) {
                    category.items[index].position = initialPosition;
                    initialPosition += 1;
                }
            };
            return hamburgerMenuCreateEditComponentController;
        }());
        hamburgerMenuCreateEditComponentController.$inject = ['rearrangeUtils', '$routeParams', '$location', 'hamburgerMenuService', 'securityService', 'contentTargetingService', 'alertService', 'adGraphService', "$rootScope"];
        hamburgerMenuCreateEditController.hamburgerMenuCreateEditComponentController = hamburgerMenuCreateEditComponentController;
    })(hamburgerMenuCreateEditController = app.hamburgerMenuCreateEditController || (app.hamburgerMenuCreateEditController = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-create-edit.controller.js.map