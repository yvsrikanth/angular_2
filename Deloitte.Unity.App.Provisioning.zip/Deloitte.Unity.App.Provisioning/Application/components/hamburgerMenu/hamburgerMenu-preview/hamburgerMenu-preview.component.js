var app;
(function (app) {
    var directives;
    (function (directives) {
        var hamburgerMenuPreviewComponent = (function () {
            function hamburgerMenuPreviewComponent() {
                this.bindings = {
                    hamburgerMenuItem: "<"
                };
                this.controller = app.hamburgerMenuPreviewController.hamburgerMenuPreviewComponentController;
                this.templateUrl = "/Application/components/hamburgerMenu/hamburgerMenu-preview/hamburgerMenu-preview.html";
                this.controllerAs = "hamburgerMenuPreview";
            }
            return hamburgerMenuPreviewComponent;
        }());
        angular.module("SPApp").component("hamburgerMenuPreview", new hamburgerMenuPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-preview.component.js.map