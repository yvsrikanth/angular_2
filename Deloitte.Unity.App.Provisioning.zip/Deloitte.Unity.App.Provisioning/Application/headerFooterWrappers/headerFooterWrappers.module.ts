﻿module app.headerFooterWrappers {

    angular
        .module("SPApp.headerFooter", [
            "headerFooterApp"
        ])
        .component("headerWrapper", headerFooterWrappers.headerWrapper.headerWrapperComponent)
        .component("footerWrapper", headerFooterWrappers.footerWrapper.footerWrapperComponent);
        
}