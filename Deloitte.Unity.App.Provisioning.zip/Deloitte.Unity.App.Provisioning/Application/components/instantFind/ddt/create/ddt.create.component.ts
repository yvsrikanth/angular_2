﻿module app.directives {

    class ddtCreateComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
            this.templateUrl = '/Application/components/instantFind/ddt/create/ddt.create.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('ddtCreate', new ddtCreateComponent());
}