﻿module app.directives {

    class notificationsComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                notificationsData: '@',
                type: '@'
            };
            this.controller = app.notificationsComponentController.notificationsComponentController;
            this.templateUrl = '/Application/components/notifications/notifications.html';
            this.controllerAs = "notificationsCtrl";
        }
    }

    angular.module('SPApp').component('systemNotifications', new notificationsComponent());
}