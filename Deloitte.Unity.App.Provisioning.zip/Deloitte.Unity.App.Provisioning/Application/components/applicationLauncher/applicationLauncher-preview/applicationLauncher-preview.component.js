var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationLauncherPreviewComponent = (function () {
            function applicationLauncherPreviewComponent() {
                this.controller = app.applicationLauncherPreviewController.applicationLauncherPreviewController;
                this.templateUrl =
                    '/Application/components/applicationLauncher/applicationLauncher-preview/applicationLauncher-preview.html';
                this.controllerAs = "applicationLauncherPreview";
            }
            return applicationLauncherPreviewComponent;
        }());
        directives.applicationLauncherPreviewComponent = applicationLauncherPreviewComponent;
        angular.module('SPApp').component('applicationLauncherPreview', new applicationLauncherPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-preview.component.js.map