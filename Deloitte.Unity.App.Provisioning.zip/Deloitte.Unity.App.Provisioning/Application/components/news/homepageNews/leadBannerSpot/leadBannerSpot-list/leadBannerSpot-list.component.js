var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadBannerSpotListComponent = (function () {
            function leadBannerSpotListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.leadBannerSpotListController.leadBannerSpotListComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot-list/leadBannerSpot-list.component.html";
                this.controllerAs = "leadBannerSpotList";
            }
            return leadBannerSpotListComponent;
        }());
        directives.leadBannerSpotListComponent = leadBannerSpotListComponent;
        angular.module("SPApp").component("leadBannerSpotList", new leadBannerSpotListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-list.component.js.map