var app;
(function (app) {
    var applicationLauncherController;
    (function (applicationLauncherController) {
        var applicationLauncherComponentController = (function () {
            function applicationLauncherComponentController($scope, $rootScope, $http, $compile, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$compile = $compile;
                this.securityService = securityService;
                var self = this;
                self.http = $http;
                self.memberFirmName = "Select";
                self.whenOneItem = 1;
            }
            applicationLauncherComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firmWithPermissions = Object.keys(permissions).sort();
                    _this.firms = Object.keys(_this.userPermissions).sort();
                });
            };
            applicationLauncherComponentController.prototype.getMemberFirmItemData = function (data) {
                this.memberFirmName = data.name;
            };
            return applicationLauncherComponentController;
        }());
        applicationLauncherComponentController.$inject = ['$scope', '$rootScope', '$http', '$compile', 'securityService'];
        applicationLauncherController.applicationLauncherComponentController = applicationLauncherComponentController;
    })(applicationLauncherController = app.applicationLauncherController || (app.applicationLauncherController = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher.controller.js.map