var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var leadNews;
                (function (leadNews) {
                    var leadNewsThumbnailsPreviewComponent = {
                        bindings: {
                            news: "<",
                            selectedNew: "=?",
                            skipSort: "<"
                        },
                        controller: news.genericNewsLayoutPreviewController,
                        templateUrl: "/Application/components/news/homepageNews/leadNews/leadNews-thumbnailsPreview/leadNews-thumbnailsPreview.html",
                        controllerAs: "vm"
                    };
                    angular.module("SPApp").component("leadNewsThumbnailsPreview", leadNewsThumbnailsPreviewComponent);
                })(leadNews = homepageNews.leadNews || (homepageNews.leadNews = {}));
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-thumbnailsPreview.component.js.map