var app;
(function (app) {
    var expandedLeadNewsPreviewController;
    (function (expandedLeadNewsPreviewController) {
        var leadNewsPreviewComponentController = (function () {
            function leadNewsPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
            }
            leadNewsPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.leadNewsItem = [];
                for (var itemIndex = 0; itemIndex < 2; itemIndex++) {
                    this.leadNewsItem.push(app.components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "Lead"));
                }
                this.setLeadNewsParams();
                this.getDetailsLeadNewsItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            leadNewsPreviewComponentController.prototype.setLeadNewsParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                }
                if (angular.isDefined(this.$routeParams.edit)) {
                    this.edit = this.$routeParams.edit;
                }
            };
            leadNewsPreviewComponentController.prototype.setItemsOnPositions = function (items) {
                if (items.length) {
                    var layout = items[0].layout;
                    for (var i = 0; i < this.leadNewsItem.length; i++) {
                        this.leadNewsItem[i].layout = layout;
                    }
                }
                app.components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.leadNewsItem);
            };
            leadNewsPreviewComponentController.prototype.getDetailsLeadNewsItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllLeadNewsData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestLeadNewsItem();
                    return;
                }
            };
            leadNewsPreviewComponentController.prototype.requestAllLeadNewsData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "Lead", take: 2 }).then(function (result) {
                    _this.setItemsOnPositions(result.items);
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            leadNewsPreviewComponentController.prototype.requestLeadNewsItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.setItemsOnPositions([data]);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.setItemsOnPositions([item]);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            leadNewsPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.leadNewsItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.leadNewsItem.length > 1;
            };
            leadNewsPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/expandedpageNews/leadNews");
            };
            return leadNewsPreviewComponentController;
        }());
        leadNewsPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];
        expandedLeadNewsPreviewController.leadNewsPreviewComponentController = leadNewsPreviewComponentController;
    })(expandedLeadNewsPreviewController = app.expandedLeadNewsPreviewController || (app.expandedLeadNewsPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-preview.controller.js.map