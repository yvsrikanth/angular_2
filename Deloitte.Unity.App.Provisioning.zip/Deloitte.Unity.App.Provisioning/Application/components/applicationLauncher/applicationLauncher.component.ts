﻿module app.directives {

    class applicationLauncherComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                headlineNewsItem: '@'
            };
            this.controller = applicationLauncherController.applicationLauncherComponentController;
            this.templateUrl = '/Application/components/applicationLauncher/applicationLauncher.html';
            this.controllerAs = "applicationLauncherVm";
        }
    }

    angular.module('SPApp').component('applicationLauncher', new applicationLauncherComponent());

}