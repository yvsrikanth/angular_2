var app;
(function (app) {
    var directives;
    (function (directives) {
        var AudienceName = (function () {
            function AudienceName(audiencesService) {
                var _this = this;
                this.audiencesService = audiencesService;
                this.restrict = 'A';
                this.template = '{{name}}<ng-transclude></ng-transclude>';
                this.transclude = true;
                this.scope = {
                    audienceId: '='
                };
                this.link = function (scope) {
                    scope.name = scope.audienceId;
                    _this.audiencesService.getById(scope.audienceId)
                        .then(function (res) {
                        scope.name = res['displayName'];
                    }, function () {
                        scope.name = "Audience not found";
                    });
                };
            }
            AudienceName.factory = function () {
                var directive = function (audiencesService) { return new AudienceName(audiencesService); };
                directive.$inject = ['audiencesService'];
                return directive;
            };
            return AudienceName;
        }());
        angular.module('SPApp').directive('audienceName', AudienceName.factory());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=audienceName.directive.js.map