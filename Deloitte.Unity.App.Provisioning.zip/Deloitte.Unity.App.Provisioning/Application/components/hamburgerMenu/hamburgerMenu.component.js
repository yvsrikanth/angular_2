var app;
(function (app) {
    var directives;
    (function (directives) {
        var hamburgerMenuComponent = (function () {
            function hamburgerMenuComponent() {
                this.controller = app.hamburgerMenuController.hamburgerMenuComponentController;
                this.templateUrl = '/Application/components/hamburgerMenu/hamburgerMenu.html';
                this.controllerAs = "hamburgerMenu";
            }
            return hamburgerMenuComponent;
        }());
        angular.module('SPApp').component('hamburgerMenu', new hamburgerMenuComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu.component.js.map