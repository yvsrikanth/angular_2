var app;
(function (app) {
    var leadBannerSpotPreviewController;
    (function (leadBannerSpotPreviewController) {
        var leadBannerSpotPreviewComponentController = (function () {
            function leadBannerSpotPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService, audienceService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
                this.audienceService = audienceService;
            }
            leadBannerSpotPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setleadBannerSpotParams();
                this.leadBannerSpotItem = [];
                this.getDetailsLeadBannerSpotItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            leadBannerSpotPreviewComponentController.prototype.setleadBannerSpotParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            leadBannerSpotPreviewComponentController.prototype.getDetailsLeadBannerSpotItem = function () {
                if (!angular.isDefined(this.id)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.id)) {
                    this.requestLeadBannerSpotItem();
                    return;
                }
            };
            leadBannerSpotPreviewComponentController.prototype.requestLeadBannerSpotItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.leadBannerSpotItem.push(data);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.leadBannerSpotItem.push(item);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            leadBannerSpotPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.leadBannerSpotItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.loadAudiences();
            };
            leadBannerSpotPreviewComponentController.prototype.loadAudiences = function () {
                var that = this;
                that.audiences = [];
                var _loop_1 = function (audience) {
                    that.audienceService.getContentTargetById(audience).then(function (data) {
                        that.audiences.push(data.displayName);
                    }, function () {
                        that.audiences.push("Item Not Found - " + audience);
                    });
                };
                for (var _i = 0, _a = that.selectedItem.audiences; _i < _a.length; _i++) {
                    var audience = _a[_i];
                    _loop_1(audience);
                }
            };
            leadBannerSpotPreviewComponentController.prototype.getImageSrc = function () {
                if (this.selectedItem && this.selectedItem.items && this.selectedItem.items.length) {
                    return this.selectedItem.items[0].imageUrl || this.selectedItem.items[0].image;
                }
                else {
                    return null;
                }
            };
            leadBannerSpotPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/homepageNews/leadBannerSpot");
            };
            return leadBannerSpotPreviewComponentController;
        }());
        leadBannerSpotPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService", "contentTargetingService"];
        leadBannerSpotPreviewController.leadBannerSpotPreviewComponentController = leadBannerSpotPreviewComponentController;
    })(leadBannerSpotPreviewController = app.leadBannerSpotPreviewController || (app.leadBannerSpotPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-preview.controller.js.map