﻿module app.components.news.expandedpageNews.thumbnailNews {
    export class expandedThumbnailNewsCreateEditController extends genericNewsCreateEditController {
        
        static $inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService,
                /*pageTitleOnEditAll*/ "Edit thumbnail news layout",
                /*pageTitleOnEditById*/ "Edit thumbnail news",
                /*pageTitleOnCreate*/ "Create thumbnail news",
                /*maxItems*/ 14,
                /*region*/ "Thumbnail-newstab",
                /*listPath*/ "/news/expandedpageNews/thumbnailNews");
        }
    }
}