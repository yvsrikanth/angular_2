﻿module app.pageTitleController {


    export class pageTitleComponentController {

        static $inject = ['$scope', '$rootScope', 'securityService'];
        public firms: any;
        public userPermissions: any;

        constructor(private $scope, private $rootScope, private securityService: security.shared.securityService) {
        }

        $onInit() {

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firms = Object.keys(this.userPermissions).sort();;

            });
        }

    }
}