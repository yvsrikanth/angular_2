var app;
(function (app) {
    var components;
    (function (components) {
        var siteProvisioning;
        (function (siteProvisioning) {
            var siteProvisioningListComponentOptions = {
                bindings: {},
                controller: siteProvisioning.siteProvisioningListController,
                templateUrl: "/Application/components/siteProvisioning/siteProvisioning-list/siteProvisioning-list.component.html",
                controllerAs: "vm"
            };
            angular.module("SPApp").component("siteProvisioning", siteProvisioningListComponentOptions);
        })(siteProvisioning = components.siteProvisioning || (components.siteProvisioning = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=siteProvisioning-list.component.js.map