var app;
(function (app) {
    var expandedExternalResourcesPreviewController;
    (function (expandedExternalResourcesPreviewController) {
        var externalResourcesPreviewComponentController = (function () {
            function externalResourcesPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
            }
            externalResourcesPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setParams();
                this.externalResourcesItem = [];
                this.getDetailsExternalResourcesItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            externalResourcesPreviewComponentController.prototype.setParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                    this.resourceTitle = "Preview external resource";
                    this.buttonText = "Edit resource";
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                    this.resourceTitle = "External resource layout preview";
                    this.buttonText = "Edit layout";
                }
            };
            externalResourcesPreviewComponentController.prototype.getDetailsExternalResourcesItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllExternalResourceData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestExternalResourcesItem();
                    return;
                }
            };
            externalResourcesPreviewComponentController.prototype.requestAllExternalResourceData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "external-links", take: 8 }).then(function (result) {
                    _this.externalResourcesItem = result.items;
                    _this.externalResourcesItem.sort(function (a, b) { return a.ordinal - b.ordinal; });
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            externalResourcesPreviewComponentController.prototype.requestExternalResourcesItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.externalResourcesItem.push(data);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.externalResourcesItem.push(item);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            externalResourcesPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.externalResourcesItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.externalResourcesItem.length > 1;
            };
            externalResourcesPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/expandedpageNews/externalResources");
            };
            return externalResourcesPreviewComponentController;
        }());
        externalResourcesPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];
        expandedExternalResourcesPreviewController.externalResourcesPreviewComponentController = externalResourcesPreviewComponentController;
    })(expandedExternalResourcesPreviewController = app.expandedExternalResourcesPreviewController || (app.expandedExternalResourcesPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-preview.controller.js.map