// ReSharper disable StringLiteralWrongQuotes
var app;
(function (app) {
    var components;
    (function (components) {
        var sp;
        (function (sp) {
            var report;
            (function (report) {
                var reportController = (function () {
                    function reportController($http, $filter, $templateCache, $window, spService) {
                        var _this = this;
                        this.$http = $http;
                        this.$filter = $filter;
                        this.$templateCache = $templateCache;
                        this.$window = $window;
                        this.spService = spService;
                        this.searchText = '';
                        //filterOptions: any = {
                        //    filterText: ''
                        //};
                        this.filterOptions = {
                            filterText: "searchText",
                            useExternalFilter: false
                        };
                        this.gridOptions1 = {
                            expandableRowTemplate: "<div style=\"background-color: rgb(248, 248, 248) !important;\" id=\"reqPanel\" class=\"innergidTemp\">\n                                      <ul class=\"ms-Pivot ms-Pivot--large\" style=\"padding-left: 21px; background-color: rgb(248, 248, 248) !important;\">\n                                          <li id=\"RequestInfoLi{{row.entity.Id}}\" class=\"ms-Pivot-link is-selected\" data-panel=\"RequestInfo{{row.entity.Id}}\" ng-click=\"clickMeSub(row.entity.Id, 'RequestInfoLi', 'RequestInfo', 'rolesLi', 'roles', 'RequestInfoLi', 'RequestInfo')\"\n                                              ng-bind=\"'FormLabels.RequestDetails'| translate\"></li>\n                                  \n                                          <span style=\"color: green; padding-right: 15px; font-weight: bold;\">|</span>\n                                          <li id=\"rolesLi{{row.entity.Id}}\" class=\"ms-Pivot-link\" data-panel=\"roles{{row.entity.Id}}\" ng-click=\"clickMeSub(row.entity.Id,'rolesLi, 'roles, 'RequestInfoLi, 'RequestInfo')\"\n                                              ng-bind=\"'FormLabels.RequestHistory'| translate\"></li>\n                                      </ul>\n                                      <!--<hr id=\"callhr\"/>-->\n                                      <div class=\"ms-Pivot-panel-container fade1\">\n                                          <!--<div class=\"ms-Pivot-panel \" id=\"RequestInfo\">-->\n                                          <div style=\"margin-top:15px; background-color: rgb(248, 248, 248) !important;\" class=\"ms-Pivot-panel is-selected\" id=\"RequestInfo{{row.entity.Id}}\">\n                                              <table class=\"ms-Table\">\n                                                  <tr>\n                                                      <td class=\"reqInfo\">ID:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Id}}</td>\n                                                      <td class=\"reqInfo\">{{\"FormLabels.Description\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Description}}</td>\n                                                      <td class=\"reqInfo-wide\">{{\"FormLabels.IsSearchable\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.IsSearchable}}</td>\n                                                  </tr>\n                                                  <tr>\n                                                      <td class=\"reqInfo\" ng-if=adminVal()>{{\"FormLabels.Requestor\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\" ng-if=adminVal()>{{row.entity.Requestor}}</td>\n                                                      <!--<td class=\"reqInfo\" ng-if=adminVal()>Requestor:</td><td class=\"reqInfoVal\" ng-if=adminVal()>{{row.entity.Requestor}}</td>-->\n                                                      <td class=\"reqInfo\">{{\"FormLabels.Size\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Size}}</td>\n                                                      <td class=\"reqInfo-wide\">{{\"FormLabels.OriginalRequestor\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.OriginalRequestor}}</td>\n                                                  </tr>\n                                                  <tr>\n                                                      <td class=\"reqInfo\">OmnitureRSID:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.OmnitureRSID}}</td>\n                                                      <td class=\"reqInfo\">{{\"FormLabels.Status\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Status}}</td>\n                                                      <td class=\"reqInfo-wide\">{{\"FormLabels.Language\" | translate }}:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Language}}</td>\n                                                  </tr>\n                                                  <tr>\n                                                      <td class=\"reqInfo\">Addtl. Admins:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.AdditionalAdmins.join()}}</td>\n                                                      <td class=\"reqInfo\">Exception:</td>\n                                                      <td class=\"reqInfoVal\">{{row.entity.Exception }}</td>\n                                                  </tr>\n                                              </table>\n                                              <!--<div>\n                                                  <span style=\"padding-left:10px\">\n                                                      <strong>Member Firm Values:</strong>\n                                                  </span>\n                                              </div>\n                                              <div class=\"ms-Table\">\n                                                  <div ng-repeat=\"(key, value) in row.entity.MemberFirmValues\">\n                                                      <div class=\"ms-Table-row\">\n                                                          <span style=\"width:177px ; border-bottom:0px!important\" class=\"ms-Table-cell u-textAlignLeft\">{{value.Key}}</span>\n                                                          <span style=\"border-bottom:0px!important\" class=\"ms-Table-cell u-textAlignLeft\">{{value.Value}}</span>\n                                                      </div>\n                                                  </div>\n                                              </div>-->\n                                              <div>\n                                                  <span style=\"padding-left:10px\">\n                                                      <strong>{{\"FormLabels.MemberFirmValues\" | translate }}:</strong>\n                                                  </span>\n                                              </div>\n                                              <table calss=\"ms-Table\">\n                                                  <tr ng-repeat=\"(key, value) in row.entity.MemberFirmValues\">\n                                                      <!--commenting biswa-->\n                                                      <!--<td style=\"width:123px;padding-left:10px;color: darkgray !important;padding-bottom:10px;\">{{value.Key}}</td><td class=\"reqInfoVal\">{{value.Value}}</td>-->\n                                                      <td class=\"MemberFirmVal\">{{value.Key}}</td>\n                                                      <td class=\"reqInfoVal\">{{value.Value}}</td>\n                                                  </tr>\n                                              </table>\n                                          </div>\n                                          <!--<div class=\"ms-Pivot-panel is-selected\" id=\"roles\">-->\n                                          <!--<div  style=\"background-color: rgb(248, 248, 248);\" class=\"ms-Pivot-panel\" id=\"roles\">-->\n                                          <div style=\"background-color: rgb(248, 248, 248);\" class=\"ms-Pivot-panel\" id=\"roles{{row.entity.Id}}\">\n                                              <!--<div class=\"ms-Table\">\n                                                  <div class=\"ms-Table-row \">\n                                                      <span style=\"width:200px\" class=\"ms-Table-cell\">\n                                                          <strong>Status</strong>\n                                                      </span>\n                                                      <span class=\"ms-Table-cell\">\n                                                          <strong>Date</strong>\n                                                      </span>\n                                                  </div>\n                                              </div>\n                                              <div class=\"ms-Table\">\n                                                  <div class=\"ms-Table-row \" ng-repeat=\"subitem in row.entity.RequestHistoryColl\">\n                                                      <div class=\"ms-Table-row\">\n                                                          <span class=\"ms-Table-cell\">{{subitem.Status}}</span>\n                                                          <span class=\"ms-Table-cell u-textAlignLeft\">{{(new Date(parseInt(subitem.ProcessedOn.replace('/Date(', '')))).toUTCString()}}</span>\n                                                      </div>\n                                                      <div class=\"ms-Table-row\">\n                                                          <span style=\"width:200px; border-bottom:0px!important\" class=\"ms-Table-cell\">{{subitem.Status}}</span>\n                                                          <span style=\"border-bottom:0px!important\" class=\"ms-Table-cell\">{{formatDate(subitem.ProcessedOn)}}</span>\n                                                      </div>\n                                                  </div>\n                                              </div>-->\n                                              <table class=\"ms-Table\">\n                                                  <tr>\n                                                      <td style=\"width:123px;padding-left:10px;padding-top:5px\"><b>{{\"FormLabels.Status\" | translate }}</b></td>\n                                                      <td><b>Date</b></td>\n                                                  </tr>\n                                                  <tr></tr>\n                                                  <tr ng-repeat=\"subitem in row.entity.RequestHistoryColl\">\n                                                      <td style=\"width:123px;padding-left:10px;padding-top:5px;color: darkgray !important;\">{{subitem.Status}}</td>\n                                                      <td>{{formatDate(subitem.ProcessedOn)}}</td>\n                                                  </tr>\n                                              </table>\n                                          </div>\n                                      </div>\n                                  </div>",
                            columnDefs: [
                                {
                                    name: 'Title',
                                    pinnedLeft: true,
                                    displayName: 'FormLabels.Title',
                                    headerCellFilter: 'translate',
                                    cellTemplate: '<div class="columndef"><a href="{{row.entity.URL}}">{{COL_FIELD}}</a></div>'
                                },
                                {
                                    field: 'MemberFirm',
                                    displayName: 'FormLabels.MemberFirm',
                                    headerCellFilter: 'translate',
                                    width: "15%",
                                    cellClass: 'rowItem ms-u-hiddenSm',
                                    headerCellClass: 'ms-u-hiddenSm',
                                    enableFiltering: true
                                },
                                {
                                    field: 'PrimaryAdmin',
                                    displayName: 'FormLabels.PrimaryAdmin',
                                    headerCellFilter: 'translate',
                                    width: "15%",
                                    cellClass: 'rowItem ms-u-hiddenMdDown',
                                    headerCellClass: 'ms-u-hiddenMdDown'
                                },
                                {
                                    field: 'SiteType',
                                    displayName: 'FormLabels.SiteType',
                                    headerCellFilter: 'translate',
                                    cellClass: 'rowItem',
                                    width: "10%"
                                },
                                {
                                    field: 'Status',
                                    displayName: 'FormLabels.Status',
                                    headerCellFilter: 'translate',
                                    width: "10%",
                                    cellClass: 'rowItem ms-u-hiddenMdDown',
                                    headerCellClass: 'ms-u-hiddenMdDown'
                                },
                                {
                                    field: 'Indicator',
                                    name: 'Status',
                                    displayName: 'FormLabels.Status',
                                    headerCellFilter: 'translate',
                                    width: 100,
                                    enableSorting: false,
                                    enableColumnMenu: false,
                                    cellClass: 'rowItem grid-align',
                                    cellTemplate: "<div ng-if=\"row.entity.Status=='Provisioned'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-success ms-Icon--circleFill\"></i>\n                                       <span class=\"opensasgriddata statusopensans\">{{row.entity.Status}}</span>\n                                   </div>\n                                   <div ng-if=\"row.entity.Status=='Failed'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-alert ms-Icon--circleFill\"></i>\n                                       <span class=\"opensasgriddata statusopensans\">{{row.entity.Status}}</span>\n                                   </div>\n                                   <div ng-if=\"row.entity.Status=='Requested'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-yellow ms-Icon--circleFill\"></i>\n                                       <span style=\"padding-left:5px\">{{row.entity.Status}}</span>\n                                   </div>\n                                   <div ng-if=\"row.entity.Status=='Creating'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-yellow ms-Icon--circleFill\"></i>\n                                       <span style=\"padding-left:5px\">{{row.entity.Status}}</span>\n                                   </div>\n                                   <div ng-if=\"row.entity.Status=='Created'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-yellow ms-Icon--circleFill\"></i>\n                                       <span style=\"padding-left:5px\">{{row.entity.Status}}</span>\n                                   </div>\n                                   <div ng-if=\"row.entity.Status=='Provisioning'\">\n                                       <i ng-click=\"grid.appScope.GetInfo($event,row)\" class=\"icoSize ms-Icon ms-fontColor-yellow ms-Icon--circleFill\"></i>\n                                       <span style=\"padding-left:5px\">{{row.entity.Status}}</span>\n                                   </div>"
                                },
                                {
                                    field: 'RequestedOn',
                                    displayName: 'FormLabels.RequestDate',
                                    headerCellFilter: 'translate',
                                    width: "20%",
                                    enableColumnResizing: true,
                                    cellClass: 'rowItemDate ms-u-hiddenSm',
                                    headerCellClass: 'ms-u-hiddenSm',
                                    cellTemplate: "<div style='font-size:14px;padding-top:5px;padding-left:3px'>{{grid.appScope.formatDate(COL_FIELD)}}</div>",
                                    cellFilter: 'date:\'yyyy-MM-dd\''
                                },
                                {
                                    field: 'Action',
                                    displayName: 'FormLabels.Action',
                                    headerCellFilter: 'translate',
                                    enableSorting: false,
                                    enableColumnMenu: false,
                                    cellClass: 'grid-align',
                                    width: "100",
                                    cellTemplate: "<div style=\"text-align:left\" ng-if=\"row.entity.Status=='Failed'\"><img style=\"width:18px\" ng-click=\"grid.appScope.GetAction($event,row)\"><span class=\"spl-icon-File_edit\" style=\"font-size: 24px\"></span></img></div>'"
                                },
                                {
                                    name: 'expand',
                                    cellTemplate: "<div style=\"color:#53565a\" class=\"ui-grid-header-cell ui-grid-row-header-cell ui-grid-expandable-buttons-cell\">\n                                       <div class=\"ui-grid-cell-contents\">\n                                           <i ng-class=\"{ 'spl-icon-smallchevron-down' : !row.isExpanded, 'spl-icon-smallchevron-up' : row.isExpanded }\" ng-click=\"grid.api.expandable.toggleRowExpansion(row.entity)\"></i>\n                                       </div>\n                                   </div>",
                                    displayName: '',
                                    enableSorting: false,
                                    enableColumnMenu: false,
                                    width: "20"
                                },
                                {
                                    field: 'Action',
                                    displayName: '',
                                    enableSorting: false,
                                    enableColumnMenu: false,
                                    width: "20"
                                }
                            ],
                            onRegisterApi: function (gridApi) {
                                _this.gridApi1 = gridApi;
                            },
                            //'<div ui-grid="row.entity.subGridOptions" style="height:100%;"></div>',
                            //expandableRowTemplate:'<div ui-grid="row.entity.subGridOptions" style="height:{{(18 * 30) + 10}}px"  ui-grid-auto-resize></div>',
                            enableExpandableRowHeader: false,
                            enableColumnResizing: false,
                            enablePaginationControls: false,
                            paginationPageSize: 10,
                            enableHorizontalScrollbar: 0,
                            enableVerticalScrollbar: 0,
                            enableColumnMenus: false,
                            enableRowSelection: true,
                            enableRowHeaderSelection: false,
                            multiSelect: false,
                            noUnselect: true,
                            expandableRowHeight: 'auto',
                            rowHeight: 45,
                            expandableRowScope: {
                                clickMeSub: function (rowid, listid, dataid, hidelistid, hidedataid) {
                                    listid += rowid;
                                    dataid += rowid;
                                    hidelistid += rowid;
                                    hidedataid += rowid;
                                    var queryResult = document.getElementById(hidelistid);
                                    var activeListId = angular.element(queryResult);
                                    activeListId.removeClass('is-selected');
                                    queryResult = document.getElementById(hidedataid);
                                    activeListId = angular.element(queryResult);
                                    activeListId.removeClass('is-selected');
                                    queryResult = document.getElementById(listid);
                                    activeListId = angular.element(queryResult);
                                    activeListId.removeClass('is-selected');
                                    activeListId.addClass('is-selected');
                                    queryResult = document.getElementById(dataid);
                                    activeListId = angular.element(queryResult);
                                    activeListId.removeClass('is-selected');
                                    activeListId.addClass('is-selected');
                                    return false;
                                },
                                formatDate: function (date) {
                                    return (new Date(parseInt(date.replace('/Date(', '')))).toUTCString();
                                },
                                adminVal: function () {
                                    var val = _this.adminValue;
                                    if (val == "true")
                                        return true;
                                    else
                                        return false;
                                }
                            },
                            filterOptions: this.filterOptions
                        };
                    }
                    reportController.prototype.$onInit = function () {
                        var _this = this;
                        this.spService
                            .getSitesDetails()
                            .then(function (data) {
                            _this.firmData = data;
                        });
                        this.spService
                            .getSitesDetailsOfUser("vikram")
                            .then(function (data) {
                            _this.firmData = data;
                            console.log(data);
                        });
                        this.$templateCache
                            .put('ui-grid/expandableRowHeader', "<div class=\"ui-grid-header-cell ui-grid-row-header-cell ui-grid-expandable-buttons-cell\">\n                        <div class=\"ui-grid-cell-contents\">\n                            <i ng-class=\"{ 'ui-grid-icon-angle-down' : !row.isExpanded, 'ui-grid-icon-up-dir' : row.isExpanded }\" ng-click=\"grid.api.expandable.toggleRowExpansion(row.entity)\"></i>\n                        </div>\n                    </div>");
                        this.gridOptions1.data = this.$window.bootstrappedSiteRequests;
                        var pos = this.gridOptions1
                            .columnDefs
                            .map(function (e) {
                            return e.field;
                        }).indexOf('Action');
                        this.gridOptions1.columnDefs[pos].visible = this.$window.admin == 'true';
                        this.adminValue = this.$window.admin;
                    };
                    //  $http.get('/DisplayRequest/GetAllData')
                    //    .success(function (data) {
                    //        $scope.gridOptions.data = data;
                    //    })
                    //.error(function (data) {
                    //    alert('fail');
                    //    $scope.message = 'Unexpected Error while loading data!!';
                    //    $scope.result = "color-red";
                    //    console.log($scope.message);
                    //});
                    reportController.prototype.formatDate = function (date) {
                        return (new Date(parseInt(date.replace("/Date(", "")))).toUTCString();
                    };
                    reportController.prototype.refreshData = function () {
                        this.gridOptions1.data = this.$filter("filter")(this.$window.bootstrappedSiteRequests, this.searchText, undefined);
                    };
                    //biswa code change
                    reportController.prototype.range = function (min, max, step) {
                        step = step || 1;
                        var input = [];
                        for (var i = min; i <= max; i += step)
                            input.push(i);
                        return input;
                    };
                    return reportController;
                }());
                reportController.$inject = ['$http', '$filter', '$templateCache', '$window', 'siteRequestService'];
                report.reportController = reportController;
            })(report = sp.report || (sp.report = {}));
        })(sp = components.sp || (components.sp = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
// ReSharper restore StringLiteralWrongQuotes 
//# sourceMappingURL=report.controller.js.map