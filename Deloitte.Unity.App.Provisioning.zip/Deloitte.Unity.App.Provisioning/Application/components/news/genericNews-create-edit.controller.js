var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news_1) {
            var genericNewsCreateEditController = (function () {
                function genericNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, pageTitleOnEditAll, pageTitleOnEditById, pageTitleOnCreate, maxItems, region, listPath) {
                    this.rearrangeUtils = rearrangeUtils;
                    this.$anchorScroll = $anchorScroll;
                    this.$q = $q;
                    this.$location = $location;
                    this.$routeParams = $routeParams;
                    this.contentTargetingService = contentTargetingService;
                    this.newsService = newsService;
                    this.hamburgerMenuService = hamburgerMenuService;
                    this.alertService = alertService;
                    this.pageTitleOnEditAll = pageTitleOnEditAll;
                    this.pageTitleOnEditById = pageTitleOnEditById;
                    this.pageTitleOnCreate = pageTitleOnCreate;
                    this.maxItems = maxItems;
                    this.region = region;
                    this.listPath = listPath;
                    this.saving = false;
                    this.haveBeenPreviewed = false;
                    this.imgPreviewed = false;
                    this.originalItems = new Array();
                    this.items = new Array();
                    this.previewItems = new Array();
                    this.audiences = new Array();
                    this.ordinals = new Array();
                    this.isSubmited = false;
                    this.loaded = false;
                    this.validateFormField = false;
                    this.livePositionChange = true;
                    this.regex = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
                }
                genericNewsCreateEditController.prototype.onFetchItems = function () {
                };
                genericNewsCreateEditController.prototype.$onInit = function () {
                    this.firm = this.$routeParams.firm;
                    for (var itemIndex = 0; itemIndex < this.maxItems; itemIndex++) {
                        this.items.push(this.getEmptyItem(itemIndex + 1));
                    }
                    for (var i = 0; i < this.items.length; i++) {
                        this.ordinals.push(i + 1);
                    }
                    this.setItemsToPreview(this.items);
                    this.fetchAudiences();
                    this.fetchItems(this.$routeParams.id);
                    if (this.region === 'headline') {
                        this.getBlockName();
                    }
                };
                genericNewsCreateEditController.prototype.getPageTitle = function () {
                    var id = this.$routeParams.id;
                    if (id) {
                        if (id.toLowerCase() === "all") {
                            return this.pageTitleOnEditAll;
                        }
                        else {
                            return this.pageTitleOnEditById;
                        }
                    }
                    else {
                        return this.pageTitleOnCreate;
                    }
                };
                genericNewsCreateEditController.prototype.fetchAudiences = function () {
                    var _this = this;
                    this.contentTargetingService.getAudiencesData(this.firm)
                        .then(function (response) {
                        _this.audiences = response.items;
                    });
                };
                genericNewsCreateEditController.prototype.checkUrlFilter = function (s) {
                    if (s) {
                        if (!s.match(/^[a-zA-Z]+:\/\//)) {
                            s = 'http://' + s;
                        }
                        return s;
                    }
                };
                genericNewsCreateEditController.prototype.getBlockName = function () {
                    var _this = this;
                    this.hamburgerMenuService
                        .getFirmByKey(this.firm)
                        .then(function (response) {
                        if (response.items.length > 0) {
                            _this.firmDataFromHamburgerMenu = response.items[0];
                            _this.blockName = response.items[0].newsHeadlineTitle !== "*" ? response.items[0].newsHeadlineTitle : "";
                            _this.previewBlockName = _this.blockName;
                        }
                        else {
                            _this.firmDataFromHamburgerMenu = null;
                        }
                    });
                };
                genericNewsCreateEditController.prototype.getEmptyItem = function (ordinal, id) {
                    return genericNewsCreateEditController.getEmptyItem(ordinal, this.firm, this.region, id);
                };
                genericNewsCreateEditController.getEmptyItem = function (ordinal, firm, region, id) {
                    return {
                        audiences: new Array(),
                        ordinal: null,
                        items: [{ language: "0", content: "...", description: "..." }],
                        firm: firm,
                        region: region,
                        layout: "Layout",
                        id: id,
                        isEnabled: true
                    };
                };
                genericNewsCreateEditController.prototype.goToList = function () {
                    this.$location.path(this.listPath).search({});
                };
                genericNewsCreateEditController.prototype.fetchItems = function (id) {
                    var _this = this;
                    if (!id)
                        id = "all";
                    var promise;
                    if (id.toLowerCase() === "all") {
                        promise = this.newsService
                            .get({ firm: this.firm, region: this.region, take: this.maxItems, include: "image" })
                            .then(function (result) {
                            for (var index = 0; index < result.items.length; index++) {
                                var item = result.items[index];
                                _this.items[item.ordinal - 1] = item;
                            }
                            return result.items;
                        });
                    }
                    else {
                        promise = this.newsService
                            .getById(id, "image")
                            .then(function (item) {
                            _this.items = [item];
                            return _this.items;
                        });
                    }
                    promise.then(function () {
                        _this.originalItems = angular.copy(_this.items);
                        _this.onFetchItems();
                        _this.setItemsToPreview(_this.items);
                        _this.loaded = true;
                        ////Potential placeholer-ngModel Fix
                        //setTimeout(() => {
                        //    for (var i = 0; i < this.items.length; i++) {
                        //        angular.element(`#title${i+1}`).val(this.items[i].items[0].title);
                        //        angular.element(`#subtitle${i+1}`).val(this.items[i].items[0].subtitle);
                        //        angular.element(`#url${i+1}`).val(this.items[i].items[0].url);
                        //        angular.element(`#thumbnail${i+1}`).val(this.items[i].items[0].thumbnailTitle);
                        //    }
                        //}, 100);
                    });
                };
                genericNewsCreateEditController.prototype.onClear = function (item) {
                    var index = this.items.indexOf(item);
                    this.items[index] = this.getEmptyItem(item.ordinal, item.id);
                };
                genericNewsCreateEditController.prototype.onPreview = function () {
                    if ($('.error-message').length > 0) {
                        return;
                    }
                    this.setItemsToPreview(this.items);
                    this.haveBeenPreviewed = true;
                    this.imgPreviewed = true;
                };
                genericNewsCreateEditController.prototype.onChangeImg = function () {
                    this.imgPreviewed = false;
                };
                genericNewsCreateEditController.prototype.getAvaliableOrdinal = function (news) {
                    return genericNewsCreateEditController.getAvaliableOrdinal(news);
                };
                genericNewsCreateEditController.prototype.onPositionChanged = function (changed) {
                    if (this.livePositionChange)
                        this.rearrangeUtils.rearrangeOrdinals(changed, this.items);
                };
                genericNewsCreateEditController.setItemsOnPositions = function (items, target) {
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        target[item.ordinal - 1] = item;
                    }
                };
                genericNewsCreateEditController.getAvaliableOrdinal = function (news) {
                    var ordinal = 1;
                    while (true) {
                        if (news.filter(function (n) { return n.ordinal === ordinal; }).length) {
                            ordinal++;
                        }
                        else {
                            return ordinal;
                        }
                    }
                };
                genericNewsCreateEditController.processOrdinalSoring = function (items) {
                    var previewItems = angular.copy(items);
                    var ordinalsToClear = [];
                    for (var i = 0; i < previewItems.length; i++) {
                        if (!previewItems[i].ordinal) {
                            var ordinal = this.getAvaliableOrdinal(previewItems);
                            ordinalsToClear.push(ordinal);
                            previewItems[i].ordinal = ordinal;
                        }
                    }
                    previewItems.sort(function (a, b) { return a.ordinal - b.ordinal; });
                    for (var i = 0; i < ordinalsToClear.length; i++) {
                        previewItems.filter(function (n) { return n.ordinal === ordinalsToClear[i]; })[0].ordinal = undefined;
                    }
                    return previewItems;
                };
                genericNewsCreateEditController.prototype.setItemsToPreview = function (items) {
                    this.previewItems = genericNewsCreateEditController.processOrdinalSoring(items);
                    this.previewedItemsJson = angular.toJson(items);
                    var ordinalId;
                    for (var i = 0; i < this.previewItems.length; i++) {
                        var item = this.previewItems[i];
                        var image = item["image"];
                        var thumb = item["thumbnail"];
                        if (image && image.data) {
                            item.items[0].image = image.data;
                        }
                        if (thumb && thumb.data) {
                            item.items[0].thumbnail = thumb.data;
                        }
                        delete item["image"];
                        delete item["thumbnail"];
                    }
                    if (this.previewItems.length === 1) {
                        ordinalId = this.previewItems[0].ordinal - 1;
                        var previewItemsUpdatedList = [];
                        for (var i = 0; i < this.maxItems; i++) {
                            if (i === ordinalId) {
                                previewItemsUpdatedList.push(this.previewItems[0]);
                            }
                            else {
                                previewItemsUpdatedList.push({});
                            }
                        }
                        this.previewItems = previewItemsUpdatedList;
                    }
                    this.selectedPreviewItem = this.previewItems[0];
                };
                genericNewsCreateEditController.prototype.onSelectAudience = function (audience, item) {
                    if (item.audiences.indexOf(audience.id) === -1) {
                        item.audiences.push(audience.id);
                    }
                };
                genericNewsCreateEditController.prototype.onRemoveAudience = function (id, item) {
                    var audIndex = item.audiences.indexOf(id);
                    if (audIndex !== -1) {
                        item.audiences.splice(audIndex, 1);
                    }
                };
                genericNewsCreateEditController.prototype.onClearImage = function (item, index) {
                    item["image"] = {};
                    item.items[0].image = null;
                    item.items[0].imageUrl = null;
                };
                genericNewsCreateEditController.prototype.onClearThumbnail = function (item, index) {
                    item["thumbnail"] = {};
                    item.items[0].thumbnail = null;
                    item.items[0].thumbnailUrl = null;
                };
                genericNewsCreateEditController.prototype.getImageText = function (item, img) {
                    return img && img.name ? img.name : ((item ? item.items[0].imageUrl : null) || "");
                };
                genericNewsCreateEditController.prototype.getImageThumbnailText = function (item, img) {
                    return img && img.name ? img.name : ((item ? item.items[0].thumbnailUrl : null) || "");
                };
                genericNewsCreateEditController.prototype.getAudienceName = function (id) {
                    for (var i = 0; i < this.audiences.length; i++) {
                        var aud = this.audiences[i];
                        if (aud.id === id) {
                            return aud.displayName;
                        }
                    }
                    return id;
                };
                genericNewsCreateEditController.prototype.countOrdinal = function (ordinal, items) {
                    var counter = 0;
                    for (var i = 0; i < items.length; i++) {
                        if (items[i] && items[i].ordinal === ordinal)
                            counter++;
                    }
                    return counter;
                };
                genericNewsCreateEditController.prototype.validateOrdinal = function (items) {
                    for (var index = 0; index < items.length; index++) {
                        if (items[index].ordinal && this.countOrdinal(items[index].ordinal, items) !== 1) {
                            return false;
                        }
                    }
                    return true;
                };
                genericNewsCreateEditController.prototype.onCancel = function () {
                    this.goToList();
                };
                genericNewsCreateEditController.prototype.hasChangedOrIsNew = function (item, originals) {
                    if (!item) {
                        return false;
                    }
                    if (!item.id) {
                        return true;
                    }
                    // Is not new, should be in the originals
                    var match = originals.filter(function (n) { return n.id === item.id; });
                    if (!match.length) {
                        return true;
                    }
                    // Return if changed or not
                    return !angular.equals(match[0], item);
                };
                genericNewsCreateEditController.prototype.previewed = function () {
                    var currentItemsJson = angular.toJson(this.items);
                    var dataPreviewed = currentItemsJson === this.previewedItemsJson;
                    return dataPreviewed && this.imgPreviewed;
                };
                genericNewsCreateEditController.prototype.positionsAreValid = function (items) {
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        if (this.isValidForPublishing(item, true)) {
                            if (!item.ordinal)
                                return false;
                        }
                    }
                    return true;
                };
                genericNewsCreateEditController.prototype.save = function (checkPreviewChange, skipCheckPositions, invalid) {
                    var _this = this;
                    if (invalid) {
                        this.$anchorScroll("mainView");
                        return;
                    }
                    if (checkPreviewChange && !this.previewed()) {
                        return;
                    }
                    if (!skipCheckPositions && !this.positionsAreValid(this.previewItems)) {
                        this.$anchorScroll("mainView");
                        return;
                    }
                    this.isSubmited = true;
                    var promises = [];
                    if (this.region === "headline" && this.firmDataFromHamburgerMenu != null) {
                        this.firmDataFromHamburgerMenu.newsHeadlineTitle = this.blockName !== "" ? this.blockName : "*";
                        this.hamburgerMenuService.saveFirm(this.firmDataFromHamburgerMenu);
                    }
                    var error = {};
                    for (var index = 0; index < this.previewItems.length; index++) {
                        var item = this.previewItems[index];
                        item.ordinal = index + 1;
                        //Identify items to delete
                        if (item.id && !this.isValidForPublishing(item, true)) {
                            promises.push(this.newsService.delete(item.id));
                        }
                        else if (this.isValidForPublishing(item)) {
                            //Identify items to skip
                            if (this.hasChangedOrIsNew(item, this.originalItems)) {
                                promises.push(this.newsService.save(item, !item.id));
                            }
                        }
                    }
                    this.saving = true;
                    this.$q.all(promises).then(function () {
                        $("body").removeClass("modal-open");
                        _this.saving = false;
                        _this.goToList();
                    }, function (result) {
                        _this.saving = false;
                        error = result;
                    });
                    if (error.hasOwnProperty("statusText")) {
                        this.showError(error);
                    }
                };
                genericNewsCreateEditController.prototype.showError = function (error) {
                    this.alertService.show({
                        buttons: components.alert.AlertButtons.Accept,
                        title: error.statusText !== "" ? error.statusText : 'Server error',
                        message: error.data !== null ? error.data.message : 'Server error',
                        dismissText: "Ok"
                    });
                };
                genericNewsCreateEditController.prototype.setImageDataToItem = function (item) {
                    var _this = this;
                    var self = this;
                    return self.$q(function (resolve) {
                        var isDatasetThumbnail = false;
                        var isDatasetImage = false;
                        if (item.items[0].thumbnailUrl != null && item.items[0].thumbnail == null) {
                            var fileExtension = item.items[0].thumbnailUrl
                                .substr(item.items[0].thumbnailUrl.lastIndexOf('.') + 1);
                            _this.toDataUrl(item.items[0].thumbnailUrl, function (baseImage) {
                                item.items[0].thumbnail = baseImage;
                                isDatasetThumbnail = true;
                                if (isDatasetThumbnail && isDatasetImage) {
                                    resolve(item);
                                }
                            }, 'image/' + fileExtension);
                        }
                        else {
                            isDatasetThumbnail = true;
                        }
                        if (item.items[0].imageUrl != null && item.items[0].image == null) {
                            var fileExtension = item.items[0].imageUrl
                                .substr(item.items[0].imageUrl.lastIndexOf('.') + 1);
                            _this.toDataUrl(item.items[0].imageUrl, function (baseImage) {
                                item.items[0].image = baseImage;
                                isDatasetImage = true;
                                if (isDatasetThumbnail && isDatasetImage) {
                                    resolve(item);
                                }
                            }, 'image/' + fileExtension);
                        }
                        else {
                            isDatasetImage = true;
                        }
                        if (isDatasetThumbnail && isDatasetImage) {
                            resolve(item);
                        }
                    });
                };
                genericNewsCreateEditController.prototype.toDataUrl = function (src, callback, outputFormat) {
                    var img = new Image();
                    img.crossOrigin = 'Anonymous';
                    img.src = src;
                    var self = this;
                    img.onload = function () {
                        var canvas = document.createElement('CANVAS');
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(self, 0, 0);
                        var dataUrl = canvas.toDataURL(outputFormat);
                        callback(dataUrl);
                    };
                };
                genericNewsCreateEditController.prototype.isValidForPublishing = function (item, excludeId) {
                    return genericNewsCreateEditController.isValidForPublishing(item, excludeId);
                };
                genericNewsCreateEditController.isValidForPublishing = function (item, excludeId) {
                    if (!excludeId && item.id || (item.audiences && item.audiences.length))
                        return true;
                    var child = (item && item.items) ? item.items[0] : {};
                    var childAttrs = 0;
                    for (var attr in child) {
                        if (child.hasOwnProperty(attr) && child[attr])
                            childAttrs++;
                    }
                    if (childAttrs > 3)
                        return true;
                    return false;
                };
                return genericNewsCreateEditController;
            }());
            news_1.genericNewsCreateEditController = genericNewsCreateEditController;
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=genericNews-create-edit.controller.js.map