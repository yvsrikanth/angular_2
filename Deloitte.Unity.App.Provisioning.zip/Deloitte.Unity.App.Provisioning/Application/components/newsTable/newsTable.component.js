var app;
(function (app) {
    var components;
    (function (components) {
        var newsTable;
        (function (newsTable) {
            var newsTableComponent = (function () {
                function newsTableComponent() {
                    this.bindings = {
                        columns: "<",
                        rows: "<",
                        firm: "@",
                        module: "@",
                        linkButton: "=",
                        editButton: "=",
                        deleteButton: "=",
                        visibleButton: "=",
                        editUrl: "@",
                        previewUrl: "@"
                    };
                    this.controller = newsTable.newsTableComponentController;
                    this.templateUrl = "/Application/components/newsTable/newsTable.component.html";
                    this.controllerAs = "table";
                }
                return newsTableComponent;
            }());
            newsTable.newsTableComponent = newsTableComponent;
            angular.module("SPApp").component("newsTable", new newsTableComponent());
        })(newsTable = components.newsTable || (components.newsTable = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=newsTable.component.js.map