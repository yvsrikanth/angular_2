﻿module app.directives {

    class expandedHeadlineNewsComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.expandedHeadlineNews.headlineNewsComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews.component.html";
            this.controllerAs = "headlineNews";
        }

    }

    angular.module("SPApp").component("expandedHeadlineNews", new expandedHeadlineNewsComponent());

}