var app;
(function (app) {
    var directives;
    (function (directives) {
        var headlineNewsListComponent = (function () {
            function headlineNewsListComponent() {
                this.bindings = {
                    firm: '='
                };
                this.controller = app.headlineNewsListController.headlineNewsListComponentController;
                this.templateUrl = '/Application/components/news/homepageNews/headlineNews/headlineNews-list/headlineNews-list.html';
                this.controllerAs = "headlineNewsList";
            }
            return headlineNewsListComponent;
        }());
        directives.headlineNewsListComponent = headlineNewsListComponent;
        angular.module('SPApp').component('headlineNewsListComponent', new headlineNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-list.component.js.map