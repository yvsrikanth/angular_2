var app;
(function (app) {
    var aadEndpoints = {
        "https://graph.microsoft.com": "https://graph.microsoft.com",
        "https://resources.deloitte.com": "https://resources.deloitte.com",
        "https://outlook.office.com": "https://outlook.office.com"
    };
    aadEndpoints[unityConfigKeys.apiMapKey] = unityConfigKeys.apiMapValue;
    aadEndpoints[unityConfigKeys.alertsAadApiKey] = unityConfigKeys.alertsAadApiValue;
    app.appSettings = {
        adal: {
            instance: "https://login.microsoftonline.com/",
            tenant: "deloitte.com",
            clientId: unityConfigKeys.clientId,
            redirectUrl: unityConfigKeys.redirectUrl,
            aadEndpoints: aadEndpoints,
            viewportMatrix: function () {
                var w = window, d = w.document, de = d.documentElement, db = d.body || d.getElementsByTagName("body")[0], x = w.innerWidth || de.clientWidth || db.clientWidth, y = w.innerHeight || de.clientHeight || db.clientHeight;
                return { width: x, height: y };
            }
        },
        apiUrl: unityConfigKeys.unityApiEndpointUrl,
        subscriptionId: unityConfigKeys.unityApiSubscriptionKey
    };
    angular.module("SPApp").constant("appSettings", app.appSettings);
})(app || (app = {}));
//# sourceMappingURL=app.settings.js.map