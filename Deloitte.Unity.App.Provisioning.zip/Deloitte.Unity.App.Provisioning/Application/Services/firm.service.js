/// <reference path="../app.settings.ts" />
/// <reference path="services.model.ts" />
/// <reference path="../../scripts/typings/angularjs/angular.d.ts" />
var app;
(function (app) {
    var services;
    (function (services) {
        var firmService = (function () {
            function firmService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            firmService.prototype.get = function (options) {
                var result;
                if (!options || (typeof options === "object")) {
                    result = this.$http
                        .get(this.appSettings.apiUrl + "/firms", { params: options || {} });
                }
                else {
                    result = this.$http
                        .get(this.appSettings.apiUrl + "/firms/" + options);
                }
                return result
                    .then(function (result) {
                    var queryResult = result.data;
                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }
                    return queryResult;
                });
            };
            firmService.prototype.put = function (data) {
                return this.$http
                    .put(this.appSettings.apiUrl + "/firms/" + data.id, data)
                    .then(function (response) { return response.data; });
            };
            return firmService;
        }());
        firmService.$inject = ["$http", "appSettings"];
        services.firmService = firmService;
        function siteFirmServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(firmService);
        }
        angular.module("SPApp").factory("firmService", ["$rootElement", function ($rootElement) { return siteFirmServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=firm.service.js.map