var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedLeadNewsPreviewComponent = (function () {
            function expandedLeadNewsPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.expandedLeadNewsPreviewController.leadNewsPreviewComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews-preview/leadNews-preview.html";
                this.controllerAs = "leadNewsPreview";
            }
            return expandedLeadNewsPreviewComponent;
        }());
        angular.module("SPApp").component("expandedLeadNewsPreview", new expandedLeadNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-preview.component.js.map