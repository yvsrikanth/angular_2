﻿module app.directives {

    class newsItemComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                item: "<",
                title: "@",
                titlePrimaryImage: "@",
                titlePrimaryNews: "@",
                subtitleNews: "@",
                showThumbnail: "=",
                showContent: "=",
                titleUrl: "@",
                showPosition: "="
            };
            this.controller = newsItemController.newsItemComponentController;
            this.templateUrl = "/Application/components/newsItem/newsItem.component.html";
            this.controllerAs = "newsItem";
        }
    }
    angular.module("SPApp").component("newsItem", new newsItemComponent());
}