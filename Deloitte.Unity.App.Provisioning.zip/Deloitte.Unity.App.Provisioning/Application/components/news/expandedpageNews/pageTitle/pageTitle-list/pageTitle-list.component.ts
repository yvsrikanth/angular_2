﻿namespace app.directives {
    export class pageTitleListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: '='
            };
            this.controller = pageTitleListController.pageTitleListComponentController;
            this.templateUrl = '/Application/components/news/expandedpageNews/pageTitle/pageTitle-list/pageTitle-list.html';
            this.controllerAs = "pageTitleList";
        }
    }

    angular.module('SPApp').component('pageTitleListComponent', new pageTitleListComponent());
}