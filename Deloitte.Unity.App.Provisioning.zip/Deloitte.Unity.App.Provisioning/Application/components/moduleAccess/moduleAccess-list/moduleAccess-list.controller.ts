﻿module app.moduleAccessListController {

    export class moduleAccessListComponentController {

        static $inject = ["$scope", "$rootScope", "moduleAccessService", "securityService", "$routeParams", "alertService"];

        firm: string;

        moduleAccessItem: any;
        moduleAccessItemDetails: any;
        query: any;
        totalCount = 0;
        itemsPerPage: Number;
        modulesList: any;
        moduleId: string;
        userPermissions: security.shared.IModulePermissions;
        sortCol: string = "DisplayName";
        asc: boolean = true;

        constructor(private $scope, private $rootScope, private moduleAccessService: services.moduleAccessService, private securityService: security.shared.securityService, private $routeParams, private alertService: components.alert.alertService) {

            this.itemsPerPage = 8;
            this.query = {
                skip: 0, take: this.itemsPerPage
            };


        }

        $onInit() {

            this.moduleAccess(0, this.itemsPerPage);

            this.securityService.getUserPermissions().then(permissions => {
                this.setMemberFirm();
                this.userPermissions = permissions[this.firm];
            });
        }

        sort(col: string) {
            if (col === this.sortCol) {
                this.asc = !this.asc;
            } else {
                this.sortCol = col;
                this.asc = true;
            }
            this.moduleAccess(this.query.skip, this.itemsPerPage);
        }

        getSortExpression() {
            return (this.asc ? '' : '-') + this.sortCol;
        }

        moduleAccess(skip, take) {

            this.moduleAccessService.getModuleAccess(skip, take, this.firm, this.getSortExpression())
                .then((data: any) => {
                    this.query = data.query;
                    this.moduleAccessItem = data.items;
                    this.totalCount = data.totalCount;
                    this.getGroupedData();
                });

        }

        getGroupedData() {

            for (let item of this.moduleAccessItem) {

                let modules = item.permissions.length > 0 ? [item.permissions[0].split("-")[0]] : [];

                if (item.permissions.length > 0) {

                    for (let mod of item.permissions) {
                        if (this.validateModuleExists(mod.split("-")[0], modules) === false) { modules.push(mod.split("-")[0]); }
                    }

                }
                item.permissions = modules;
            }
        }

        validateModuleExists(module, modules) {

            for (let mod of modules) {

                if (mod === module) { return true; }
            }

            return false;
        }

        getModuleList(modules) {
            this.modulesList = modules;
        }

        deleteModuleAccessItem(item) {
            this.moduleId = item.id;

            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: 'Delete an entry ',
                message: 'The selected entry will be deleted. This action cannot be undone.',
                dismissText: 'Cancel',
                confirmText: 'Delete',
                onConfirm: () => {
                    this.onConfirmDeleteModuleAccessItem(item);
                    this.alertService.close();
                }
            });
        }

        onConfirmDeleteModuleAccessItem(item) {

            this.moduleAccessService.deleteModuleAccessItem(this.moduleId).then(() => {
                this.moduleAccessItem.splice(this.moduleAccessItem.indexOf(item), 1);
                this.moduleAccess(0, this.itemsPerPage);
            });
        }

        setDetailsModuleAccessItem(data) {
            sessionStorage.setItem("module-access-item", angular.toJson(data));
        }

        setMemberFirm() {

            if (this.$routeParams.firm !== undefined && !angular.isDefined(this.firm)) {
                this.firm = this.$routeParams.firm;
            }

        }

    }
}