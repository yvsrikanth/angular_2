﻿module app.directives {

    class contentTargetingCreateComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                contentTargetItem: '@',
            };
            this.controller = app.contentTargetingCreateController.contentTargetingCreateComponentController;
            this.templateUrl = '/Application/components/contentTargeting/contentTargeting-create-edit/contentTargeting-create-edit.html';
            this.controllerAs = "contentTargetingCreateVm";
        }

    }

    angular.module('SPApp').component('contentTargetingCreate', new contentTargetingCreateComponent());

}