﻿module app.components.news.expandedpageNews.headlineNews  {

    var expandedHeadlineNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {


        },
        controller: expandedHeadlineNewsCreateEditController,
        templateUrl: "/Application/components/news/expandedpageNews/headlineNews/headlineNews-create-edit/headlineNews-create-edit.html",
        controllerAs: "expandedHeadlineNewsCreateEdit"
    }

    angular.module('SPApp').component('expandedHeadlineNewsCreateEdit', expandedHeadlineNewsCreateEditComponent);

}