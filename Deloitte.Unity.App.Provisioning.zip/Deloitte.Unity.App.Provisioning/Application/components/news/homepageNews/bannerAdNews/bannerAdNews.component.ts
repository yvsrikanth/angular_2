﻿module app.directives {

    class bannerAdNewsComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.bannerAdNews.bannerAdNewsComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews.component.html";
            this.controllerAs = "bannerAdNews";
        }

    }

    angular.module("SPApp").component("bannerAdNews", new bannerAdNewsComponent());

}