﻿module app.components.pagination {
    export class paginationComponentController {

        static $inject = [];
        constructor() {
        }

        //Inputs
        skip: number;
        take: number;
        totalCount: number;

        //Output
        onChangePage: (paramsObject?: any) => void;

        //Internal attributes
        pages: number[];
        currentPage: number;
        lastPage: number;

        $onChanges(changes: ng.IOnChangesObject) {
            this.currentPage = (this.skip / this.take) + 1;
            this.lastPage = Math.ceil((this.totalCount || 1) / this.take);
            if (this.currentPage > this.lastPage) {
                this.skip = this.skip - this.take;
                this.setPage(this.lastPage);
            }
            this.pages = this.buildPages(this.skip, this.take, this.totalCount);
        }

        setPage(page: number, force?: boolean) {

            if (force || this.currentPage !== page) {
                let start = (page - 1) * this.take;
                this.skip = start;
                this.currentPage = page;
                this.pages = this.buildPages(this.skip, this.take, this.totalCount);
                this.doRequest();
            }
        }

        onGoTo() {
            //Should we need to ask to the user the page to go to?
        }

        onSelectPage(page: number) {
            if (page) {
                this.setPage(page);
            } else {
                this.onGoTo();
            }
        }

        onNextPage() {
            if (this.currentPage !== this.lastPage) {
                this.setPage(this.currentPage + 1);
            }
        }
        onNextPrevious() {
            if (this.currentPage !== 1) {
                this.setPage(this.currentPage - 1);
            }
        }

        isFirstPage() {
            return this.isCurrentPage(1);
        }

        isLastPage() {
            return this.isCurrentPage(this.lastPage);
        }

        isCurrentPage(page: number) {
            return this.currentPage === page;
        }

        doRequest() {
            this.onChangePage({
                $event: {
                    skip: this.skip,
                    take: this.take
                }
            });
        }

        /**
         * Builds and returns an array of page indexes from the specified parameters
         * @param skip Number of items to skip
         * @param take Number of items to take
         * @param total Total number of items in the data store
         */
        buildPages(skip: number, take: number, total: number) {
            /*
            var skip = 40, total = 121, take = 20;
            var skip = 0, total = 121, take = 20;
            /**/
            var page = (skip / take) + 1;
            let pages = Math.ceil(total / take);
            let result: number[] = [];

            if (pages > 7) {
                result.push(1);

                if (page < 5) {
                    for (let i = 2; i <= 5; i++) {
                        result.push(i);
                    }
                    result.push(0);
                } else if (page > pages - 4) {
                    result.push(0);
                    for (let i = pages - 4; i < pages; i++) {
                        result.push(i);
                    }
                } else {
                    result.push(0);
                    for (let i = page - 1; i <= page + 1; i++) {
                        result.push(i);
                    }
                    result.push(0);
                }
                result.push(pages);
            } else {
                if (!pages) {
                    result.push(1);
                } else {
                    for (let i = 0; i < pages; i++) {
                        result.push(i + 1);
                    }
                }
            }

            return result;
        }
    }
}