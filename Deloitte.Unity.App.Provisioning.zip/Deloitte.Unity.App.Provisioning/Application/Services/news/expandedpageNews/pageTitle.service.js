var app;
(function (app) {
    var services;
    (function (services) {
        var pageTitleService = (function () {
            function pageTitleService($http, appSettings) {
                this.appSettings = appSettings;
                this.path = "/firms/";
                this.http = $http;
            }
            pageTitleService.prototype.deletePageTitle = function (newsId, reData) {
                return this.http.put(this.appSettings.apiUrl + this.path + newsId, reData);
            };
            pageTitleService.prototype.createEditPageTitle = function (newsId, reData) {
                return this.http.put(this.appSettings.apiUrl + this.path + newsId, reData);
            };
            pageTitleService.prototype.getPageList = function (skip, take, firm) {
                var configList = {
                    params: {
                        "skip": skip,
                        "take": take,
                        "key": firm
                    }
                };
                return this.http.get(this.appSettings.apiUrl + this.path, configList).then(function (result) { return result.data; });
            };
            pageTitleService.prototype.getSelectedPageTitleData = function (firmId) {
                return this.http.get(this.appSettings.apiUrl + this.path + firmId).then(function (result) { return result.data; });
            };
            pageTitleService.prototype.setFirm = function (firm) {
                this.selectedFirm = firm;
            };
            pageTitleService.prototype.setFirmObj = function (item) {
                this.selectedFirmObj = item;
            };
            pageTitleService.prototype.getFirmObj = function () {
                return this.selectedFirmObj;
            };
            pageTitleService.prototype.getFirmName = function () {
                return this.selectedFirm;
            };
            return pageTitleService;
        }());
        pageTitleService.$inject = ['$http', 'appSettings'];
        services.pageTitleService = pageTitleService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(pageTitleService);
        }
        angular.module("SPApp").factory('pageTitleService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle.service.js.map