﻿namespace app.directives {
    export class expandedThumbnailNewsListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = expandedThumbnailNewsListController.thumbnailNewsListComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-list/thumbnailNews-list.component.html";
            this.controllerAs = "thumbnailNewsList";
        }
    }
    angular.module("SPApp").component("expandedThumbnailNewsList", new expandedThumbnailNewsListComponent());
}