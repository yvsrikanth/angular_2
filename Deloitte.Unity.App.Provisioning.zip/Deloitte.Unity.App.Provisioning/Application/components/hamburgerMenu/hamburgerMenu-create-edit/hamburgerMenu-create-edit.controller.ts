﻿module app.hamburgerMenuCreateEditController {
    import ICategory = components.hamburgerMenu.ICategory;
    import ISubcategory = components.hamburgerMenu.ISubcategory;
    import ICategoryBase = components.hamburgerMenu.ICategoryBase;

    export class hamburgerMenuCreateEditComponentController {
        static $inject = ['rearrangeUtils', '$routeParams', '$location', 'hamburgerMenuService', 'securityService', 'contentTargetingService', 'alertService', 'adGraphService', "$rootScope"];

        firm: any;
        firmKey: string;
        hamburgerMenuItem: ICategory;
        hamburgerMenuItems: ICategory[];
        userPermissions: security.shared.IModulePermissions;
        currentLevel: string;
        page: string;
        labels: any;
        isNew: boolean;
        isSubmited: boolean = false;
        livePositionChange1: boolean = true;
        livePositionChange2: boolean = true;
        livePositionChange3: boolean = true;

        public regex: any = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

        constructor(
            private rearrangeUtils: components.itemsWithOrdinal.RearrangeUtils,
            private $routeParams,
            private $location: ng.ILocationService,
            private hamburgerMenuService: services.hamburgerMenuService,
            private securityService: security.shared.securityService,
            private contentTargetingService: services.contentTargetingService,
            private alertService: components.alert.alertService,
            private adGraphService: services.adGraphService,
            private $rootScope
        ) { }

        $onInit() {

            let self = this;

            self.labels = [];
            self.currentLevel = '1';
            self.firmKey = self.$routeParams.firm;
            self.page = self.$location.path().split('/')[2];
            self.initHamburgerMenuItems();

            self.securityService.getUserPermissions().then(permissions => {
                self.userPermissions = permissions[self.firmKey];
            });

        }


        checkUrlFilter(s: any) {
            if (s) {
                if (!s.match(/^[a-zA-Z]+:\/\//)) {
                    s = 'http://' + s;
                }
                return s;
            }
        }

        initHamburgerMenuItems() {

            this.hamburgerMenuService.getFirmByKey(this.firmKey).then((result: any) => {
                this.firm = result.items[0];

                this.hamburgerMenuItems = this.firm.navigation.mainMenu;
                let index = 1;
                for (let item of this.hamburgerMenuItems) {
                    if (item.code === this.$routeParams.code) {
                        this.hamburgerMenuItem = item;
                        this.hamburgerMenuItem.position = index;
                        break;
                    }
                    index++;
                }

                if (!this.hamburgerMenuItem) {
                    this.hamburgerMenuItem = {};
                }

                if (this.hamburgerMenuItems.indexOf(this.hamburgerMenuItem) < 0)
                    this.hamburgerMenuItems.push(this.hamburgerMenuItem);

                if (!this.hamburgerMenuItem.position)
                    this.hamburgerMenuItem.position = this.hamburgerMenuItems.length;

                this.setSubcategoryPositions();
                this.setLabels();
            });

        }

        onChangeMainCategoryName(item: any) {
            this.updateCode(item);
        }

        countCode(code: string) {
            var counter = 0;

            if (this.hamburgerMenuItems && code){
                for (var i = 0; i < this.hamburgerMenuItems.length; i++) {
                    if (this.hamburgerMenuItems[i] &&
                        this.hamburgerMenuItems[i].code &&
                        this.hamburgerMenuItems[i].code.toLocaleLowerCase() === code.toLocaleLowerCase()) {
                        counter++;
                    }
                }
            }

            return counter;
        }

        itemWithDuplicatedCode() {
            return this.countCode(this.hamburgerMenuItem.code) > 1;
        }

        onPositionChanged(livePositionChange: boolean, changed: any, array?: any[]) {
            if (livePositionChange)
                this.rearrangeUtils.rearrangePositions(changed, array || this.hamburgerMenuItem.items);
        }

        getPositionText(Position: string) {
            return 'Position ' + (+Position + 1);
        }

        saveFirm(): ng.IPromise<any> {

            this.hamburgerMenuItem = this.updateCode(this.hamburgerMenuItem);
            if (this.livePositionChange1) {
                this.onPositionChanged(this.livePositionChange1, this.hamburgerMenuItem, this.hamburgerMenuItems);
            } else {
                this.sortMainCategory();
                this.sortSubCategory();
            }


            return this.hamburgerMenuService.saveFirm(this.firm);
        }
        
        sortMainCategory() {

            if (!angular.isObject(this.hamburgerMenuItems)) return;

            for (let index = 0; index < this.hamburgerMenuItems.length; index++) {

                if (this.hamburgerMenuItems[index].hasOwnProperty("position")) {
                    let pos: any = this.hamburgerMenuItems[index].position;
                    let tmp = this.hamburgerMenuItems[pos - 1];
                    this.hamburgerMenuItems[pos - 1] = this.hamburgerMenuItems[index];
                    this.hamburgerMenuItems[index] = tmp;
                }
            }

        }

        sortSubCategory() {

            if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items)) return;

            var array: any = [];

            for (var item in this.hamburgerMenuItem.items) {
                this.hamburgerMenuItem.items[item].items = this.sortSubCategoryLink(this.hamburgerMenuItem.items[item].items);
                array.push(this.hamburgerMenuItem.items[item]);
            }

            array.sort(function (a, b) {
                return (a["position"] > b["position"] ? 1 : -1);
            });
            this.hamburgerMenuItem.items = array;

        }

        sortSubCategoryLink(items: any) {

            if (!angular.isObject(items)) return items;

            var array: any = [];
            for (let item of items) {
                array.push(item);
            }

            array.sort(function (a, b) {
                return (a["position"] > b["position"] ? 1 : -1);
            });

            return array;
        }

        setSubcategoryPositions() {
            if (!angular.isDefined(this.hamburgerMenuItem || !angular.isDefined(this.hamburgerMenuItem.items)))
                return;

            if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items)) return;

            let index = 1;
            for (let item of this.hamburgerMenuItem.items) {
                item.position = index;

                if (angular.isDefined(item.items)) {
                    let subIndex = 1;
                    for (let subItem of item.items) {
                        subItem["position"] = subIndex;
                        subIndex++;
                    }
                }

                index++;
            }
        }

        updateCode(menuItem: ICategory | ISubcategory): ICategory | ISubcategory {

            let self = this;
            if (menuItem.title) menuItem.code = menuItem.title.replace(/ /g, "");

            if (menuItem.items) {

                for (let item of menuItem.items) {
                    self.updateCode(item);
                }
            }
            return menuItem;
        }

        delete(hamburgerMenuItem: components.hamburgerMenu.ICategory): void {
            let self = this;
            self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, hamburgerMenuItem);
        }

        onRemoveGroup(group: string, category: ICategory | ISubcategory): void {

            var groupIndex = category.groups.indexOf(group);
            if (groupIndex !== -1) {
                category.groups.splice(groupIndex, 1);
            }

            this.saveFirm().then(() => {

            });
        }

        countPosition(position: number, items: ICategory[] | ISubcategory[]): number {
            var counter = 0;
            if (items) {
                for (var i = 0; i < items.length; i++) {
                    if (items[i] && items[i].position && items[i].position === position)
                        counter++;
                }
            }

            return counter;
        }

        goTo(location: string): void {
            let self = this;

            self.isSubmited = true;
            if (location === 'MainList') {
                if (self.page === "create") {
                    self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, self.hamburgerMenuItem)
                        .then(() => {
                            self.$location.path('hamburgerMenu');
                        });
                } else {
                    self.$location.path('hamburgerMenu');
                }
            } else if (location === 'Save') {
                self.saveFirm()
                    .then(() => {
                        self.$location.path('hamburgerMenu');
                    }, error => {
                        self.isSubmited = false;
                        this.alertService.show({
                            buttons: app.components.alert.AlertButtons.Accept,
                            title: error.statusText,
                            message: error.data.message,
                            dismissText: "Ok"
                        });
                    });

            } else {

                self.saveFirm().then(() => {
                    self.$location.path('hamburgerMenu/' + self.page + '/' + self.$routeParams.firm + '/' + self.hamburgerMenuItem.code + '/' + location);
                });
            }
        }

        addNewItem(category: ICategory | ISubcategory): void {
            if (!category.items) {
                category.items = [];
            }

            category.items.push({ position: category.items.length + 1 });
            this.labels[this.labels.length] = "Sub - category " + (this.labels.length + 1);
        }

        deleteItem(category: ICategory | ISubcategory, subcategory: ICategoryBase<ISubcategory>, labelIndex: number): void {

            for (let index = 0; index < category.items.length; index++) {
                if (category.items[index].title === subcategory.title) {
                    category.items.splice(index, 1);
                    this.labels.splice(labelIndex, 1);
                    this.setLabels();
                    this.updateSubcategory(category, index, subcategory.position);
                    break;
                }
            }
        }

        setLabels(): void {

            if (!angular.isDefined(this.hamburgerMenuItem.items)) {
                return;
            }

            this.labels = [this.hamburgerMenuItem.items.length > 0 ? this.hamburgerMenuItem.items.length : 1];
            if (this.hamburgerMenuItem.items.length === 0) this.labels[0] = "Sub - category 1";
            for (let i = 0; i < this.hamburgerMenuItem.items.length; i++) {
                this.labels[i] = "Sub - category " + (i + 1);
            }
        }

        updateSubcategory(category: ICategory | ISubcategory, subIndex: number, position: number) {

            let initialPosition = position;
            for (let index = subIndex; index < category.items.length; index++) {
                category.items[index].position = initialPosition;
                initialPosition += 1;
            }
        }

    }
}