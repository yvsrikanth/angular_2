﻿module app.components {
    export class adGroupValidationInputComponent {

        static $inject = ["adGraphService"];

        constructor(private adGraphService: services.adGraphService) {

        }

        groupName: string;
        placeholder: string;
        class: string;
        inputId: string;


        temporalGroupName: string;
        takedGroupName: string;
        loadingAd = false;
        required: boolean = false;
        adInputMsg: string;
        lastAdGroupSearch: string;
        hamburgerMenuItem: any;

        $onInit() {
            this.setGroupName();
        }

        setGroupName() {
            this.temporalGroupName = this.groupName || "";
            this.takedGroupName = this.groupName;

            this.onBlurAdGroup();
        }

        $doCheck() {
            if (this.groupName !== this.takedGroupName) {
                this.setGroupName();
            }
        }

        onBlurAdGroup() {
            
            this.groupName = "";
            this.takedGroupName = this.groupName;
            if (this.temporalGroupName === this.lastAdGroupSearch) {
                return;
            }
            this.adInputMsg = "";
            this.lastAdGroupSearch = this.temporalGroupName;

            if (!this.temporalGroupName) {
                return;
            }

            this.loadingAd = true;

            this.adGraphService
                .getGroups(this.temporalGroupName)
                .then(groups => {
                    this.loadingAd = false;

                    if (!groups || !groups.length) {
                        this.adInputMsg = "The AD Group is not valid";
                    } else {
                        this.groupName = this.temporalGroupName;
                        this.takedGroupName = this.temporalGroupName;

                        if (this.hamburgerMenuItem !== undefined) {

                            if (!this.hamburgerMenuItem.hasOwnProperty("groups")) {
                                this.hamburgerMenuItem.groups = [this.temporalGroupName];
                            } else {
                                let groups: string[] = this.hamburgerMenuItem.groups.map(g => { return g.toLowerCase(); });
                                if (groups.indexOf(this.temporalGroupName.toLowerCase()) === -1) this.hamburgerMenuItem.groups.push(this.temporalGroupName);
                            }

                            this.temporalGroupName = "";
                        }
                    }

                })
                .catch(() => {
                    this.loadingAd = false;
                    this.adInputMsg = `Could not validate AD Group '${this.temporalGroupName}'. Server error`;
                });
        }
    }

    var adGroupValidationInputComponentOptions: ng.IComponentOptions = {
        bindings: {
            groupName: "=",
            required: "@",
            placeholder: "@",
            inputClass: "@",
            inputId: "@",
            hamburgerMenuItem: "="
        },
        templateUrl: "/Application/components/adGroupValidationInput/adGroupValidationInput.component.html",
        controller: adGroupValidationInputComponent,
        controllerAs: "vm"
    }

    angular.module("SPApp").component("adGroupValidationInput", adGroupValidationInputComponentOptions);
}