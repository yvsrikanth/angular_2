var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var leadNews;
                (function (leadNews) {
                    var expandedLeadNewsCreateEditComponent = {
                        bindings: {},
                        controller: leadNews.expandedLeadNewsCreateEditController,
                        templateUrl: "/Application/components/news/expandedpageNews/leadNews/leadNews-create-edit/leadNews-create-edit.html",
                        controllerAs: "leadNewsEditor"
                    };
                    angular.module("SPApp").component("expandedLeadNewsEditor", expandedLeadNewsCreateEditComponent);
                })(leadNews = expandedpageNews.leadNews || (expandedpageNews.leadNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-create-edit.component.js.map