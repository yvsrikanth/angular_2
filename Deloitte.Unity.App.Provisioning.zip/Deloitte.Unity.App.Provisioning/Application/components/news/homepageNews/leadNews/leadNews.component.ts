﻿module app.directives {

    class leadNewsComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.leadNews.leadNewsComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews.html";
            this.controllerAs = "leadNews";
        }

    }

    angular.module("SPApp").component("leadNews", new leadNewsComponent());

}