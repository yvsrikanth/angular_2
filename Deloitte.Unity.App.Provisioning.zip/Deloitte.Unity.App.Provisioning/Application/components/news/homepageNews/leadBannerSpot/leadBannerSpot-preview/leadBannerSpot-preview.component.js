var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadBannerSpotPreviewComponent = (function () {
            function leadBannerSpotPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.leadBannerSpotPreviewController.leadBannerSpotPreviewComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot-preview/leadBannerSpot-preview.html";
                this.controllerAs = "leadBannerSpotPreview";
            }
            return leadBannerSpotPreviewComponent;
        }());
        angular.module("SPApp").component("leadBannerSpotPreview", new leadBannerSpotPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-preview.component.js.map