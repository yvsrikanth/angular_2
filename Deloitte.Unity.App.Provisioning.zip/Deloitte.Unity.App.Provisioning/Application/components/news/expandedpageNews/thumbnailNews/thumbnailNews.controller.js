var app;
(function (app) {
    var components;
    (function (components) {
        var expandedThumbnailNews;
        (function (expandedThumbnailNews) {
            var thumbnailNewsComponentController = (function () {
                function thumbnailNewsComponentController($scope, $rootScope, securityService) {
                    this.$scope = $scope;
                    this.$rootScope = $rootScope;
                    this.securityService = securityService;
                }
                thumbnailNewsComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.securityService.getUserPermissions().then(function (permissions) {
                        _this.userPermissions = permissions;
                        _this.firms = Object.keys(_this.userPermissions).sort();
                    });
                };
                return thumbnailNewsComponentController;
            }());
            thumbnailNewsComponentController.$inject = ["$scope", "$rootScope", "securityService"];
            expandedThumbnailNews.thumbnailNewsComponentController = thumbnailNewsComponentController;
        })(expandedThumbnailNews = components.expandedThumbnailNews || (components.expandedThumbnailNews = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews.controller.js.map