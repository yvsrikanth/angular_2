var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var thumbnailNews;
                (function (thumbnailNews) {
                    var expandedThumbnailNewsCreateEditController = (function (_super) {
                        __extends(expandedThumbnailNewsCreateEditController, _super);
                        function expandedThumbnailNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            return _super.call(this, 
                            // Injected dependencies
                            rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, 
                            /*pageTitleOnEditAll*/ "Edit thumbnail news layout", 
                            /*pageTitleOnEditById*/ "Edit thumbnail news", 
                            /*pageTitleOnCreate*/ "Create thumbnail news", 
                            /*maxItems*/ 14, 
                            /*region*/ "Thumbnail-newstab", 
                            /*listPath*/ "/news/expandedpageNews/thumbnailNews") || this;
                        }
                        return expandedThumbnailNewsCreateEditController;
                    }(news.genericNewsCreateEditController));
                    expandedThumbnailNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    thumbnailNews.expandedThumbnailNewsCreateEditController = expandedThumbnailNewsCreateEditController;
                })(thumbnailNews = expandedpageNews.thumbnailNews || (expandedpageNews.thumbnailNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-create-edit.controller.js.map