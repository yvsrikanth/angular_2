var app;
(function (app) {
    var directives;
    (function (directives) {
        var newsItemComponent = (function () {
            function newsItemComponent() {
                this.bindings = {
                    item: "<",
                    title: "@",
                    titlePrimaryImage: "@",
                    titlePrimaryNews: "@",
                    subtitleNews: "@",
                    showThumbnail: "=",
                    showContent: "=",
                    titleUrl: "@",
                    showPosition: "="
                };
                this.controller = app.newsItemController.newsItemComponentController;
                this.templateUrl = "/Application/components/newsItem/newsItem.component.html";
                this.controllerAs = "newsItem";
            }
            return newsItemComponent;
        }());
        angular.module("SPApp").component("newsItem", new newsItemComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=newsItem.component.js.map