﻿module app.directives {


    var notificationCreateEditComponent: ng.IComponentOptions = {

        bindings: {
        },
        controller: components.notificationCreateEditController.notificationCreateEditController,
        templateUrl: '/Application/components/notifications/notification-create-edit/notification-create-edit.html',
        controllerAs: "notificationCreateEditCtrl"
    }
    angular.module('SPApp').component('notificationCreateEdit', notificationCreateEditComponent);
}