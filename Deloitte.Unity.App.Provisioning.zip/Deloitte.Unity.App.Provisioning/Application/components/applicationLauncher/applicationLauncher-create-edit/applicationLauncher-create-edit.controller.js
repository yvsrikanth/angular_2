var app;
(function (app) {
    var applicationLauncherCreateEditController;
    (function (applicationLauncherCreateEditController_1) {
        var applicationLauncherCreateEditController = (function () {
            function applicationLauncherCreateEditController($scope, applicationLauncherService, contentTargetingService, $location, $routeParams, alertService, rearrangeUtils) {
                this.$scope = $scope;
                this.applicationLauncherService = applicationLauncherService;
                this.contentTargetingService = contentTargetingService;
                this.$location = $location;
                this.$routeParams = $routeParams;
                this.alertService = alertService;
                this.rearrangeUtils = rearrangeUtils;
                this.applicationLauncherList = [];
                this.applist = [];
                this.isSubmit = false;
                this.veiwedPreview = false;
                this.previewWrng = '';
                this.livePositionChange = true;
                this.ordinals = new Array();
                this.regex = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
                var self = this;
                self.applicationId = this.$routeParams.id;
                self.actionType = this.checkIfIdPresent();
                self.firm = this.$routeParams.firm;
                self.getApplicationLauncherList(0, 8);
            }
            applicationLauncherCreateEditController.prototype.$onInit = function () {
            };
            applicationLauncherCreateEditController.prototype.checkUrlFilter = function (s) {
                if (s) {
                    if (!s.match(/^[a-zA-Z]+:\/\//)) {
                        s = 'http://' + s;
                    }
                    return s;
                }
            };
            applicationLauncherCreateEditController.prototype.checkIfIdPresent = function () {
                var self = this;
                var actionType;
                var id = this.$routeParams.id;
                if (id) {
                    if (id.toLowerCase() === "all") {
                        self.headerTitle = 'Edit application layout';
                        actionType = "editAll";
                    }
                    else {
                        self.headerTitle = 'Edit Application';
                        actionType = "edit";
                        self.appId = id;
                    }
                }
                else {
                    self.headerTitle = 'Add Application';
                    actionType = "create";
                }
                return actionType;
            };
            applicationLauncherCreateEditController.prototype.getApplicationLauncherList = function (skip, take) {
                var _this = this;
                var self = this;
                var rightNow = new Date();
                var i = 0;
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.applicationLauncherService.getPageList(skip, take, self.firm).then(function (data) {
                    self.applicationLauncherList = data.items[0];
                    if (_this.actionType === "create") {
                        self.applist.push({
                            ordinal: 1,
                            title: "",
                            url: ""
                        });
                        i = 1;
                    }
                    else if (_this.actionType === "editAll") {
                        i = 0;
                    }
                    for (var j = 0; j < self.applicationLauncherList.navigation.appLauncher.length; j++) {
                        var obj = {
                            ordinal: j + i + 1,
                            title: self.applicationLauncherList.navigation.appLauncher[j].title,
                            url: self.applicationLauncherList.navigation.appLauncher[j].url
                        };
                        self.applist.push(obj);
                    }
                    for (var i = 0; i < self.applist.length; i++) {
                        _this.ordinals.push(i + 1);
                    }
                });
            };
            applicationLauncherCreateEditController.prototype.onClear = function (item) {
                item.title = "";
                item.url = "";
                item.ordinal = '';
            };
            applicationLauncherCreateEditController.prototype.insertNewApplication = function () {
                var self = this;
                self.applist.push({
                    ordinal: self.applist.length + 1,
                    title: "",
                    url: ""
                });
                this.ordinals.push(self.applist.length);
            };
            //Method called when clicked Preivew layout icon.
            applicationLauncherCreateEditController.prototype.updatePreview = function () {
                var self = this;
                this.isSubmit = false;
                var changedId = 0;
                self.veiwedPreview = true;
                if (self.actionType === "edit") {
                    for (var i = 0; i < self.applicationLauncherList.navigation.appLauncher.length; i++) {
                        if (self.applicationLauncherList.navigation.appLauncher[i].title === self.appId) {
                            changedId = i;
                        }
                    }
                    var changedItem = self.applist[changedId];
                    self.applist.splice(changedId, 1);
                    self.applist.splice(changedItem.ordinal, 0, changedItem);
                    changedId = changedItem.ordinal;
                }
                else {
                    self.applist.sort(function (a, b) {
                        return (a.ordinal - b.ordinal);
                    });
                }
                self.applicationLauncherList.navigation.appLauncher = [];
                angular.copy(self.applist, self.applicationLauncherList.navigation.appLauncher);
                if (self.actionType === "edit") {
                    self.appId = self.applicationLauncherList.navigation.appLauncher[changedId].title;
                }
            };
            applicationLauncherCreateEditController.prototype.updateRecords = function (form) {
                var _this = this;
                var self = this;
                self.isSubmit = true;
                if (form.$valid) {
                    var applicationlist = self.applicationLauncherList.navigation.appLauncher.filter(function (item) {
                        return item.ordinal !== '';
                    });
                    self.applicationLauncherList.navigation.appLauncher = applicationlist;
                    self.applicationLauncherList.navigation.appLauncher.map(function (item) {
                        delete item.ordinal;
                    });
                    if (self.veiwedPreview) {
                        self.applicationLauncherService
                            .deleteApplicationItem(self.applicationLauncherList.id, self.applicationLauncherList)
                            .then(function () {
                            self.$location.path("applicationLauncher");
                        }, function (response) {
                            self.isSubmit = false;
                            if (response.status === 400) {
                                _this.errorMessage = response.data.message;
                            }
                            else {
                                _this.alertService.show({
                                    buttons: app.components.alert.AlertButtons.Accept,
                                    title: response.statusText,
                                    message: response.data.message,
                                    dismissText: "Ok"
                                });
                            }
                        });
                    }
                    else {
                        // please preview the app !
                        self.previewWrng = " Please preview the applisting !";
                    }
                }
            };
            applicationLauncherCreateEditController.prototype.verifyDuplicate = function (index, item) {
                var selectedValue = item.ordinal;
                var self = this;
                var sorted, i, isDuplicate;
                var obj = {
                    ordinal: selectedValue
                };
                if (this.livePositionChange) {
                    this.rearrangeUtils.rearrangeOrdinals(item, self.applist);
                    return false;
                }
                sorted = self.applist.concat().sort(function (a, b) {
                    if (a.ordinal > b.ordinal)
                        return 1;
                    if (a.ordinal < b.ordinal)
                        return -1;
                    return 0;
                });
                for (i = 0; i < self.applist.length; i++) {
                    isDuplicate = ((sorted[i - 1] && sorted[i - 1].ordinal === sorted[i].ordinal) || (sorted[i + 1] && sorted[i + 1].ordinal === sorted[i].ordinal));
                    sorted[i].form.position.$setValidity('duplicate', !isDuplicate);
                }
            };
            ;
            return applicationLauncherCreateEditController;
        }());
        applicationLauncherCreateEditController.$inject = [
            "$scope", "applicationLauncherService", "contentTargetingService", "$location", "$routeParams", "alertService", "rearrangeUtils"
        ];
        applicationLauncherCreateEditController_1.applicationLauncherCreateEditController = applicationLauncherCreateEditController;
    })(applicationLauncherCreateEditController = app.applicationLauncherCreateEditController || (app.applicationLauncherCreateEditController = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-create-edit.controller.js.map