var app;
(function (app) {
    var contentTargetingListController;
    (function (contentTargetingListController) {
        var contentTargetingListComponentController = (function () {
            function contentTargetingListComponentController($scope, $rootScope, contentTargetingService, securityService, $routeParams, alertService, userAttributesService, userService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.contentTargetingService = contentTargetingService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
                this.alertService = alertService;
                this.userAttributesService = userAttributesService;
                this.userService = userService;
                this.sortCol = "DisplayName";
                this.asc = true;
            }
            contentTargetingListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.itemsPerPage = 8;
                this.query = {
                    skip: 0, take: this.itemsPerPage
                };
                this.fetchAttributes();
                this.contentTarget(0, this.itemsPerPage);
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                });
            };
            contentTargetingListComponentController.prototype.sort = function (col) {
                if (col === this.sortCol) {
                    this.asc = !this.asc;
                }
                else {
                    this.sortCol = col;
                    this.asc = true;
                }
                this.contentTarget(this.currentPage, this.itemsPerPage);
            };
            contentTargetingListComponentController.prototype.getSortExpression = function () {
                return (this.asc ? '' : '-') + this.sortCol;
            };
            contentTargetingListComponentController.prototype.fetchAttributes = function () {
                var _this = this;
                this.userAttributesService.get()
                    .then(function (allAttributes) {
                    _this.allAttributes = allAttributes.items;
                });
            };
            contentTargetingListComponentController.prototype.contentTarget = function (skip, take) {
                var _this = this;
                var self = this;
                var rightNow = new Date();
                this.currentPage = skip;
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                this.listAuthors = null;
                self.contentTargetingService.getContentTarget(this.firm, skip, take, this.getSortExpression()).then(function (data) {
                    self.contentTargetItem = data.items;
                    self.totalCount = data.totalCount;
                    for (var i = 0; i < _this.contentTargetItem.length; i++) {
                        _this.contentTargetItem[i].created =
                            new Date(_this.contentTargetItem[i].created).toISOString().slice(0, 10);
                    }
                    self.contentTargetingService.memberFirmData().then(function (memberData) {
                        angular.forEach(memberData.items, function (memberFirmValue) {
                            angular.forEach(data.items, function (value1) {
                                if (value1.firm === memberFirmValue.key) {
                                    value1.firm = memberFirmValue.name;
                                }
                            });
                        });
                    });
                    var ids = _this.contentTargetItem
                        .filter(function (item) { return item.modifiedBy && item.modifiedBy.toUpperCase() !== "SYSTEM" && item.modifiedBy.toUpperCase() !== "JOBS"; })
                        .map(function (i) { return i.modifiedBy; })
                        .filter(function (v, i, a) { return a.indexOf(v) === i; });
                    _this.getAuthors(ids);
                });
            };
            contentTargetingListComponentController.prototype.getAttrName = function (id) {
                if (this.allAttributes) {
                    if (this.allAttributes.length) {
                        var match = this.allAttributes.filter(function (a) { return a.id === id; })[0];
                        if (match)
                            return match.displayName;
                    }
                }
                else {
                    return "";
                }
                return id;
            };
            contentTargetingListComponentController.prototype.getAttributeData = function (data) {
                this.attributesData = data.rules;
                this.displayTitle = data.displayName;
            };
            contentTargetingListComponentController.prototype.gotoCreateAudience = function (params) {
                if (params.firm) {
                    this.contentTargetingService.setFirm(params.firm);
                }
                if (params.audienceID) {
                    this.contentTargetingService.setAudienceId(params.audienceID);
                }
            };
            contentTargetingListComponentController.prototype.getAuthors = function (ids) {
                var _this = this;
                var idsStr = ids.join(",");
                this.userService
                    .getUserList(idsStr)
                    .then(function (data) {
                    _this.listAuthors = data.items;
                })
                    .catch(function (error) {
                    _this.listAuthors = [];
                });
            };
            contentTargetingListComponentController.prototype.getAuthorName = function (id) {
                if (this.listAuthors) {
                    if (this.listAuthors.length) {
                        var author = this.listAuthors.filter(function (a) { return a.id === id; })[0];
                        if (author)
                            return author.attributes.name.first + " " + author.attributes.name.last;
                    }
                }
                else {
                    return "";
                }
                return id;
            };
            contentTargetingListComponentController.prototype.deleteAttribute = function (data) {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: 'Delete an entry',
                    message: 'The selected entry will be deleted. This action cannot be undone',
                    dismissText: 'Cancel',
                    confirmText: 'Delete',
                    onConfirm: function () {
                        _this.contentTargetingService.deleteAudience(data)
                            .then(function () {
                            _this.contentTargetItem.splice(_this.contentTargetItem.indexOf(data), 1);
                            _this.contentTarget(_this.currentPage, _this.itemsPerPage);
                            _this.alertService.close();
                        }, function (err) {
                            _this.alertService.show({
                                buttons: app.components.alert.AlertButtons.Accept,
                                title: err.statusText !== "" ? err.statusText : "Server error",
                                message: err.data !== null ? err.data.message : "Server error",
                                dismissText: "Ok"
                            });
                        });
                    }
                });
            };
            return contentTargetingListComponentController;
        }());
        contentTargetingListComponentController.$inject = ['$scope', '$rootScope', 'contentTargetingService', 'securityService', '$attrs', 'alertService', 'userAttributesService', 'userService'];
        contentTargetingListController.contentTargetingListComponentController = contentTargetingListComponentController;
    })(contentTargetingListController = app.contentTargetingListController || (app.contentTargetingListController = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-list.controller.js.map