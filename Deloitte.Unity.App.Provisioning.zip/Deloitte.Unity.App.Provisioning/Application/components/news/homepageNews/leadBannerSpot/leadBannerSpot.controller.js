var app;
(function (app) {
    var components;
    (function (components) {
        var leadBannerSpot;
        (function (leadBannerSpot) {
            var leadBannerSpotComponentController = (function () {
                function leadBannerSpotComponentController($scope, $rootScope, securityService) {
                    this.$scope = $scope;
                    this.$rootScope = $rootScope;
                    this.securityService = securityService;
                }
                leadBannerSpotComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.securityService.getUserPermissions().then(function (permissions) {
                        _this.userPermissions = permissions;
                        _this.firms = Object.keys(_this.userPermissions).sort();
                    });
                };
                return leadBannerSpotComponentController;
            }());
            leadBannerSpotComponentController.$inject = ["$scope", "$rootScope", "securityService"];
            leadBannerSpot.leadBannerSpotComponentController = leadBannerSpotComponentController;
        })(leadBannerSpot = components.leadBannerSpot || (components.leadBannerSpot = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot.controller.js.map