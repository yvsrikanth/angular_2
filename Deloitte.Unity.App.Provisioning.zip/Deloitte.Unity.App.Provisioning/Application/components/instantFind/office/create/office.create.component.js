var app;
(function (app) {
    var directives;
    (function (directives) {
        var officeCreateComponent = (function () {
            function officeCreateComponent() {
                this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
                this.templateUrl = '/Application/components/instantFind/office/create/office.create.html';
                this.controllerAs = "instantFindCtrl";
            }
            return officeCreateComponent;
        }());
        angular.module('SPApp').component('officeCreate', new officeCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=office.create.component.js.map