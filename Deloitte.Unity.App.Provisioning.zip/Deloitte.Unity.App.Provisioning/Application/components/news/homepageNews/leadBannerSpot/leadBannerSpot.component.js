var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadBannerSpotComponent = (function () {
            function leadBannerSpotComponent() {
                this.controller = app.components.leadBannerSpot.leadBannerSpotComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot.component.html";
                this.controllerAs = "leadBannerSpot";
            }
            return leadBannerSpotComponent;
        }());
        angular.module("SPApp").component("leadBannerSpot", new leadBannerSpotComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot.component.js.map