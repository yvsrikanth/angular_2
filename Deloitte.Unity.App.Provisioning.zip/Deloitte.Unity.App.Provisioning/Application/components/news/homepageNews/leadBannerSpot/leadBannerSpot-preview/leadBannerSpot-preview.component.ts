﻿module app.directives {

    class leadBannerSpotPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = leadBannerSpotPreviewController.leadBannerSpotPreviewComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot-preview/leadBannerSpot-preview.html";
            this.controllerAs = "leadBannerSpotPreview";
        }

    }

    angular.module("SPApp").component("leadBannerSpotPreview", new leadBannerSpotPreviewComponent());

}