var app;
(function (app) {
    var hamburgerMenuListController;
    (function (hamburgerMenuListController) {
        var hamburgerMenuListComponentController = (function () {
            function hamburgerMenuListComponentController(hamburgerMenuService, securityService, userService) {
                this.hamburgerMenuService = hamburgerMenuService;
                this.securityService = securityService;
                this.userService = userService;
                var self = this;
                var rightNow = new Date();
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.itemsPerPage = 8;
                self.query = {
                    skip: 0, take: self.itemsPerPage
                };
                self.getHamburgerMenu();
            }
            hamburgerMenuListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                });
                this.reverse = false;
                this.sortColumn = "title";
            };
            hamburgerMenuListComponentController.prototype.getHamburgerMenu = function () {
                var _this = this;
                var self = this;
                self.hamburgerMenuService.getFirmByKey(self.firmKey).then(function (result) {
                    self.firm = result.items[0];
                    self.allHamburgerMenuItems = self.firm.navigation.mainMenu;
                    self.totalCount = self.allHamburgerMenuItems.length;
                    self.sortBy(_this.sortColumn);
                    //self.hamburgerMenu(0, self.itemsPerPage);
                });
            };
            hamburgerMenuListComponentController.prototype.hamburgerMenu = function (skip, take) {
                var self = this;
                this.query = {
                    skip: skip, take: take
                };
                self.hamburgerMenuItems = self.allHamburgerMenuItems.slice(skip, skip + take);
            };
            hamburgerMenuListComponentController.prototype.setAuthorNameAndCreate = function () {
                var _this = this;
                if (!this.firm || this.firm.length <= 0)
                    return;
                if (this.firm.createdBy.toUpperCase() === "SYSTEM" || this.firm.createdBy.toUpperCase() === "JOBS" || this.firm.createdBy === "") {
                    this.hamburgerMenuItems["createdBy"] = this.firm.createdBy;
                }
                else {
                    this.userService.getUserList(this.firm.createdBy).then(function (data) {
                        if (data.items.length > 0) {
                            _this.hamburgerMenuItems["createdBy"] = data.items[0].attributes.name.first + " " + data.items[0].attributes.name.last;
                        }
                        else {
                            _this.hamburgerMenuItems["createdBy"] = _this.firm.createdBy;
                        }
                    });
                }
                this.hamburgerMenuItems["created"] = new Date(this.firm.created).toISOString().slice(0, 10);
            };
            hamburgerMenuListComponentController.prototype.getSubcategoryText = function (items) {
                var total = items ? items.length : 0;
                if (total === 1) {
                    return items[0].title;
                }
                return total + ' items';
            };
            hamburgerMenuListComponentController.prototype.getSubcategoryLinkText = function (items) {
                var total = 0;
                var firstLinkText = '';
                for (var index = 0; items && index < items.length; index++) {
                    if (items[index].items != undefined) {
                        if (firstLinkText === '') {
                            firstLinkText = items[index].items[0].title;
                        }
                        total += items[index].items.length;
                    }
                }
                if (total === 1) {
                    return firstLinkText;
                }
                return total + ' items';
            };
            hamburgerMenuListComponentController.prototype.delete = function (hamburgerMenuItem) {
                var _this = this;
                var self = this;
                self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, hamburgerMenuItem)
                    .then(function () {
                    self.allHamburgerMenuItems.splice(_this.allHamburgerMenuItems.indexOf(hamburgerMenuItem), 1);
                    self.hamburgerMenuItems.splice(_this.hamburgerMenuItems.indexOf(hamburgerMenuItem), 1);
                    self.totalCount = _this.allHamburgerMenuItems.length;
                    self.hamburgerMenu(self.hamburgerMenuItems.length ? _this.query.skip : 0, self.itemsPerPage);
                });
            };
            hamburgerMenuListComponentController.prototype.sortBy = function (column) {
                this.sortColumn = column;
                if (!angular.isObject(this.allHamburgerMenuItems))
                    return;
                var array = [];
                for (var item in this.allHamburgerMenuItems) {
                    array.push(this.allHamburgerMenuItems[item]);
                }
                array.sort(function (a, b) {
                    if (a[column] === undefined || a[column] === null) {
                        a[column] = "";
                    }
                    if (!b[column] === undefined || b[column] === null) {
                        b[column] = "";
                    }
                    if (a[column].toLowerCase && b[column].toLowerCase) {
                        return (a[column].toLowerCase() > b[column].toLowerCase() ? 1 : -1);
                    }
                    else {
                        return (a[column] > b[column] ? 1 : -1);
                    }
                });
                if (this.reverse)
                    array.reverse();
                this.reverse = !this.reverse;
                this.allHamburgerMenuItems = array;
                this.hamburgerMenu(0, this.itemsPerPage);
            };
            return hamburgerMenuListComponentController;
        }());
        hamburgerMenuListComponentController.$inject = ["hamburgerMenuService", "securityService", "userService"];
        hamburgerMenuListController.hamburgerMenuListComponentController = hamburgerMenuListComponentController;
    })(hamburgerMenuListController = app.hamburgerMenuListController || (app.hamburgerMenuListController = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-list.controller.js.map