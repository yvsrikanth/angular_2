var app;
(function (app) {
    var moduleAccessController;
    (function (moduleAccessController) {
        var moduleAccessComponentController = (function () {
            function moduleAccessComponentController($scope, $rootScope, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.securityService = securityService;
            }
            moduleAccessComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firms = Object.keys(_this.userPermissions).sort();
                });
            };
            return moduleAccessComponentController;
        }());
        moduleAccessComponentController.$inject = ["$scope", "$rootScope", "securityService"];
        moduleAccessController.moduleAccessComponentController = moduleAccessComponentController;
    })(moduleAccessController = app.moduleAccessController || (app.moduleAccessController = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess.controller.js.map