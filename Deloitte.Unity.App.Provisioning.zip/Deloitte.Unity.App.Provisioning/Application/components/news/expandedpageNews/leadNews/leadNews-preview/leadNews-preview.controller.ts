﻿module app.expandedLeadNewsPreviewController {

    export class leadNewsPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];

        id: string;
        firm: string;
        edit: boolean;
        leadNewsItem: any[];
        selectedItem: any;
        showTitle: boolean;
        userPermissions: security.shared.IModulePermissions;

        constructor(
            private $scope,
            private $rootScope,
            private $routeParams,
            private newsService: services.newsService,
            private $location,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService
        ) {}

        $onInit() {

            this.leadNewsItem = [];
            for (var itemIndex = 0; itemIndex < 2; itemIndex++) {
                this.leadNewsItem.push(components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "Lead"));
            }
            this.setLeadNewsParams();
            this.getDetailsLeadNewsItem();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setLeadNewsParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
            }

            if (angular.isDefined(this.$routeParams.edit)) {
                this.edit = this.$routeParams.edit;
            }
        }

        setItemsOnPositions(items: components.news.INewsArticleData[]) {
            if (items.length) {
                var layout = items[0].layout;
                for (var i = 0; i < this.leadNewsItem.length; i++) {
                    this.leadNewsItem[i].layout = layout;
                }
            }
            components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.leadNewsItem);
        }

        getDetailsLeadNewsItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllLeadNewsData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestLeadNewsItem();
                return;
            }

        }

        requestAllLeadNewsData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "Lead", take: 2 }).then(result => {
                this.setItemsOnPositions(result.items);
            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        requestLeadNewsItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.setItemsOnPositions([data]);
                this.setSelectedItem();
            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.setItemsOnPositions([item]);
                }, response => {
                    this.redirectToHome(response.statusText);
                    });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {

            this.selectedItem = this.leadNewsItem[0];
            if (!angular.isDefined(this.firm)) { this.firm = this.selectedItem.firm; }
            this.showTitle = this.leadNewsItem.length > 1;
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/expandedpageNews/leadNews");
        }

    }
}