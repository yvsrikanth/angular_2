﻿module app.components.accordionItem {
    export class accordionItemComponent implements ng.IComponentController {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;
        transclude: boolean;

        constructor() {
            this.bindings = {
                expanded: "<",
                itemTitle: "@",
                id: "@",
                parentId: "@"
            };
            this.controller = accordionItem.accordionItemComponentController;
            this.templateUrl = "/Application/components/accordionItem/accordionItem.component.html";
            this.controllerAs = "accordionItem";
            this.transclude = true;
        }
    }
    angular.module("SPApp").component("accordionItem", new accordionItemComponent());
}