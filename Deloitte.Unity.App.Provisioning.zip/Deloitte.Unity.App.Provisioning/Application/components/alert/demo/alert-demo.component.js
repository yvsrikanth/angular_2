angular.module("SPApp")
    .component("alertDemo", {
    template: "\n                <div>\n                    <table>\n                        <thead>\n                            <tr>\n                                <th>Ejemplo</th>\n                                <th>Descripcion</th>\n                            </tr>\n                        </thead>\n                        <tbody>\n                            <tr>\n                                <td>\n                                    <button role=\"button\" ng-click=\"onInfoClick()\">Info con click</button>\n                                </td>\n                                <td>\n                                    Mostrar mensajes de informaci\u00F3n y maneja onDismiss para saber cuando se ha presionado el boton Principal\n                                </td>\n                            </tr>\n                            <tr>\n                                <td>\n                                    <button role=\"button\" ng-click=\"onInfo()\">Info</button>\n                                </td>\n                                <td>\n                                    Mostrar mensajes de informaci\u00F3n, como confirmaciones o instrucciones\n                                </td>\n                            </tr>\n                            <tr>\n                                <td>\n                                    <button role=\"button\" ng-click=\"onError()\">Error</button>\n                                </td>\n                                <td>\n                                    Mostrar mensajes de error\n                                </td>\n                            </tr>\n                            <tr>\n                                <td>\n                                    <button role=\"button\" ng-click=\"onConfirm()\">Confirmacion</button>\n                                </td>\n                                <td>\n                                    Solicitar confirmaci\u00F3n del usuario\n                                </td>\n                            </tr>\n                            <tr>\n                                <td>\n                                    <button role=\"button\" ng-click=\"onLoad()\">Bloquear</button>\n                                </td>\n                                <td>\n                                    Congela la experiecia de usuario, por ejemplo mientras se completa una petici\u00F3n\n                                </td>\n                            </tr>\n                        </tbody>\n                    </table>\n                </div>",
    controller: function ($scope, alertService) {
        $scope.onInfoClick = function () {
            alertService.show({
                buttons: app.components.alert.AlertButtons.Accept,
                title: "Listo",
                message: "Se han guardado los datos exitosamente",
                dismissText: "Aceptar",
                onDismiss: function () {
                    alert("Has cerrado el modal");
                }
            });
        };
        $scope.onInfo = function () {
            alertService.show({
                buttons: app.components.alert.AlertButtons.Accept,
                title: "Listo",
                message: "Se han guardado los datos exitosamente",
                dismissText: "Aceptar"
            });
        };
        $scope.onError = function () {
            alertService.show({
                buttons: app.components.alert.AlertButtons.Accept,
                title: "Error",
                message: "No se pudo completar la operación.",
                dismissText: "Aceptar"
            });
        };
        $scope.onConfirm = function () {
            alertService.show({
                buttons: app.components.alert.AlertButtons.AcceptCancel,
                title: "Advertencia",
                message: "No podra deshacer esta opción. ¿Está seguro que desea continuar?",
                dismissText: "Cancelar",
                confirmText: "Continuar",
                onConfirm: function () {
                    $scope.onLoad();
                }
            });
        };
        $scope.onLoad = function () {
            alertService.show({
                buttons: app.components.alert.AlertButtons.None,
                title: "Eliminando",
                message: "Esto puede tomar unos segundos...",
                noDismiss: true
            });
            setTimeout(function () {
                $scope.$apply(function () {
                    $scope.onInfo();
                });
            }, 3000);
        };
    }
});
//# sourceMappingURL=alert-demo.component.js.map