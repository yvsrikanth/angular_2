var app;
(function (app) {
    var directives;
    (function (directives) {
        var officeEditComponent = (function () {
            function officeEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/office/edit/office.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return officeEditComponent;
        }());
        angular.module('SPApp').component('officeEdit', new officeEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=office.edit.component.js.map