﻿module app.pageTitleListController {


    export class pageTitleListComponentController {

        static $inject = ['$scope', '$rootScope', 'contentTargetingService', 'securityService', '$attrs', 'alertService', 'pageTitleService'];

        public pageListItems: any;
        public firm: any;
        public itemsPerPage: Number;
        public query: any;
        public totalCount: any;
        public memberFirm: String;
        public dateForToday: any;
        public userPermissions: security.shared.IFirmPermissions;
        public attrs: any;
        public regionType: String;
        public displayOneList: any = [];
        public errorMessage: String;

        public columns: any;

        isNew: boolean;

        http: ng.IHttpService;

        constructor(private $scope, private $rootScope, private contentTargetingService: services.contentTargetingService,
            private securityService: security.shared.securityService,
            private $attrs: ng.IAttributes, private alertService: components.alert.alertService, private pageTitleService: services.pageTitleService) {
            let self = this;
            self.attrs = $attrs;

            self.itemsPerPage = 8;
            self.query = {
                skip: 0,
                take: self.itemsPerPage

            };

        }

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
            });

            this.getPageListData(0, this.itemsPerPage);
            
        }

        getPageListData(skip, take) {
            let self = this;

            var rightNow = new Date();
            self.dateForToday = rightNow.toISOString().slice(0, 10);

            self.pageTitleService.getPageList(skip, take, self.firm).then((data: any) => {

                self.pageListItems = data.items;
                if (self.pageListItems.length > 0) {
                    self.displayOneList = [];
                    self.displayOneList.push(self.pageListItems[0]);
                    this.isNew = self.displayOneList[0].newsPageTitle ? false : true;
                }
                
            });
        }

        deletePageTitle(data) {
            let self = this;
            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: 'Delete an entry',
                message: 'The selected entry will be deleted. This action cannot be undone',
                dismissText: 'Cancel',
                confirmText: 'Delete',
                onConfirm: () => {
                    data.newsPageTitle = '*';
                    self.pageTitleService.deletePageTitle(data.id, data).then(() => {
                        this.getPageListData(0, this.itemsPerPage);
                        this.alertService.close();
                    }, response => {

                        if (response.status === 400) {

                            this.errorMessage = response.data.message;

                        } else {
                            this.alertService.show({
                                buttons: app.components.alert.AlertButtons.Accept,
                                title: response.statusText,
                                message: response.data.message,
                                dismissText: "Ok"
                            });
                        }
                    });
                }
            });
        }
        gotoPageTitleCreateEdit(params) {
            if (params.firm) {
                this.contentTargetingService.setFirm(params.firm);
            }
            if (params.audienceID) {
                this.contentTargetingService.setAudienceId(params.audienceID);
            }
        }

        setFirm() {
            let self = this;
            this.contentTargetingService.setFirm(self.firm);
        }
        setFirmObj(item:any) {
            this.pageTitleService.setFirmObj(item[0]);
        }
    }
}