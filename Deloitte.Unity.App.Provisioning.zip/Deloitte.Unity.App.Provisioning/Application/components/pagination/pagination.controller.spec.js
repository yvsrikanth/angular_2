var app;
(function (app) {
    var components;
    (function (components) {
        var pagination;
        (function (pagination) {
            describe("paginationComponentController", function () {
                describe("buildPages", function () {
                    var controller;
                    //Prepare
                    beforeEach(function () {
                        controller = new pagination.paginationComponentController();
                    });
                    it("should build 1 page because size is 0", function () {
                        // Prepare
                        var skip = 10, take = 5, total = 25;
                        // Do
                        var pages = controller.buildPages(0, 5, 0);
                        //Check
                        expect(pages).toEqual([1]);
                    });
                    it("should build 5 pages because size is 25 and take is 5", function () {
                        // Prepare
                        var skip = 10, take = 5, total = 25;
                        // Do
                        var pages = controller.buildPages(skip, take, total);
                        //Check
                        expect(pages).toEqual([1, 2, 3, 4, 5]);
                    });
                    it("should build 6 pages because size is 26 and take is 5", function () {
                        // Prepare
                        var skip = 10, take = 5, total = 26;
                        // Do
                        var pages = controller.buildPages(skip, take, total);
                        //Check
                        expect(pages).toEqual([1, 2, 3, 4, 5, 6]);
                    });
                });
            });
        })(pagination = components.pagination || (components.pagination = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=pagination.controller.spec.js.map