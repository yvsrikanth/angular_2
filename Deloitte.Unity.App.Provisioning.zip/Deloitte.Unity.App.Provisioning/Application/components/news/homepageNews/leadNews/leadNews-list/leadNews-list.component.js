var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadNewsListComponent = (function () {
            function leadNewsListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.leadNewsListController.leadNewsListComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews-list/leadNews-list.component.html";
                this.controllerAs = "leadNewsList";
            }
            return leadNewsListComponent;
        }());
        directives.leadNewsListComponent = leadNewsListComponent;
        angular.module("SPApp").component("leadNewsList", new leadNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-list.component.js.map