﻿module app.contentTargetingCreateController {

    export class contentTargetingCreateComponentController {
        static $inject = ['$scope', '$rootScope', 'contentTargetingService', 'userAttributesService', 'alertService', '$http', '$compile', '$window', '$location', '$routeParams'];
        public attributesData: any;
        public userAttributes: any;
        public userAttrValues: any;
        public userAttrDisplayName: String;
        public userAttrValueName: String;
        public userAttrDetails: any = [];
        public userAttrOperatorName: String;
        public errorMsgDuplicateAttr: String;
        public editAudienceId: String;
        public memberFirmName: String = '';
        public duplicateAudienceError: String;
        public validateFormField: Boolean = false;
        public displayTitle: String;
        public actionType: String;
        public headerTitle: String;
        public audienceId: string;
        public isNew = false;
        public validateFormFieldDuplicated = [false];
        isSubmited: boolean = false;


        http: ng.IHttpService;
        window: any;
        location: ng.ILocationService;
        //routeParams: ngRoute.$routeParams;


        constructor(
            private $scope,
            private $rootScope,
            private contentTargetingService: services.contentTargetingService,
            private userAttributesService: services.userAttributesService,
            private alertService: components.alert.alertService,
            $http: ng.IHttpService, private $compile, $window, $location: ng.ILocationService,
            private $routeParams) {
                this.http = $http;  
                this.window = $window;
                this.location = $location;

        }

        $onInit() {

            let self = this;
            self.audienceId = self.$routeParams.id;
            self.actionType = (self.audienceId) ? 'edit' : 'create';
            self.createAndEditInit();
            
        }


        createAndEditInit() {

            let self = this;
            self.userAttributesService.get().then((res) => {
                self.userAttributes = res['items'].sort((a, b) => {
                    return a.displayName.localeCompare(b.displayName);
                });
                if (self.actionType === "edit") {
                    self.isNew = false;
                    self.headerTitle = "Edit audience";
                    self.contentTargetingService.getSelectedAudiencesData(self.audienceId)
                        .then((res: any) => {
                            self.memberFirmName = res.firm;
                            self.displayTitle = res.displayName;
                            for (var i = 0; i < res.rules.length; i++) {
                                this.setAttributes(res, i);
                            }
                        });
                }
                else {
                    self.isNew = true;
                    self.memberFirmName = self.$routeParams.firm;
                    self.headerTitle = "Create new audience";
                    this.addNewsAttributes();
                }
            });
        }

        setAttributes(response, index) {
            let self = this;
            let rule = response.rules[index];
            let attr = this.userAttributes.filter(ua => {
                return ua.id === rule['attribute'];
            });
            if (attr && attr[0]) {
                let parsedRule = {
                    "attrArray": self.userAttributes,
                    "userAttr": attr[0],
                    "userAttrDisplayName": attr[0].displayName,
                    "userAttrOperatorName": rule.operator,
                    "selectedValues": rule.values,
                    "userAttrValueName": rule.values.join(',')
                }
                self.userAttrDetails.push(parsedRule);
            }

            this.sortAttributes();

        }

        addNewsAttributes() {
            let self = this;
            self.userAttrDetails.push({
                "attrArray": self.userAttributes,
                "userAttr": {},
                "userAttrDisplayName": "",
                "userAttrValueName": "",
                "selectedValues": [],
                "userAttrOperatorName": ""
            });
            self.validateFormField = false;
            this.sortAttributes();
        }

        sortAttributes() {

            if (!angular.isDefined(this.userAttrDetails) || !angular.isDefined(this.userAttrDetails[0].attrArray)) return;

            for (var item of this.userAttrDetails[0].attrArray) {
                var array: any = item.values.sort();
                item.vales = array;
            }

            
            
        }

        removeAttribute(index) {
            let self = this;
            self.userAttrDetails.splice(index, 1);
        }

        isValidRule(rule) {
            let result = false;
            if (rule.userAttrDisplayName && rule.userAttrOperatorName && rule.userAttrValueName) {
                result = true;
            }
            return result;
        }

        toggleValue(value, attribute) {
            let index = attribute.selectedValues.indexOf(value);
            if (index >= 0) {
                attribute.selectedValues.splice(index, 1);
            } else {
                attribute.selectedValues.push(value);
            }
            attribute.userAttrValueName = attribute.selectedValues.join(',');
        }

        saveAudience(form) {
            let self = this;
            let rule = [];
            self.validateFormField = true;

            this.isSubmited = true;

            angular.forEach(self.userAttrDetails, (value) => {
                if (self.isValidRule(value)) {
                    rule.push({
                        "attribute": value.userAttr.id,
                        "operator": value.userAttrOperatorName,
                        "values": value.userAttrValueName.split(',')
                    });
                }
            });


            let requestObj = {
                "displayName": self.displayTitle,
                "rules": rule
            };
            if (self.isNew) {
                requestObj['firm'] = self.memberFirmName || 'US';
            }
            if (!form.$valid) {
                this.isSubmited = false;
                return false;
            } else {

                self.contentTargetingService.contentTargetingCreate(self.audienceId, requestObj, self.isNew).then(() => {
                    window.history.back();
                }, (err) => {
                    this.isSubmited = false;
                    if (err.status === 400) {
                        self.duplicateAudienceError = err.data.message;
                    }
                    if (err.status === 500) {
                        self.alertService.show({
                            buttons: app.components.alert.AlertButtons.Accept,
                            title: "Error",
                            message: err.statusText,
                            dismissText: "Ok"
                        });
                    }
                });
            }
        }

        getAttributeIndex(attribute) {
            return this.userAttributes.map((obj, index) => {
                if (obj.id === attribute) {
                    return index;
                }
            }).filter(isFinite);

        }

        resetAttributeValue(attribute) {
            attribute.userAttrValueName = "";
            attribute.selectedValues = [];
        }

        anyDuplicatedAttribute() {
            for (var index = 0; index < this.validateFormFieldDuplicated.length; index++) {
                if (this.validateFormFieldDuplicated[index])
                    return true;
            }

            return false;
        }

        verifyDuplicate(index, selectedValue) {
            let self = this;

            self.resetAttributeValue(self.userAttrDetails[index]);
            self.validateFormFieldDuplicated[index] = false;

            for (var j = 0; j < self.userAttrDetails.length; j++) {

                if (index !== j && self.userAttrDetails[j].userAttr && self.userAttrDetails[index].userAttr.displayName === self.userAttrDetails[j].userAttr.displayName) {
                    self.validateFormFieldDuplicated[index] = true;
                }
            }
            self.userAttrDetails[index].userAttrDisplayName = selectedValue.displayName;
        };

    }
}