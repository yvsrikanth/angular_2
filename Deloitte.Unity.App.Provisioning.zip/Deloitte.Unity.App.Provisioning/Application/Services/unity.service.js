var app;
(function (app) {
    var services;
    (function (services) {
        var unitySPService = (function () {
            function unitySPService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            unitySPService.prototype.userData = function () {
                return this.$http
                    .get(this.appSettings.apiUrl + "/user/users/rperla")
                    .then(function (result) { return result.data; });
            };
            return unitySPService;
        }());
        unitySPService.$inject = ["$http", "appSettings"];
        services.unitySPService = unitySPService;
        function SPServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(unitySPService);
        }
        angular.module("SPApp").factory("unitySPService", ["$rootElement", function ($rootElement) { return SPServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=unity.service.js.map