﻿module app.headerFooterWrappers {

    export class headerFooterComponentController {
        alertItems: any = [];
        firmItems: any;
        newsHeadlineTitle: any;
        notificationsList: any = [];
        userInformation: any = {};
        memberFirmData: any;
        scLinks: any = [];
        firmKey: string;

        static $inject = ["$rootScope", "$timeout", "unityCommonService", "$element", "securityService", "userService", "firmService"];

        constructor(
            private $rootScope,
            private $timeout,
            private unityCommonService,
            private $element: ng.IRootElementService,
            private securityService: security.shared.securityService,
            private userService: app.services.userService,
            private firmService: services.firmService
        ) {

        }

        $onInit() {
            window["userApiData"] = {
                userMemberFirm: ""
            };

            this.userInformation = this.$rootScope.userInfo.profile;
            var username = this.userInformation.unique_name.split("@")[0];

            this.userService
                .getUserPermissions(username)
                .then(userPermissions => {
                    window["userGroupsArray"] = userPermissions.groups;
                });

            this.userService
                .getUser(username)
                .then((userDetails: services.IUser) => {
                    window["userAudienceArray"] = userDetails.audiences;

                    var memberFirm = "";
                    if (userDetails.attributes && userDetails.attributes.externalId) {
                        memberFirm = userDetails.attributes.externalId.memberFirm;
                    }

                    window["userApiData"].userMemberFirm = memberFirm;

                    if (!sessionStorage.getItem("firmKey"))
                        sessionStorage.setItem("firmKey", memberFirm);

                    this.firmService
                        .get(memberFirm)
                        .then(result => {
                            var resultAsArray = <services.IPaginatedResult<services.IFirmResponseItem>>result;
                            if (result.newsHeadlineTitle) {
                                this.firmItems = result;
                                this.newsHeadlineTitle = result.newsHeadlineTitle;
                            } else if (resultAsArray.items && resultAsArray.items.length) {
                                this.firmItems = resultAsArray.items[0];
                                this.newsHeadlineTitle = resultAsArray.items[0].newsHeadlineTitle;
                            }

                            if (!this.newsHeadlineTitle) {
                                this.newsHeadlineTitle = "My news";
                            }
                        });
                });

            //Alert Data method invokation by passing user Name
            this.unityCommonService
                .alertData(username)
                .then(results => {
                    this.alertItems = results.data;
                });


            window["isAdminUser"] = true;
        }
    }
}