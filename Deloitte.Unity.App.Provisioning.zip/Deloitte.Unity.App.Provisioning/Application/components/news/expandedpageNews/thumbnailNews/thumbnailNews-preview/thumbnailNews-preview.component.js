var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedThumbnailNewsPreviewComponent = (function () {
            function expandedThumbnailNewsPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.expandedThumbnailNewsPreviewController.thumbnailNewsPreviewComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-preview/thumbnailNews-preview.component.html";
                this.controllerAs = "thumbnailPreview";
            }
            return expandedThumbnailNewsPreviewComponent;
        }());
        angular.module("SPApp").component("expandedThumbnailNewsPreview", new expandedThumbnailNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-preview.component.js.map