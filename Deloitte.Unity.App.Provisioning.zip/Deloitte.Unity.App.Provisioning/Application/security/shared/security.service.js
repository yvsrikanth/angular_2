var app;
(function (app) {
    var security;
    (function (security) {
        var shared;
        (function (shared) {
            var securityService = (function () {
                function securityService($q, userService) {
                    this.$q = $q;
                    this.userService = userService;
                }
                securityService.prototype.getUserPermissions = function () {
                    var _this = this;
                    return this
                        .getCachedUserPermissions()
                        .then(function (user) {
                        if (user.permissions && user.permissions.length) {
                            return _this.getUserPermissionsModel(user.permissions);
                        }
                        return {};
                    });
                };
                securityService.prototype.getCachedUserPermissions = function () {
                    var json = sessionStorage.getItem(securityService.USER_CACHE_KEY);
                    var msec = sessionStorage.getItem(securityService.USER_CACHE_DATE);
                    if (json && msec) {
                        var obj = JSON.parse(json);
                        var diff = Date.now() - (+msec);
                        var minsDiff = diff / 1000 / 60;
                        var minsExp = (+(window["unityConfigKeys"].PermissionsCacheExpiraion || '5'));
                        if (minsDiff < minsExp) {
                            return this.$q.resolve(obj);
                        }
                    }
                    return this.userService
                        .getUserPermissions()
                        .then(function (user) {
                        sessionStorage.setItem(securityService.USER_CACHE_KEY, JSON.stringify(user));
                        sessionStorage.setItem(securityService.USER_CACHE_DATE, Date.now().toString());
                        return user;
                    });
                };
                securityService.prototype.getUserPermissionsModel = function (permissions) {
                    var result = {};
                    for (var permIndex = 0; permIndex < permissions.length; permIndex++) {
                        var permission = permissions[permIndex];
                        var firm = permission.firm;
                        var splittedPermission = permission.key.split("-");
                        var module = splittedPermission[0];
                        var access = splittedPermission[1];
                        if (!result.hasOwnProperty(firm)) {
                            result[firm] = {};
                        }
                        var firmPermissions = result[firm];
                        if (!firmPermissions.hasOwnProperty(module)) {
                            firmPermissions[module] = this.getDefaultPermissions();
                        }
                        firmPermissions[module][access] = true;
                    }
                    this.loadMissingModules(result);
                    return result;
                };
                securityService.prototype.getMergedPermissions = function () {
                    var _this = this;
                    return this.getUserPermissions().then(function (p) { return _this.getMergedPermissionsModel(p); });
                };
                securityService.prototype.isAdmin = function () {
                    var _this = this;
                    return this
                        .getMergedPermissions()
                        .then(function (permissions) { return _this.hasAnyPermission(permissions); });
                };
                securityService.prototype.hasAnyPermission = function (modules) {
                    var r = false;
                    for (var module in modules) {
                        var permissions = modules[module];
                        r = permissions.create ||
                            permissions.delete ||
                            permissions.disable ||
                            permissions.read ||
                            permissions.update;
                        if (r) {
                            return r;
                        }
                    }
                    return r;
                };
                securityService.prototype.getMergedPermissionsModel = function (permissions) {
                    var result = {};
                    for (var firm in permissions) {
                        if (permissions.hasOwnProperty(firm)) {
                            var firmPermissions = permissions[firm];
                            for (var module in firmPermissions) {
                                if (!result.hasOwnProperty(module))
                                    result[module] = this.getDefaultPermissions();
                                var modulePermissions = firmPermissions[module];
                                result[module].create = result[module].create || modulePermissions.create;
                                result[module].read = result[module].read || modulePermissions.read;
                                result[module].delete = result[module].delete || modulePermissions.delete;
                                result[module].disable = result[module].disable || modulePermissions.disable;
                                result[module].update = result[module].update || modulePermissions.update;
                            }
                        }
                    }
                    return result;
                };
                securityService.prototype.loadMissingModules = function (firms) {
                    for (var firm in firms) {
                        if (firms.hasOwnProperty(firm)) {
                            this.loadMissingModulesOnFirm(firms[firm]);
                        }
                    }
                };
                securityService.prototype.loadMissingModulesOnFirm = function (permissions) {
                    for (var moduleIndex = 0; moduleIndex < securityService.modules.length; moduleIndex++) {
                        var module = securityService.modules[moduleIndex];
                        if (!permissions[module]) {
                            permissions[module] = this.getDefaultPermissions();
                        }
                    }
                };
                securityService.prototype.getDefaultPermissions = function () {
                    return {
                        create: false,
                        read: false,
                        update: false,
                        delete: false,
                        disable: false
                    };
                };
                return securityService;
            }());
            securityService.$inject = ["$q", "userService"];
            securityService.USER_CACHE_KEY = "USER_CACHE";
            securityService.USER_CACHE_DATE = "USER_CACHE_DATE";
            securityService.modules = [
                "systemNotifications",
                "contentTargeting",
                "homePageLeadnews",
                "homeHeadlineNews",
                "homePageBannerAd",
                "homePageHiddenNews",
                "extendedPageLeadNews",
                "extendedPageHeadlineNews",
                "extendedPageThumbnailNews",
                "extendedPageTitle",
                "extendedPageExternalResources",
                "hamburgerMenu",
                "applicationLauncher",
                "moduleAccess",
                "instantFind"
            ];
            shared.securityService = securityService;
            angular.module("SPApp").service("securityService", securityService);
        })(shared = security.shared || (security.shared = {}));
    })(security = app.security || (app.security = {}));
})(app || (app = {}));
//# sourceMappingURL=security.service.js.map