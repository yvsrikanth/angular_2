﻿﻿module app.services {

    export class instantFindService {
        static $inject = ["$http", "appSettings"];

        constructor(private $http: ng.IHttpService, private appSettings: IAppSettings) {
        }

        getResultItems(skip, take, resultType) {
            var queryParams = { skip, take, resultType};
            return this.$http.get(this.appSettings.apiUrl + '/instantFind/results', { params: queryParams })
                .then(result => result.data);
        }

        getResultItem(id) {
            return this.$http.get(this.appSettings.apiUrl + '/instantFind/results/' + id)
                .then(result => result.data);
        }

        saveResultItem(item) {
            return this.$http.post(this.appSettings.apiUrl + '/instantFind/results', item);
        }

        updateResultItem(item) {
            return this.$http.put(this.appSettings.apiUrl + '/instantFind/results/' + item.id, item);
        }

        deleteResultItem(id) {
            return this.$http.delete(this.appSettings.apiUrl + '/instantFind/results/' + id);
        }

        getPeopleItems(skip, take) {
            var queryParams = { skip, take };
            return this.$http.get(this.appSettings.apiUrl + "/users", { params: queryParams })
                .then(result => result.data);
        }

        getPeopleItem(id) {
            return this.$http.get(this.appSettings.apiUrl + "/users/" + id)
                .then(result => result.data);
        }

        updatePeopleItem(item) {
            return this.$http.post(this.appSettings.apiUrl + "/users/" + item.id + '/attributes',
                { attributes: item.attributes, deleteUnspecified: true });
        }

        search(skip, take, firm, query, resultType) {
            var queryParams = { skip, take, firm, query, resultType };
            return this.$http.get(this.appSettings.apiUrl + '/instantFind/search', { params: queryParams })
                .then(result => result.data);
        }

        getTypes() {
            return this.$http.get(this.appSettings.apiUrl + '/instantFind/resultTypes')
                .then(result => result.data);
        }
    }

    angular.module("SPApp").service('instantFindService', instantFindService);
}
