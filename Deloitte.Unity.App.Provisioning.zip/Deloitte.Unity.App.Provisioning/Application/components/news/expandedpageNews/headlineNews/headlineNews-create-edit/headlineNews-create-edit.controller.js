var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var headlineNews;
                (function (headlineNews) {
                    var expandedHeadlineNewsCreateEditController = (function (_super) {
                        __extends(expandedHeadlineNewsCreateEditController, _super);
                        function expandedHeadlineNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            return _super.call(this, 
                            // Injected dependencies
                            rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, 
                            /*pageTitleOnEditAll*/ "Edit headline news layout", 
                            /*pageTitleOnEditById*/ "Edit headline news", 
                            /*pageTitleOnCreate*/ "Create headline news", 
                            /*maxItems*/ 10, 
                            /*region*/ "headline", 
                            /*listPath*/ "/news/expandedpageNews/headlineNews") || this;
                        }
                        expandedHeadlineNewsCreateEditController.prototype.onPreview = function () {
                            _super.prototype.onPreview.call(this);
                            this.previewBlockName = this.blockName;
                        };
                        return expandedHeadlineNewsCreateEditController;
                    }(news.genericNewsCreateEditController));
                    expandedHeadlineNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    headlineNews.expandedHeadlineNewsCreateEditController = expandedHeadlineNewsCreateEditController;
                })(headlineNews = expandedpageNews.headlineNews || (expandedpageNews.headlineNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-create-edit.controller.js.map