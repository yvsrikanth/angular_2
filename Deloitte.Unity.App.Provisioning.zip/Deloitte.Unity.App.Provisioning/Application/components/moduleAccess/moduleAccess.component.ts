﻿module app.directives {

    class moduleAccessComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                moduleAccessItem: "@"
            };
            this.controller = moduleAccessController.moduleAccessComponentController;
            this.templateUrl = "/Application/components/moduleAccess/moduleAccess.html";
            this.controllerAs = "moduleAccess";
        }

    }

    angular.module("SPApp").component("moduleAccess", new moduleAccessComponent());

}