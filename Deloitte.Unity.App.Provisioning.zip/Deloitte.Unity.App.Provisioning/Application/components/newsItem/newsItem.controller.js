var app;
(function (app) {
    var newsItemController;
    (function (newsItemController) {
        var newsItemComponentController = (function () {
            function newsItemComponentController($scope, $rootScope, audienceService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.audienceService = audienceService;
            }
            newsItemComponentController.prototype.$onInit = function () {
                this.loadAudiences();
            };
            newsItemComponentController.prototype.loadAudiences = function () {
                var that = this;
                that.audiences = [];
                var _loop_1 = function (audience) {
                    that.audienceService.getContentTargetById(audience).then(function (data) {
                        that.audiences.push(data.displayName);
                    }, function () {
                        that.audiences.push("Item Not Found (" + audience + ")");
                    });
                };
                for (var _i = 0, _a = that.item.audiences; _i < _a.length; _i++) {
                    var audience = _a[_i];
                    _loop_1(audience);
                }
            };
            return newsItemComponentController;
        }());
        newsItemComponentController.$inject = ["$scope", "$rootScope", "contentTargetingService"];
        newsItemController.newsItemComponentController = newsItemComponentController;
    })(newsItemController = app.newsItemController || (app.newsItemController = {}));
})(app || (app = {}));
//# sourceMappingURL=newsItem.controller.js.map