var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadNewsPreviewComponent = (function () {
            function leadNewsPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.leadNewsPreviewController.leadNewsPreviewComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews-preview/leadNews-preview.html";
                this.controllerAs = "leadNewsPreview";
            }
            return leadNewsPreviewComponent;
        }());
        angular.module("SPApp").component("leadNewsPreview", new leadNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-preview.component.js.map