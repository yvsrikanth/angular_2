var app;
(function (app) {
    var hamburgerMenuController;
    (function (hamburgerMenuController) {
        var hamburgerMenuComponentController = (function () {
            function hamburgerMenuComponentController(securityService) {
                this.securityService = securityService;
                var self = this;
                self.whenOneItem = 1;
            }
            hamburgerMenuComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firms = Object.keys(permissions).sort();
                });
            };
            return hamburgerMenuComponentController;
        }());
        hamburgerMenuComponentController.$inject = ['securityService'];
        hamburgerMenuController.hamburgerMenuComponentController = hamburgerMenuComponentController;
    })(hamburgerMenuController = app.hamburgerMenuController || (app.hamburgerMenuController = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu.controller.js.map