﻿﻿module app.services {
     export class userAttributesService {

        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings) {
        }

        resourcePath = "/userattributes/";

        /**
         * Retrieve a list of news articles
         * @param options Request parameters
         */
        get(): ng.IPromise<services.IPaginatedResult<any>> {
            let params = { params: { skip: 0, take: 999999 } }
            return this.$http
                .get(this.appSettings.apiUrl + this.resourcePath, params)
                .then(result => result.data);
        }

        /**
         * Retrieves a single news article by id
         * @param id Unique identifier or key for the news article
         * @param include Requests that optional fields or data be embedded in the response
         */
        getById(id: string): ng.IPromise<any> {
            return this.$http
                .get(this.appSettings.apiUrl + this.resourcePath + id)
                .then(result => result.data);
        }
    }

     function myServiceFactory($rootElement): userAttributesService {
        const inj = $rootElement.injector();
        return inj.instantiate(userAttributesService);
    }
    angular.module("SPApp").factory('userAttributesService',
        ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}
