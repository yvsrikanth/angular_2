﻿module app.applicationLauncherListController {

    const operator = ["Less than", "Equal", "Greater than", "Not Equal"];

    export class applicationLauncherListComponentController {
        static $inject = ["$scope", "$rootScope", "contentTargetingService", "$http", "$compile", "securityService", "$attrs", "alertService", "applicationLauncherService", "clientSidePaginationFactory", "moduleAccessService"];
        public applicationLauncherList: any;
        public firm: any;
        public itemsPerPage: Number;
        public query: any;
        public totalCount: any;
        public memberFirm: String;
        public dateForToday: any;
        public userPermissions: security.shared.IFirmPermissions;
        public attrs: any;
        public ctrl: any;
        public regionType: String;
        public errorMessage:String;
        columns: any;
        columnNames: any;
        reverse: boolean;
        paginatedList: components.pagination.clientSidePaginationFactory<any>;

        http: ng.IHttpService;

        constructor(
            private $scope,
            private $rootScope,
            private contentTargetingService: services.contentTargetingService,
            $http: ng.IHttpService,
            private $compile,
            private securityService: security.shared.securityService,
            private $attrs: ng.IAttributes,
            private alertService: components.alert.alertService,
            private applicationLauncherService: services.applicationLauncherService,
            private paginatedListFactory: any,
            private moduleAccessService: services.moduleAccessService) {
            let self = this;
            self.http = $http;
            self.attrs = $attrs;

            self.itemsPerPage = 8;
            self.query = {
                skip: 0,
                take: self.itemsPerPage
            };
            this.paginatedList = paginatedListFactory.instance();
        }

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
            });
            this.reverse = false;

            this.getApplicationLauncherList(0, this.itemsPerPage);
            this.setColumns();
        }

        setColumns() {
            this.columns = ["Application name", "URL"];
            this.columnNames = ["title", "url"];
        }
        setFirm() {
            this.contentTargetingService.setFirm(this.firm);
        }

        getApplicationLauncherList(skip, take) {
            let self = this;
            var rightNow = new Date();
            self.dateForToday = rightNow.toISOString().slice(0, 10);
            self.applicationLauncherService.getPageList(skip, take, this.firm).then((data: any) => {
                self.applicationLauncherList = data.items[0];
                self.paginatedList.setItems(self.applicationLauncherList.navigation.appLauncher);
            });
        }

        sortBy(index: number) {
            let self = this;
            let column = index <=1 ? "Application name" : (index === 1 ? "URL" : "Created date");

            if (!angular.isObject(self.applicationLauncherList.navigation.appLauncher)) return self.applicationLauncherList.navigation.appLauncher;

            var array = [];
            for (var value of self.applicationLauncherList.navigation.appLauncher) {
                array.push(value);
            }

            array.sort(function (a, b) {

                if (column === "Application name") {
                    return (a.title.toLowerCase() > b.title.toLowerCase() ? 1 : -1);
                } else {
                    return (a.url.toLowerCase() > b.url.toLowerCase() ? 1 : -1);
                }
            });

            if (self.reverse) array.reverse();
            self.reverse = !self.reverse;

            self.applicationLauncherList.navigation.appLauncher = array;

        }

        deleteApplicationItem(id) {
            let self = this;
            let index: any;

            for (var i in self.applicationLauncherList.navigation.appLauncher) {
                if (self.applicationLauncherList.navigation.appLauncher[i].title === id) {
                    index = i;
                }
            }
            self.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: 'Delete an entry',
                message: 'The selected entry will be deleted. This action cannot be undone',
                dismissText: 'Cancel',
                confirmText: 'Delete',
                onConfirm: () => {
                    self.alertService.close();
                    self.applicationLauncherList.navigation.appLauncher.splice(index, 1);
                    self.applicationLauncherService
                        .deleteApplicationItem(self.applicationLauncherList.id, self.applicationLauncherList)
                        .then(() => {
                                this.getApplicationLauncherList(0, this.itemsPerPage);
                            },
                            response => {

                                if (response.status === 400) {

                                    this.errorMessage = response.data.message;

                                } else {
                                    this.alertService.show({
                                        buttons: app.components.alert.AlertButtons.Accept,
                                        title: response.statusText,
                                        message: response.data.message,
                                        dismissText: "Ok"
                                    });
                                }
                            });
                }
            });

        }
    }
}