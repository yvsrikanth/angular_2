﻿namespace app.directives {
    export class expandedExternalResourcesListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = expandedExternalResourcesListController.externalResourcesListComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources-list/externalResources-list.component.html";
            this.controllerAs = "externalResourcesList";
        }
    }
    angular.module("SPApp").component("expandedExternalResourcesList", new expandedExternalResourcesListComponent());
}