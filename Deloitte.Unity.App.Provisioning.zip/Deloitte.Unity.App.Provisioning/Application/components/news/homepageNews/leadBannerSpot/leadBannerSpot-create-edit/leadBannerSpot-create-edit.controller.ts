﻿module app.components.news {

    export class leadBannerSpotCreateEditComponentController {

        static $inject = [
            "$scope", "newsService", "contentTargetingService", "$routeParams", "$location", "alertService", "$anchorScroll"
        ];

        previewedItemsJson: string;
        saving = false;
        loading = false;
        firm: string;
        audiences = new Array();
        leadBannerSpot: components.news.INewsArticleData;
        image: any;
        previewHtmlContent: any;
        previewImage: any;
        radioValue: any;
        region: any;
        onPreviewItems = false;
        onCreate: boolean;
        imgPreviewed = false;

        public regex: any = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

        constructor(private $scope,
            private newsService: services.newsService,
            private contentTargetingService: services.contentTargetingService,
            private $routeParams: any,
            private $location,
            private alertService: components.alert.alertService,
            private $anchorScroll: any
        ) { }

        $onInit() {
            this.firm = this.$routeParams.firm;
            this.onCreate = true;

            this.leadBannerSpot = <components.news.INewsArticleData>{
                audiences: new Array<string>(),
                ordinal: 1,
                items: [<components.news.INewsArticleDataItem>{}],
                firm: this.firm
                

            };
            this.getAudiences();
            this.getRegionList();
            this.getItems(this.$routeParams.id);
        }

        checkUrlFilter(s: any) {
            if (s) {
                if (!s.match(/^[a-zA-Z]+:\/\//)) {
                    s = 'http://' + s;
                }
                return s;
            }
        }

        getAudiences() {
            this.contentTargetingService.getAudiencesData(this.firm)
                .then((response: any) => {
                    this.audiences = response.items;
                });
        }

        getAudienceName(id: any) {
            for (var i = 0; i < this.audiences.length; i++) {
                var aud = this.audiences[i];
                if (aud.id === id) {
                    return aud.displayName;
                }
            }
            return id;
        }

        getItems(id?: string) {
            if (id != undefined) {
                this.onCreate = false;
                this.loading = true;
                this.newsService.getById(id, "image")
                    .then((response) => {
                        this.loading = false;
                        this.leadBannerSpot = response;
                        if (this.leadBannerSpot.items[0].image != null) {
                            this.radioValue = "image"; 
                            $('input[id=box1]').prop('checked', false);  
                            $('input[id=box2]').prop('checked', true);                                                       
                            this.previewImage = this.leadBannerSpot.items[0].imageUrl;
                        } else {
                            this.radioValue = "html";
                            $('input[id=box1]').prop('checked', true);
                            $('input[id=box2]').prop('checked', false);     
                            this.previewHtmlContent = this.leadBannerSpot.items[0].content;
                        }
                        this.image= {
                            data: response.items[0].image,
                            name: response.items[0].imageUrl
                        }
                    });

            }
        }

        onSelectAudience(audience: any) {
            if (this.leadBannerSpot.audiences.indexOf(audience.id) === -1) {
                this.leadBannerSpot.audiences.push(audience.id);
            }
        }

        onRemoveAudience(id: any) {
            var audIndex = this.leadBannerSpot.audiences.indexOf(id);
            if (audIndex !== -1) {
                this.leadBannerSpot.audiences.splice(audIndex, 1);
            }
        }

        getRegionList() {
            this.newsService.getRegionList()
                .then((response: any) => {
                    this.region = response.region;
                });
        }

        onPreview() {
            if (this.radioValue === "html") {
                this.previewHtmlContent = this.leadBannerSpot.items[0].content;
                this.previewImage = null;
                this.leadBannerSpot.items[0].image = null;
                this.leadBannerSpot.items[0].url = null;
            } else {
                this.previewHtmlContent = null;
                this.previewImage = this.image ? this.image.data : null;
                this.leadBannerSpot.items[0].image = this.image ? this.image.data : null;
                this.leadBannerSpot.items[0].content = null;
            }

            this.previewedItemsJson = angular.toJson(this.leadBannerSpot);
            this.onPreviewItems = true;
            this.imgPreviewed = true;

        }

        onChangeImg() {
            this.imgPreviewed = false;
        }

        getImageText(item: INewsArticleData, img: any) {
            return img && img.name ? img.name : ((item ? item.items[0].imageUrl : null) || "");
        }

        previewed() {
            var currentItemsJson = angular.toJson(this.leadBannerSpot);
            var dataPreviewed = currentItemsJson === this.previewedItemsJson;

            return dataPreviewed && this.imgPreviewed;
        }

        onPublish(invalid) {
            if (invalid) {
                this.$anchorScroll("mainView");
                return;
            }

            this.onPreview();
            this.leadBannerSpot.region = this.region[0].hiddenNews;
            this.leadBannerSpot.items[0].description = "...";
            this.leadBannerSpot.items[0].language = "...";
            this.leadBannerSpot.layout = this.radioValue;
            if (this.leadBannerSpot.items[0].title === undefined) {
                this.leadBannerSpot.items[0].title = "...";
            }
            if (this.leadBannerSpot.items[0].url === undefined || this.leadBannerSpot.items[0].url === null) {
                this.leadBannerSpot.items[0].url = "...";
            }
            if (this.leadBannerSpot.items[0].content === undefined || this.leadBannerSpot.items[0].content === null) {
                this.leadBannerSpot.items[0].content = "...";
            }

            this.saving = true;
            this.newsService.save(this.leadBannerSpot, !(this.$routeParams.id))
                .then(() => {
                    this.saving = false;
                    this.$location.path("/news/homepageNews/leadBannerSpot");
                }, error => {
                    this.saving = false;
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: error.statusText,
                        message: error.data.message,
                        dismissText: "Ok"
                    });
                });
        }
    }
}