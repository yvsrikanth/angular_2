﻿module app.components.siteProvisioning {
    var siteProvisioningListComponentOptions: ng.IComponentOptions = {
        bindings: {},
        controller: siteProvisioningListController,
        templateUrl: "/Application/components/siteProvisioning/siteProvisioning-list/siteProvisioning-list.component.html",
        controllerAs: "vm"
    };

    angular.module("SPApp").component("siteProvisioning", siteProvisioningListComponentOptions);
}