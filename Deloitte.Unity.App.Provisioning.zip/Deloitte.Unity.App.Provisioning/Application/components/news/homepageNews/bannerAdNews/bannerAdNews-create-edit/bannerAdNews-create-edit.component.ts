﻿module app.components.news.homepageNews.bannerAdNews {
    var bannerAdNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {

        },
        controller: bannerAdNewsCreateEditController,
        templateUrl: "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-create-edit/bannerAdNews-create-edit.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("bannerAdNewsCreateEdit", bannerAdNewsCreateEditComponent);
}