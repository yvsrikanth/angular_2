﻿module app.expandedThumbnailNewsPreviewController {

    export class thumbnailNewsPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];

        id: string;
        firm: string;
        edit: boolean;
        thumbnailNewsItem: any;
        selectedItem: any;
        showTitle: boolean;
        resourceTitle: string;
        buttonText: string;
        userPermissions: security.shared.IModulePermissions;


        constructor(
            private $scope,
            private $rootScope,
            private $routeParams,
            private newsService: services.newsService,
            private $location,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService
        ) { }

        $onInit() {

            this.setThumbnailNewsParams();
            this.thumbnailNewsItem = [];
            this.getDetailsThumbnailNewsItem();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setThumbnailNewsParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
                this.resourceTitle = "Thumbnail news preview";
                this.buttonText = "Edit news";
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
                this.resourceTitle = "Thumbnail news layout preview";
                this.buttonText = "Edit layout";
            }
        }

        getDetailsThumbnailNewsItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllThumbnailNewsData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestThumbnailNewsItem();
                return;
            }

        }

        requestAllThumbnailNewsData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "Thumbnail-newstab", take: 14 }).then(result => {
                this.thumbnailNewsItem = result.items;
                this.sortByPosition();
            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        requestThumbnailNewsItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.thumbnailNewsItem.push(data);
                this.setSelectedItem();

            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.thumbnailNewsItem.push(item);
                }, response => {
                    this.redirectToHome(response.statusText);
                });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {

            this.selectedItem = this.thumbnailNewsItem[0];
            if (!angular.isDefined(this.firm)) { this.firm = this.selectedItem.firm; }
            this.showTitle = this.thumbnailNewsItem.length > 1;
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/expandedpageNews/thumbnailNews");
        }

        sortByPosition() {

            if (!angular.isObject(this.thumbnailNewsItem)) return;

            var array = [];
            for (var item in this.thumbnailNewsItem) {
                array.push(this.thumbnailNewsItem[item]);
            }

            array.sort(function (a, b) {
                return (a["ordinal"] > b["ordinal"] ? 1 : -1);
            });
            this.thumbnailNewsItem = array;

        }

    }
}