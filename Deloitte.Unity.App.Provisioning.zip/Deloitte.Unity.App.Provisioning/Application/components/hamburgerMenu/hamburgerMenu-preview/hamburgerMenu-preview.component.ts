﻿module app.directives {

    class hamburgerMenuPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                hamburgerMenuItem: "<"
            };
            this.controller = hamburgerMenuPreviewController.hamburgerMenuPreviewComponentController;
            this.templateUrl = "/Application/components/hamburgerMenu/hamburgerMenu-preview/hamburgerMenu-preview.html";
            this.controllerAs = "hamburgerMenuPreview";
        }

    }

    angular.module("SPApp").component("hamburgerMenuPreview", new hamburgerMenuPreviewComponent());

}