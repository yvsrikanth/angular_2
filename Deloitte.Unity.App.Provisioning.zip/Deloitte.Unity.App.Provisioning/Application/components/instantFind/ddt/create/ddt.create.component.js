var app;
(function (app) {
    var directives;
    (function (directives) {
        var ddtCreateComponent = (function () {
            function ddtCreateComponent() {
                this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
                this.templateUrl = '/Application/components/instantFind/ddt/create/ddt.create.html';
                this.controllerAs = "instantFindCtrl";
            }
            return ddtCreateComponent;
        }());
        angular.module('SPApp').component('ddtCreate', new ddtCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=ddt.create.component.js.map