﻿module app.components.news.homepageNews.headlineNews {
    var headlineNewsThumbnailsPreviewComponent: ng.IComponentOptions = {

        bindings: {
            news: "<",
            selectedNew: "=?",
            skipSort: "<"
        },
        controller: genericNewsLayoutPreviewController,
        templateUrl: "/Application/components/news/homepageNews/headlineNews/headlineNews-thumbnailsPreview/headlineNews-thumbnailsPreview.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("headlineNewsThumbnailsPreview", headlineNewsThumbnailsPreviewComponent);
}