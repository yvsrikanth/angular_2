﻿module app.components.siteProvisioning {
    export class siteProvisioningListController {

        loaded: boolean = false;
        isAdmin: boolean = false;

        static $inject = ["siteRequestService", "clientSidePaginationFactory", "$routeParams"];
        expandedItem: services.ISiteRequestResult;

        paginatedList: components.pagination.clientSidePaginationFactory<any>;
        constructor(
            private siteRequestService: services.siteRequestService,
            private paginatedListFactory: any,
            private $routeParams: any
        ) {
            this.paginatedList = this.paginatedListFactory.instance();
        }

        $onInit() {
            this.isAdmin = this.$routeParams.isAdmin === "true";
            this.siteRequestService
                .getSitesDetails()
                .then(data => {
                    this.paginatedList.setItems(data);
                    this.loaded = true;
                });
        }

        toggleExpandedItem(item: services.ISiteRequestResult) {
            if (this.expandedItem === item) {
                this.expandedItem = null;
            } else {
                this.expandedItem = item;
            }
        }
    }
}