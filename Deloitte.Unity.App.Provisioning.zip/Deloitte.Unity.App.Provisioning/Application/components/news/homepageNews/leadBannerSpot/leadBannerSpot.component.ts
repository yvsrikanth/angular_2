﻿module app.directives {

    class leadBannerSpotComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            
            this.controller = components.leadBannerSpot.leadBannerSpotComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot.component.html";
            this.controllerAs = "leadBannerSpot";
        }

    }

    angular.module("SPApp").component("leadBannerSpot", new leadBannerSpotComponent());

}