var app;
(function (app) {
    var directives;
    (function (directives) {
        var moduleAccessListComponent = (function () {
            function moduleAccessListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.moduleAccessListController.moduleAccessListComponentController;
                this.templateUrl = "/Application/components/moduleAccess/moduleAccess-list/moduleAccess-list.component.html";
                this.controllerAs = "moduleAccessList";
            }
            return moduleAccessListComponent;
        }());
        directives.moduleAccessListComponent = moduleAccessListComponent;
        angular.module("SPApp").component("moduleAccessListComponent", new moduleAccessListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-list.component.js.map