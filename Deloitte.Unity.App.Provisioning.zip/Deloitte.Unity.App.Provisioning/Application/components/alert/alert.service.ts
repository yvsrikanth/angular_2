﻿module app.components.alert {
    export interface IAlertOptions {
        title?: string;
        message?: string;
        onConfirm?: () => void;
        onDismiss?: () => void;
        confirmText?: string;
        dismissText?: string;
        noDismiss?: boolean;
        buttons: AlertButtons;
    }

    export enum AlertButtons {
        None,
        Accept,
        AcceptCancel
    }

    export class alertService {

        static $inject = ["$rootScope", "$timeout"];
        constructor(private $rootScope: ng.IScope | any, private $timeout: any) {
            if (!this.$rootScope.alertOptions) {
                this.$rootScope.alertOptions = {};
            }
        }

        show(options: IAlertOptions): void {
            this.fixOptions(options);
            this.$rootScope.alertOptions = options;

            $("body").removeClass("modal-open");
            $(".modal-backdrop").remove();
            $(".modal-backdrop").off();
            $("#modal-alert").removeData("bs.modal");

            var modalOptions = {
                backdrop: options.noDismiss ? "static" : true,
                keyboard: !options.noDismiss,
                show: true
            };
            $("#modal-alert").modal(modalOptions);
            if (options.noDismiss) {
                this.$timeout(() => {
                    $("#modal-alert").off("keydown");
                    $("#modal-alert").off("click");
                });
            } else {
                $("#modal-alert").on("hidden.bs.modal", () => {
                    if (options.onDismiss)
                        this.$timeout(() => options.onDismiss());
                });
            }
        }

        close() {
            $("#modal-alert").modal("hide");
        }

        private fixOptions(options: IAlertOptions): void {
            if (!options.onConfirm) {
                options.onConfirm = () => { $("#modal-alert").modal("hide"); };
            }
        }

    }
    angular.module("SPApp").service("alertService", alertService);
}