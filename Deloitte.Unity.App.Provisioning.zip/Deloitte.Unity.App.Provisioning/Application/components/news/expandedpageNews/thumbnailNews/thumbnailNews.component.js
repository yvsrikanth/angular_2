var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedThumbnailNewsComponent = (function () {
            function expandedThumbnailNewsComponent() {
                this.controller = app.components.expandedThumbnailNews.thumbnailNewsComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews.component.html";
                this.controllerAs = "thumbnailNews";
            }
            return expandedThumbnailNewsComponent;
        }());
        angular.module("SPApp").component("expandedThumbnailNews", new expandedThumbnailNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews.component.js.map