﻿module app.headlineNewsListController {

    export class headlineNewsListComponentController {

        static $inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];

        firm: string;
        headlineItems: any;
        userPermissions: security.shared.IModulePermissions;
        columns: any;

        constructor(
            private $scope,
            private $rootScope,
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $routeParams
        ) { }

        $onInit() {

            this.setColumns();
            this.setMemberFirm();
            this.headlineNews();
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
        }

        headlineNews() {

            this.newsService.get({ firm: this.firm, region: "Thumbnail", take: 8}).then(result => {
                this.headlineItems = result.items;
            });
        }

        setColumns() {
            this.columns = ["News title", "Audience", "Author", "Updated date"];
        }

        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                this.firm = this.$routeParams.firm;
            }
        }
    }
}