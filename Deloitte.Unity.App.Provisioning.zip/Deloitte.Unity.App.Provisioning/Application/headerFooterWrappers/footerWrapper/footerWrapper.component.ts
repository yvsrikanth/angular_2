﻿module app.headerFooterWrappers.footerWrapper {

    export var footerWrapperComponent: ng.IComponentOptions =
        {
            templateUrl: "/Application/headerFooterWrappers/footerWrapper/footerWrapper.component.html",
            controller: headerFooterComponentController,
            controllerAs: "vm"
        };
}