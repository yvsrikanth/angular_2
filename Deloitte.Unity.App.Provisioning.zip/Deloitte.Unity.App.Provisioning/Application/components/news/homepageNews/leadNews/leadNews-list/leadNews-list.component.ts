﻿namespace app.directives {
    export class leadNewsListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = leadNewsListController.leadNewsListComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews-list/leadNews-list.component.html";
            this.controllerAs = "leadNewsList";
        }
    }
    angular.module("SPApp").component("leadNewsList", new leadNewsListComponent());
}