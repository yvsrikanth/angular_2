var app;
(function (app) {
    var services;
    (function (services) {
        var moduleAccessService = (function () {
            function moduleAccessService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
                this.path = "/roles/";
            }
            moduleAccessService.prototype.getModuleAccess = function (skip, take, firm, sort) {
                var options = { skip: skip, take: take, firms: firm };
                if (sort)
                    options.sort = sort;
                return this.$http
                    .get(this.appSettings.apiUrl + this.path, { params: options })
                    .then(function (result) {
                    var queryResult = result.data;
                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }
                    return queryResult;
                });
            };
            moduleAccessService.prototype.getModuleAccessItem = function (id) {
                return this.$http.get(this.appSettings.apiUrl + this.path + id).then(function (result) { return result.data; });
            };
            moduleAccessService.prototype.deleteModuleAccessItem = function (id) {
                return this.$http.delete(this.appSettings.apiUrl + this.path + id).then(function (result) { return result; });
            };
            moduleAccessService.prototype.createModuleAccess = function (data, isNew) {
                if (isNew) {
                    data.description = data.displayName;
                    data.created = new Date().toISOString().slice(0, 10);
                    return this.$http.post(this.appSettings.apiUrl + this.path, data).then(function (result) { return result; });
                }
                return this.$http.put(this.appSettings.apiUrl + this.path + data.id, data).then(function (result) { return result; });
            };
            return moduleAccessService;
        }());
        moduleAccessService.$inject = ["$http", "appSettings"];
        services.moduleAccessService = moduleAccessService;
        angular.module("SPApp").service("moduleAccessService", moduleAccessService);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess.service.js.map