var app;
(function (app) {
    var components;
    (function (components) {
        var siteProvisioning;
        (function (siteProvisioning) {
            var siteProvisioningCreateController = (function () {
                function siteProvisioningCreateController($location, $rootScope, siteRequestService, siteTypeService, firmService, alertService, siteRequestFieldService) {
                    this.$location = $location;
                    this.$rootScope = $rootScope;
                    this.siteRequestService = siteRequestService;
                    this.siteTypeService = siteTypeService;
                    this.firmService = firmService;
                    this.alertService = alertService;
                    this.siteRequestFieldService = siteRequestFieldService;
                    this.request = {
                        additionalAdmin: [''],
                        isSearchable: false
                    };
                }
                siteProvisioningCreateController.prototype.$onInit = function () {
                    var _this = this;
                    var profile = this.$rootScope["userInfo"].profile;
                    this.userName = profile.given_name + ' ' + profile.family_name;
                    this.siteTypeService
                        .get()
                        .then(function (siteTypes) {
                        _this.siteTypes = siteTypes.items;
                        if (siteTypes.items.length)
                            _this.request.siteType = siteTypes.items[0].id;
                    });
                };
                siteProvisioningCreateController.prototype.isTeamSiteAndUk = function () {
                    return this.isSiteType("Team Site") && sessionStorage.getItem("firmKey") === "UK";
                };
                siteProvisioningCreateController.prototype.isSiteType = function (type) {
                    if (this.siteTypes) {
                        for (var i = 0; i < this.siteTypes.length; i++) {
                            var siteType = this.siteTypes[i];
                            if (siteType.id === this.request.siteType) {
                                return siteType.description.toLowerCase() === type.toLowerCase();
                            }
                        }
                    }
                };
                siteProvisioningCreateController.prototype.onSave = function () {
                    this.save();
                };
                siteProvisioningCreateController.prototype.save = function () {
                    var _this = this;
                    this.siteRequestService
                        .post(this.request)
                        .then(function () {
                        _this.$location.path("siteProvisioning");
                    })
                        .catch(function (error) {
                        _this.alertService.show({
                            buttons: 1,
                            dismissText: "Close",
                            title: "Error",
                            message: (error.data ? error.data.message : null) || "Server error"
                        });
                    });
                };
                return siteProvisioningCreateController;
            }());
            siteProvisioningCreateController.$inject = ["$location", "$rootScope", "siteRequestService", "siteTypeService", "firmService", "alertService", "siteRequestFieldService"];
            siteProvisioning.siteProvisioningCreateController = siteProvisioningCreateController;
        })(siteProvisioning = components.siteProvisioning || (components.siteProvisioning = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=siteProvisioning-create.controller.js.map