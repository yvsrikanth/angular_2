﻿module app.components.news.expandedpageNews.headlineNews {
    export class externalResourcesCreateEditController extends genericNewsCreateEditController {

        static $inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService,
                /*pageTitleOnEditAll*/ "Edit external resource layout",
                /*pageTitleOnEditById*/ "Edit external resource",
                /*pageTitleOnCreate*/ "Create external resource",
                /*maxItems*/ 3,
                /*region*/ "external-links",
                /*listPath*/ "/news/expandedpageNews/externalResources");
        }

        save(checkPreviewChange) {
            if ($('.error-message').length > 0) {
                this.$anchorScroll("mainView");
                return;
            }
            this.setItemsToPreview(this.items);
            super.save(checkPreviewChange, true);
        }
    }
}