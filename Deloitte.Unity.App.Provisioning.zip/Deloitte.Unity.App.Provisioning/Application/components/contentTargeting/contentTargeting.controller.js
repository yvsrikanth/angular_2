var app;
(function (app) {
    var contentTargetingController;
    (function (contentTargetingController) {
        var operator = ["Less than", "Equal", "Greater than", "Not Equal"];
        var contentTargetingComponentController = (function () {
            function contentTargetingComponentController($scope, $rootScope, $http, $compile, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$compile = $compile;
                this.securityService = securityService;
                var self = this;
                self.http = $http;
                self.memberFirmName = "Select";
                self.whenOneItem = 1;
            }
            contentTargetingComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firmWithPermissions = Object.keys(permissions).sort();
                });
            };
            contentTargetingComponentController.prototype.getMemberFirmItemData = function (data) {
                this.memberFirmName = data.name;
            };
            return contentTargetingComponentController;
        }());
        contentTargetingComponentController.$inject = ['$scope', '$rootScope', '$http', '$compile', 'securityService'];
        contentTargetingController.contentTargetingComponentController = contentTargetingComponentController;
    })(contentTargetingController = app.contentTargetingController || (app.contentTargetingController = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting.controller.js.map