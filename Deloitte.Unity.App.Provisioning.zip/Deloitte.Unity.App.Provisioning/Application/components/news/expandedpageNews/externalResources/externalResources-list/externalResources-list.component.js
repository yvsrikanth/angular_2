var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedExternalResourcesListComponent = (function () {
            function expandedExternalResourcesListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.expandedExternalResourcesListController.externalResourcesListComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources-list/externalResources-list.component.html";
                this.controllerAs = "externalResourcesList";
            }
            return expandedExternalResourcesListComponent;
        }());
        directives.expandedExternalResourcesListComponent = expandedExternalResourcesListComponent;
        angular.module("SPApp").component("expandedExternalResourcesList", new expandedExternalResourcesListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-list.component.js.map