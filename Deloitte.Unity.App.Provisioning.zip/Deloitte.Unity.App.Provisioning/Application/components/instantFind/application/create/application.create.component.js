var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationCreateComponent = (function () {
            function applicationCreateComponent() {
                this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
                this.templateUrl = '/Application/components/instantFind/application/create/application.create.html';
                this.controllerAs = "instantFindCtrl";
            }
            return applicationCreateComponent;
        }());
        angular.module('SPApp').component('applicationCreate', new applicationCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=application.create.component.js.map