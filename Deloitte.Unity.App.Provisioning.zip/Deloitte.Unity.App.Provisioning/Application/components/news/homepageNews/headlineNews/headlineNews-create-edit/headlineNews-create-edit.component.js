var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var headlineNewsCreateEditComponent = {
                    bindings: {},
                    controller: homepageNews.headlineNewsCreateEditController,
                    templateUrl: '/Application/components/news/homepageNews/headlineNews/headlineNews-create-edit/headlineNews-create-edit.html',
                    controllerAs: "headlineNewsCreateEdit"
                };
                angular.module('SPApp').component('headlineNewsCreateEdit', headlineNewsCreateEditComponent);
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-create-edit.component.js.map