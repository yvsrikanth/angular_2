﻿module app.directives {

    class officeCreateComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindCreateComponentController.instantFindCreateComponentController;
            this.templateUrl = '/Application/components/instantFind/office/create/office.create.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('officeCreate', new officeCreateComponent());
}