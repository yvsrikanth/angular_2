﻿module app.leadBannerSpotListController {

    export class leadBannerSpotListComponentController {

        static $inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];

        firm: string;

        leadBannerSpotItems: any;
        userPermissions: security.shared.IModulePermissions;
        columns: any;

        constructor(
            private $scope,
            private $rootScope,
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $routeParams
        ) { }

        $onInit() {

            this.setColumns();
            this.setMemberFirm();
            this.leadBannerSpot();
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
        }

        leadBannerSpot() {

            this.newsService.get({ firm: this.firm, region: "hiddenNews", take: 8 }).then(result => {
                this.leadBannerSpotItems = result.items;
             });
        }

        setColumns() {
            this.columns = ["News title", "Audience", "Author", "Updated date"];
        }

        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm)  && !angular.isDefined(this.firm) ) {
                this.firm = this.$routeParams.firm;
            }
        }

    }
}