var app;
(function (app) {
    var services;
    (function (services) {
        var siteRequestService = (function () {
            function siteRequestService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            /**
             * Retrieve a list of site requests
             * @param options Request parameters
             */
            siteRequestService.prototype.get = function (options) {
                return this.$http
                    .get(this.appSettings.apiUrl + "/siteRequests", { params: options || {} })
                    .then(function (result) { return result.data; });
            };
            siteRequestService.prototype.getSitesDetails = function () {
                return this
                    .get({ skip: 0, take: 1000 })
                    .then(function (result) { return result.items; });
            };
            siteRequestService.prototype.getSitesDetailsOfUser = function (userEmail) {
                return this
                    .get({ skip: 0, take: 1000, requestor: userEmail })
                    .then(function (result) { return result.items; });
            };
            siteRequestService.prototype.post = function (data) {
                return this.$http
                    .post(this.appSettings.apiUrl + "/siteRequests", data);
            };
            return siteRequestService;
        }());
        siteRequestService.$inject = ["$http", "appSettings"];
        services.siteRequestService = siteRequestService;
        function spServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(siteRequestService);
        }
        angular.module("SPApp").factory("siteRequestService", ["$rootElement", function ($rootElement) { return spServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=siteRequest.service.js.map