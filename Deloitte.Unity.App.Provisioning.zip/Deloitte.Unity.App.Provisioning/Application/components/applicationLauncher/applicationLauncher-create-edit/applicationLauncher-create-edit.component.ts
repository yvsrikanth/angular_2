﻿module app.directives {

    export class applicationLauncherCreateEditComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<",
                id: "<"
            };

            this.controller = applicationLauncherCreateEditController.applicationLauncherCreateEditController;
            this.templateUrl =
                '/Application/components/applicationLauncher/applicationLauncher-create-edit/applicationLauncher-create-edit.html';
            this.controllerAs = "appLunVm";
        }
    }

    angular.module('SPApp').component('applicationLauncherCreateEdit', new applicationLauncherCreateEditComponent());

}