﻿module app.directives {

    export class headlineNewsPreviewComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {

            this.controller = headlineNewsPreviewController.headlineNewsPreviewController;
            this.templateUrl =
                '/Application/components/news/homepageNews/headlineNews/headlineNews-preview/headlineNews-preview.html';
            this.controllerAs = "headlineNewsPreview";
        }
    }

    angular.module('SPApp').component('headlineNewsPreview', new headlineNewsPreviewComponent());

}