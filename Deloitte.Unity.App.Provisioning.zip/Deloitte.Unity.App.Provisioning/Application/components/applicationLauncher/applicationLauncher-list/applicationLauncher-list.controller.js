var app;
(function (app) {
    var applicationLauncherListController;
    (function (applicationLauncherListController) {
        var operator = ["Less than", "Equal", "Greater than", "Not Equal"];
        var applicationLauncherListComponentController = (function () {
            function applicationLauncherListComponentController($scope, $rootScope, contentTargetingService, $http, $compile, securityService, $attrs, alertService, applicationLauncherService, paginatedListFactory, moduleAccessService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.contentTargetingService = contentTargetingService;
                this.$compile = $compile;
                this.securityService = securityService;
                this.$attrs = $attrs;
                this.alertService = alertService;
                this.applicationLauncherService = applicationLauncherService;
                this.paginatedListFactory = paginatedListFactory;
                this.moduleAccessService = moduleAccessService;
                var self = this;
                self.http = $http;
                self.attrs = $attrs;
                self.itemsPerPage = 8;
                self.query = {
                    skip: 0,
                    take: self.itemsPerPage
                };
                this.paginatedList = paginatedListFactory.instance();
            }
            applicationLauncherListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                });
                this.reverse = false;
                this.getApplicationLauncherList(0, this.itemsPerPage);
                this.setColumns();
            };
            applicationLauncherListComponentController.prototype.setColumns = function () {
                this.columns = ["Application name", "URL"];
                this.columnNames = ["title", "url"];
            };
            applicationLauncherListComponentController.prototype.setFirm = function () {
                this.contentTargetingService.setFirm(this.firm);
            };
            applicationLauncherListComponentController.prototype.getApplicationLauncherList = function (skip, take) {
                var self = this;
                var rightNow = new Date();
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.applicationLauncherService.getPageList(skip, take, this.firm).then(function (data) {
                    self.applicationLauncherList = data.items[0];
                    self.paginatedList.setItems(self.applicationLauncherList.navigation.appLauncher);
                });
            };
            applicationLauncherListComponentController.prototype.sortBy = function (index) {
                var self = this;
                var column = index <= 1 ? "Application name" : (index === 1 ? "URL" : "Created date");
                if (!angular.isObject(self.applicationLauncherList.navigation.appLauncher))
                    return self.applicationLauncherList.navigation.appLauncher;
                var array = [];
                for (var _i = 0, _a = self.applicationLauncherList.navigation.appLauncher; _i < _a.length; _i++) {
                    var value = _a[_i];
                    array.push(value);
                }
                array.sort(function (a, b) {
                    if (column === "Application name") {
                        return (a.title.toLowerCase() > b.title.toLowerCase() ? 1 : -1);
                    }
                    else {
                        return (a.url.toLowerCase() > b.url.toLowerCase() ? 1 : -1);
                    }
                });
                if (self.reverse)
                    array.reverse();
                self.reverse = !self.reverse;
                self.applicationLauncherList.navigation.appLauncher = array;
            };
            applicationLauncherListComponentController.prototype.deleteApplicationItem = function (id) {
                var _this = this;
                var self = this;
                var index;
                for (var i in self.applicationLauncherList.navigation.appLauncher) {
                    if (self.applicationLauncherList.navigation.appLauncher[i].title === id) {
                        index = i;
                    }
                }
                self.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: 'Delete an entry',
                    message: 'The selected entry will be deleted. This action cannot be undone',
                    dismissText: 'Cancel',
                    confirmText: 'Delete',
                    onConfirm: function () {
                        self.alertService.close();
                        self.applicationLauncherList.navigation.appLauncher.splice(index, 1);
                        self.applicationLauncherService
                            .deleteApplicationItem(self.applicationLauncherList.id, self.applicationLauncherList)
                            .then(function () {
                            _this.getApplicationLauncherList(0, _this.itemsPerPage);
                        }, function (response) {
                            if (response.status === 400) {
                                _this.errorMessage = response.data.message;
                            }
                            else {
                                _this.alertService.show({
                                    buttons: app.components.alert.AlertButtons.Accept,
                                    title: response.statusText,
                                    message: response.data.message,
                                    dismissText: "Ok"
                                });
                            }
                        });
                    }
                });
            };
            return applicationLauncherListComponentController;
        }());
        applicationLauncherListComponentController.$inject = ["$scope", "$rootScope", "contentTargetingService", "$http", "$compile", "securityService", "$attrs", "alertService", "applicationLauncherService", "clientSidePaginationFactory", "moduleAccessService"];
        applicationLauncherListController.applicationLauncherListComponentController = applicationLauncherListComponentController;
    })(applicationLauncherListController = app.applicationLauncherListController || (app.applicationLauncherListController = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-list.controller.js.map