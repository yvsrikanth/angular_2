﻿module app.components.pagination {
    export class clientSidePaginationFactory<T> {
        sortMethods: { [name: string]: (a, b) => number } = {};

        fiterColums: string[] = [];

        items: T[] = [];

        result: T[] = [];
        total: number = 0;
        skip: number = 0;
        take: number = 8;
        orderByColumn: string;
        orderReverse: boolean;
        filterTextValue: string;

        constructor() {
            this.sortMethods["date"] = (a, b) => {
                var dtA = new Date(a);
                var dtB = new Date(b);
                return dtA.getTime() - dtB.getTime();
            };
        }

        filterText() {
            var result = [];
            for (var index = 0; index <= this.items.length; index++) {
                var item = this.items[index];
                for (var attr in item) {
                    if (item.hasOwnProperty(attr)) {
                        var value: any = item[attr].toString();
                        if (value.includes(this.filterTextValue)) {
                            result.push(item);
                            break;
                        }
                    }
                }
            }

            this.result = result;
            this.total = result.length;
        }

        setItems(items: T[]) {
            this.items = items;
            this.total = items.length;
            this.changePage(0, this.take);
        }

        orderBy(column: string, type?: string) {
            var that = this;
            this.orderByColumn = column;

            if (!angular.isObject(this.items)) return;

            var array: any = [];

            for (var item in this.items) {
                array.push(this.items[item]);
            }

            array.sort(function (a, b) {

                if (type && that.sortMethods[type]) {
                    return that.sortMethods[type](a[column], b[column]);
                }

                if (a[column] === undefined || a[column] === null) {
                    a[column] = "";
                }
                if (!b[column] === undefined || b[column] === null) {
                    b[column] = "";
                }

                if (a[column].toLowerCase && b[column].toLowerCase) {
                    return (a[column].toLowerCase() > b[column].toLowerCase() ? 1 : -1);
                } else {
                    return (a[column] > b[column] ? 1 : -1);
                }

            });

            if (this.orderReverse) array.reverse();
            this.orderReverse = !this.orderReverse;

            this.items = array;
            this.changePage(this.skip, this.take);
        }

        changePage(skip: number, take: number) {
            this.skip = skip;
            this.take = take;

            this.result = this.items.slice(skip, skip + take);
        }
    }

    angular.module("SPApp").factory("clientSidePaginationFactory", [() => { return { instance: () => new clientSidePaginationFactory() }; }]);
}