var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var leadNews;
                (function (leadNews) {
                    var leadNewsThumbnailsPreviewComponent = {
                        bindings: {
                            news: "<",
                            skipSort: "<"
                        },
                        controller: news.genericNewsLayoutPreviewController,
                        templateUrl: "/Application/components/news/expandedpageNews/leadNews/leadNews-thumbnailsPreview/leadNews-thumbnailsPreview.html",
                        controllerAs: "vm"
                    };
                    angular.module("SPApp").component("expandedLeadNewsThumbnailsPreview", leadNewsThumbnailsPreviewComponent);
                })(leadNews = expandedpageNews.leadNews || (expandedpageNews.leadNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-thumbnailsPreview.component.js.map