﻿namespace app.directives {
    export class hamburgerMenuListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firmKey: '@'
            };
            this.controller = hamburgerMenuListController.hamburgerMenuListComponentController;
            this.templateUrl =
                '/Application/components/hamburgerMenu/hamburgerMenu-list/hamburgerMenu-list.html';
            this.controllerAs = "hamburgerMenuList";
        }
    }

    angular.module('SPApp').component('hamburgerMenuListComponent', new hamburgerMenuListComponent());
}