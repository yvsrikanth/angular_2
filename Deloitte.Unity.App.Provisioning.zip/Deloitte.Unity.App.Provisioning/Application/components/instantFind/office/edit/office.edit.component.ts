﻿module app.directives {

    class officeEditComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
            this.templateUrl = '/Application/components/instantFind/office/edit/office.edit.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('officeEdit', new officeEditComponent());
}