var app;
(function (app) {
    var components;
    (function (components) {
        var accordionItem;
        (function (accordionItem) {
            var accordionItemComponent = (function () {
                function accordionItemComponent() {
                    this.bindings = {
                        expanded: "<",
                        itemTitle: "@",
                        id: "@",
                        parentId: "@"
                    };
                    this.controller = accordionItem.accordionItemComponentController;
                    this.templateUrl = "/Application/components/accordionItem/accordionItem.component.html";
                    this.controllerAs = "accordionItem";
                    this.transclude = true;
                }
                return accordionItemComponent;
            }());
            accordionItem.accordionItemComponent = accordionItemComponent;
            angular.module("SPApp").component("accordionItem", new accordionItemComponent());
        })(accordionItem = components.accordionItem || (components.accordionItem = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=accordionItem.component.js.map