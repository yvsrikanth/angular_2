var app;
(function (app) {
    var components;
    (function (components) {
        var accordion;
        (function (accordion) {
            var accordionComponentController = (function () {
                function accordionComponentController($scope) {
                    this.$scope = $scope;
                }
                return accordionComponentController;
            }());
            accordionComponentController.$inject = ['$scope'];
            accordion.accordionComponentController = accordionComponentController;
        })(accordion = components.accordion || (components.accordion = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=accordion.controller.js.map