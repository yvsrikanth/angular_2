﻿module app.services {
    export interface IPaginatedResult<T> {
        query: IPaginatedQuery;
        items: T[];
        totalCount: number;
    }
    export interface IPaginatedQuery {
        skip: number;
        take: number;
    }
    export interface IAudience {
        id: string,
        created: string,
        createdBy: string,
        displayName: string,
        description: string,
        firm: string,
        rules: [
            {
                attribute: string,
                operator: string,
                value: string
            }
        ]
    }
}