﻿module app.components.news.homepageNews {

    var headlineNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {

        },
        controller: headlineNewsCreateEditController,
        templateUrl:
        '/Application/components/news/homepageNews/headlineNews/headlineNews-create-edit/headlineNews-create-edit.html',
        controllerAs: "headlineNewsCreateEdit"
    }

    angular.module('SPApp').component('headlineNewsCreateEdit', headlineNewsCreateEditComponent);
}