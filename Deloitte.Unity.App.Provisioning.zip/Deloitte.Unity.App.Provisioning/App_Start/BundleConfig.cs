﻿using System.Web.Optimization;

namespace Deloitte.Unity.App.Provisioning
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery")
                .Include("~/Assets/scripts/jquery.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/unityadminjs")
                .Include("~/Assets/scripts/angular.min.js",
                    "~/Assets/scripts/adal.min.js",
                    "~/Assets/scripts/adal-angular.min.js",
                    "~/Assets/scripts/angular-route.min.js",
                    "~/Assets/scripts/angular-filter.min.js",
                    "~/Assets/scripts/angular-sanitize.min.js",
                    "~/Assets/scripts/angular-translate.min.js",
                    "~/Assets/scripts/angular-resource.js",
                    "~/Assets/scripts/angular-translate-loader-static-files.min.js",
                    "~/Assets/scripts/angular-animate.min.js",
                    "~/Assets/scripts/angular-touch.min.js",
                     "~/Assets/scripts/ng-file-model.js")
                .IncludeDirectory("~/Application/", "*.js")
                .IncludeDirectory("~/Application/", "*.service.js", true)
                .IncludeDirectory("~/Application/", "*.controller.js", true)
                .IncludeDirectory("~/Application/", "*.component.js", true)
                .IncludeDirectory("~/Application/", "*.module.js", true)
                .IncludeDirectory("~/Application/", "*.filter.js", true)
                .IncludeDirectory("~/Application/", "*.directive.js", true));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap")
                .Include("~/Assets/scripts/bootstrap.min.js",
                     "~/Assets/scripts/tooltipster.bundle.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/uigrid")
                .Include("~/Assets/scripts/ui-grid.min.js"));

            bundles.Add(new StyleBundle("~/bundles/ccslibraries")
                .Include("~/Assets/CSS/fabric.min.css",
                    "~/Assets/CSS/fabric.components.min.css",
                    "~/Assets/CSS/ui-grid.min.css",
                    "~/Assets/CSS/tooltipster.bundle.css",
                    "~/Assets/CSS/bootstrap.min.css"));

            bundles.Add(new StyleBundle("~/bundles/unityadmincss")
                .Include("~/Assets/CSS/sp.main.css",
                    "~/Assets/CSS/create.css",
                    "~/Assets/CSS/report.css",
                    "~/Application/styles/styles.css",
                    "~/Application/styles/instantFind.css"));

            BundleTable.EnableOptimizations =
                System.Configuration.ConfigurationManager.AppSettings["BundleScripts"]?.ToLower() == "true";
        }
    }
}