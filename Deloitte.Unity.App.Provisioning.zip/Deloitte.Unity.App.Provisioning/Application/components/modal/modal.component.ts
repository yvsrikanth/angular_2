﻿module app.components.modal {
    export class modalComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;
        transclude: boolean;

        constructor() {
            this.bindings = {
                title: "@",
                message: "@",
                onConfirm: "&?",
                onDismiss: "&?",
                confirmText: "@?",
                dismissText: "@",
                noDismiss: "@?",
                buttons: "<?",
                modalId: "@",
                accent: "@?",
                size: "@?",
                submitDisabled: "@?"
            };
            this.controller = modal.modalComponentController;
            this.templateUrl = "/Application/components/modal/modal.component.html";
            this.controllerAs = "modal";
            this.transclude = true;
        }
    }
    angular.module("SPApp").component("modal", new modalComponent());
}