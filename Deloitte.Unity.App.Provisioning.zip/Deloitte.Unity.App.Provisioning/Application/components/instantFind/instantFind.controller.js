var app;
(function (app) {
    var instantFindComponentController;
    (function (instantFindComponentController_1) {
        var instantFindComponentController = (function () {
            function instantFindComponentController($filter, $location, $rootScope, instantFindService, alertService, securityService) {
                this.$filter = $filter;
                this.$location = $location;
                this.$rootScope = $rootScope;
                this.instantFindService = instantFindService;
                this.alertService = alertService;
                this.securityService = securityService;
                this.types = new Array();
                this.memberFirms = new Array();
                this.itemsPerPage = 8;
                this.totalCount = 0;
                this.searchIndex = 0;
                this.isInputSearchActive = false;
                this.filterTypesParam = '';
                this.filterFirmsParam = '';
                this.isLoading = true;
                this.shouldDisableExportButton = false;
                this.MAX_INT = 999999;
                this.allTypes = true;
                this.allFirms = true;
                this.searchQuery = '';
                this.params = {
                    skip: 0,
                    take: this.itemsPerPage,
                    firm: '',
                    resultType: '',
                    query: ''
                };
                this.initialize();
            }
            instantFindComponentController.prototype.initialize = function () {
                var self = this;
                this.securityService.getUserPermissions().then(function (data) {
                    self.userPermissions = data;
                    //for (var firm in data) {
                    //    self.memberFirms.push(firm);
                    //}
                    self.memberFirms = ['US', 'UK', 'CH'];
                    self.instantFindService.getTypes().then(function (data) {
                        self.types = data.items;
                        setTimeout(function () {
                            self.$rootScope.$apply();
                            self.searchResults();
                        }, 1000);
                    });
                });
            };
            instantFindComponentController.prototype.delete = function (item) {
                var _this = this;
                if (item.isUniversal || this.userPermissions[item.firm.trim()].instantFind.delete) {
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.AcceptCancel,
                        title: 'Delete item',
                        message: 'The action of deletion may take some time and cannot be undone.',
                        dismissText: 'Cancel',
                        confirmText: 'Delete',
                        onConfirm: function () {
                            _this.deleteItem(item);
                            _this.alertService.close();
                        }
                    });
                }
                else {
                    this.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: 'Action not allowed',
                        message: 'You do not have permissions to perform this action on '
                            + item.firm + ' member firm.',
                        dismissText: 'Ok',
                        onDismiss: function () {
                            _this.alertService.close();
                        }
                    });
                }
            };
            instantFindComponentController.prototype.deleteItem = function (item) {
                this.instantFindService.deleteResultItem(item.id);
                this.search(this.params.skip, this.params.take);
            };
            instantFindComponentController.prototype.getDisplayName = function (item) {
                if (this.isPersonItem(item)) {
                    return item.data.preferredName + ' ' + item.data.lastName;
                }
                else {
                    return item.data.displayName;
                }
            };
            instantFindComponentController.prototype.search = function (skip, take) {
                var self = this;
                var localSearchIndex = ++this.searchIndex;
                self.isLoading = true;
                this.params.query = this.isSearching() ? this.searchQuery : '';
                this.instantFindService.search(skip, take, self.params.firm, self.params.query, self.params.resultType.toLowerCase()).then(function (data) {
                    if (localSearchIndex !== self.searchIndex) {
                        return;
                    }
                    self.params = data.query;
                    if (self.params.resultType == null) {
                        self.params.resultType = '';
                    }
                    if (self.params.firm == null) {
                        self.params.firm = '';
                    }
                    self.items = data.items;
                    self.totalCount = data.totalCount;
                    for (var i = 0; i < self.items.length; i++) {
                        self.items[i].resultType = self.items[i].resultType.toLowerCase();
                    }
                    self.isLoading = false;
                }, function () {
                    if (localSearchIndex !== self.searchIndex) {
                        return;
                    }
                });
            };
            instantFindComponentController.prototype.searchResults = function () {
                this.params.skip = 0;
                this.search(0, this.itemsPerPage);
            };
            instantFindComponentController.prototype.cancelSearch = function () {
                this.searchQuery = '';
                this.items = new Array();
                this.searchResults();
            };
            instantFindComponentController.prototype.isSearching = function () {
                return this.searchQuery !== '';
            };
            instantFindComponentController.prototype.areThereItems = function () {
                return this.totalCount > 0;
            };
            instantFindComponentController.prototype.areThereFilters = function () {
                return this.params.firm !== '' || this.params.resultType !== '';
            };
            instantFindComponentController.prototype.shouldShowDeleteButton = function (item) {
                if (item.resultType === 'subissue' || item.resultType === 'person') {
                    return false;
                }
                if (item.isUniversal) {
                    return true;
                }
                return this.userPermissions[item.firm] && this.userPermissions[item.firm.trim()].instantFind.delete;
            };
            instantFindComponentController.prototype.shouldShowEditButton = function (item) {
                if (item.isUniversal) {
                    return true;
                }
                return this.userPermissions[item.firm] && this.userPermissions[item.firm.trim()].instantFind.update;
            };
            instantFindComponentController.prototype.shouldShowCreateDropdown = function () {
                var count = 0;
                for (var firm in this.userPermissions) {
                    if (this.userPermissions[firm].instantFind.create) {
                        count++;
                    }
                }
                return count > 0;
            };
            instantFindComponentController.prototype.getFirm = function (item) {
                return item.isUniversal ? this.$filter('translate')('Universal') : item.firm;
            };
            instantFindComponentController.prototype.getTitleMessage = function () {
                if (!this.areThereItems()) {
                    if (this.areThereFilters()) {
                        return this.$filter('translate')('No data is available for current selection. Please update the filters and try again.');
                    }
                    else {
                        if (this.isLoading) {
                            return this.$filter('translate')('Loading...');
                        }
                        else {
                            return this.$filter('translate')('No results found');
                        }
                    }
                }
                if (this.isSearching()) {
                    return this.$filter('translate')('Search results');
                }
                else {
                    return this.$filter('translate')('Instant find');
                }
            };
            instantFindComponentController.prototype.onFocusedSearch = function () {
                this.isInputSearchActive = true;
            };
            instantFindComponentController.prototype.onBlurSearch = function () {
                this.isInputSearchActive = false;
            };
            instantFindComponentController.prototype.isSearchActive = function () {
                return this.isSearching() || this.isInputSearchActive;
            };
            instantFindComponentController.prototype.isPersonItem = function (item) {
                return item.resultType === 'person';
            };
            instantFindComponentController.prototype.extractPageApplicationData = function (data) {
                var content = '';
                data.forEach(function (item, index) {
                    var row = item.id + '\t'
                        + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                        + item.resultType + '\t'
                        + item.data.displayName + '\t'
                        + item.data.url + '\t'
                        + item.data.isNewWindow + '\t'
                        + item.description + '\t'
                        + item.data.subtext + '\t'
                        + item.requestor.name + '\t'
                        + item.requestor.email + '\t'
                        + item.isInstantFind + '\t'
                        + item.isFrequentLink + '\t'
                        + item.tags.join(';') + '\t';
                    content += index < data.length ? row + '\n' : row;
                });
                return content;
            };
            instantFindComponentController.prototype.extractDdtData = function (data) {
                var content = '';
                data.forEach(function (item, index) {
                    var row = item.id + '\t'
                        + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                        + item.resultType + '\t'
                        + item.data.displayName + '\t'
                        + item.data.url + '\t'
                        + item.data.isNewWindow + '\t'
                        + item.data.function + '\t'
                        + item.data.category + '\t'
                        + item.tags.join(';') + '\t';
                    content += index < data.length ? row + '\n' : row;
                });
                return content;
            };
            instantFindComponentController.prototype.extractSubissueData = function (data) {
                var content = '';
                data.forEach(function (item, index) {
                    var row = item.id + '\t'
                        + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                        + item.resultType + '\t'
                        + item.data.id + '\t'
                        + item.data.displayName + '\t'
                        + item.data.categories.map(function (category) {
                            return category.displayName;
                        }).join(';') + '\t'
                        + item.tags.join(';') + '\t';
                    content += index < data.length ? row + '\n' : row;
                });
                return content;
            };
            instantFindComponentController.prototype.extractOfficeData = function (data) {
                var content = '';
                data.forEach(function (item, index) {
                    var row = item.id + '\t'
                        + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                        + item.resultType + '\t'
                        + item.data.displayName + '\t'
                        + item.data.city + '\t'
                        + item.data.state + '\t'
                        + item.data.country + '\t'
                        + item.data.postalCode + '\t'
                        + item.data.mainLine + '\t'
                        + item.data.address.split('\n').join(' ') + '\t'
                        + item.data.location + '\t'
                        + item.data.url + '\t'
                        + item.tags.join(';') + '\t';
                    content += index < data.length ? row + '\n' : row;
                });
                return content;
            };
            instantFindComponentController.prototype.getContentForType = function (resultType, data) {
                var content = 'data:text/csv;charset=utf-8,Entity ID\tMember Firm\tResult type\t';
                switch (resultType) {
                    case 'office':
                        content += 'Display name\tCity\tState\tCountry\tPostal code\tMain line\tAddress\tGeo coordinates\tBook room\tTags\n';
                        content += this.extractOfficeData(data);
                        break;
                    case 'application':
                        content += 'Title\tLaunch Url\tOpen in new window\tDescription\tType\tRequestor name\tRequestor email\tInstant Find\tFrequently used link\tTags\n';
                        content += this.extractPageApplicationData(data);
                        break;
                    case 'page':
                        content += 'Title\tLaunch Url\tOpen in new window\tDescription\tSource\tRequestor name\tRequestor email\tInstant Find\tFrequently used link\tTags\n';
                        content += this.extractPageApplicationData(data);
                        break;
                    case 'subissue':
                        content += 'Issue ID\tIssue name\tCategories\tTags\n';
                        content += this.extractSubissueData(data);
                        break;
                    case 'ddt':
                        content += 'Title\tLaunch Url\tOpen in new window\tFunction\tCategory\tTags\n';
                        content += this.extractDdtData(data);
                        break;
                    default:
                        return null;
                }
                return content;
            };
            instantFindComponentController.prototype.exportData = function (resultType) {
                var self = this;
                this.shouldDisableExportButton = true;
                this.instantFindService.getResultItems(0, self.MAX_INT, resultType.toLowerCase()).then(function (result) {
                    var stringContent = self.getContentForType(resultType, result.items);
                    var content = encodeURI(stringContent);
                    var link = document.createElement('a');
                    link.setAttribute('href', content);
                    link.setAttribute('download', 'InstantFind_' + resultType + (resultType === 'ddt' ? '' : 's') + '.xls');
                    document.body.appendChild(link);
                    setTimeout(function () {
                        link.click();
                    }, 500);
                    document.body.removeChild(link);
                    self.shouldDisableExportButton = false;
                });
            };
            return instantFindComponentController;
        }());
        instantFindComponentController.$inject = ['$filter', '$location', '$rootScope', 'instantFindService', 'alertService', 'securityService'];
        instantFindComponentController_1.instantFindComponentController = instantFindComponentController;
    })(instantFindComponentController = app.instantFindComponentController || (app.instantFindComponentController = {}));
})(app || (app = {}));
;
//# sourceMappingURL=instantFind.controller.js.map