﻿module app.services {
    export class siteRequestFieldService {
        
        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings
        ) { }

        /**
         * Retrieve a list of site requests
         * @param options Request parameters
         */
        get(options?: IGetSiteRequestFieldOptions): ng.IPromise<IPaginatedResult<ISiteRequestFieldResponseItem>> {
            return this.$http
                .get(this.appSettings.apiUrl + "/siteRequestFields", { params: options || {} })
                .then(result => result.data);
        }
       
    }

    export interface IGetSiteRequestFieldOptions {
        /**
         * Filters results to fields for a specific member firm by key
         */
        firm?: string;

        /**
         * Format - int32. Number of records to skip
         */
        skip?: number;


        /**
         * Format - int32. Number of records to retrieve
         */
        take?: number;        
    }

    export interface ISiteRequestFieldResponseItem {
        dataType?: string;
        controlTye?: string;
        firm?: string;
        id?: string;
        isRequired?: boolean;
        label?: string;
        message?: string;
        name?: string;
        values?: string[];
    }

    function siteRequestFieldServiceFactory($rootElement): siteRequestFieldService {
        const inj = $rootElement.injector();
        return inj.instantiate(siteRequestFieldService);
    }
    angular.module("SPApp").factory("siteRequestFieldService", ["$rootElement", $rootElement => siteRequestFieldServiceFactory($rootElement)]);
}
