var app;
(function (app) {
    var components;
    (function (components) {
        var alert;
        (function (alert) {
            var alertComponentController = (function () {
                function alertComponentController() {
                }
                return alertComponentController;
            }());
            alert.alertComponentController = alertComponentController;
        })(alert = components.alert || (components.alert = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=alert.controller.js.map