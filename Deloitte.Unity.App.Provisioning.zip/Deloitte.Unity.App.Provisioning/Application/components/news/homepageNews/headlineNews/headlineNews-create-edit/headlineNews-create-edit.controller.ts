﻿module app.components.news.homepageNews {

    export class headlineNewsCreateEditController extends genericNewsCreateEditController {

        static $inject = ["rearrangeUtils","$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService,
                /*pageTitleOnEditAll*/ "Edit headline news layout",
                /*pageTitleOnEditById*/ "Edit headline news",
                /*pageTitleOnCreate*/ "Create headline news",
                /*maxItems*/ 8,
                /*region*/ "Thumbnail",
                /*listPath*/ "/news/homepageNews/headlineNews");
        }

    }
}