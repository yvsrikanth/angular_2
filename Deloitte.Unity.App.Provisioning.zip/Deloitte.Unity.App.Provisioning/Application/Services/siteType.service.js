var app;
(function (app) {
    var services;
    (function (services) {
        var siteTypeService = (function () {
            function siteTypeService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            /**
             * Retrieve a list of site requests
             * @param options Request parameters
             */
            siteTypeService.prototype.get = function (options) {
                return this.$http
                    .get(this.appSettings.apiUrl + "/siteTypes", { params: options || {} })
                    .then(function (result) { return result.data; });
            };
            return siteTypeService;
        }());
        siteTypeService.$inject = ["$http", "appSettings"];
        services.siteTypeService = siteTypeService;
        function siteTypeServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(siteTypeService);
        }
        angular.module("SPApp").factory("siteTypeService", ["$rootElement", function ($rootElement) { return siteTypeServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=siteType.service.js.map