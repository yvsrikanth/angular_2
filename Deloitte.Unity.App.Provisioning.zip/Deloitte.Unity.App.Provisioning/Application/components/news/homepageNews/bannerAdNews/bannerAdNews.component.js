var app;
(function (app) {
    var directives;
    (function (directives) {
        var bannerAdNewsComponent = (function () {
            function bannerAdNewsComponent() {
                this.controller = app.components.bannerAdNews.bannerAdNewsComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews.component.html";
                this.controllerAs = "bannerAdNews";
            }
            return bannerAdNewsComponent;
        }());
        angular.module("SPApp").component("bannerAdNews", new bannerAdNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews.component.js.map