var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var thumbnailNews;
                (function (thumbnailNews) {
                    var expandedThumbnailNewsThumbnailsPreviewComponent = {
                        bindings: {
                            news: "<",
                            maxItems: "<",
                            skipSort: "<"
                        },
                        controller: news.genericNewsLayoutPreviewController,
                        templateUrl: "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-thumbnailsPreview/thumbnailNews-thumbnailsPreview.html",
                        controllerAs: "vm"
                    };
                    angular.module("SPApp").component("expandedThumbnailNewsThumbnailsPreview", expandedThumbnailNewsThumbnailsPreviewComponent);
                })(thumbnailNews = expandedpageNews.thumbnailNews || (expandedpageNews.thumbnailNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-thumbnailsPreview.component.js.map