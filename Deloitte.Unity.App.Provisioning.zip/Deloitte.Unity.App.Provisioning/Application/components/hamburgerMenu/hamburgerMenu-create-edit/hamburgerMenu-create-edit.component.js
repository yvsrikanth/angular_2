var app;
(function (app) {
    var directives;
    (function (directives) {
        var hamburgerMenuCreateEditComponent = (function () {
            function hamburgerMenuCreateEditComponent() {
                this.bindings = {
                    firm: "<",
                    hamburgerMenuItem: "<"
                };
                this.controller = app.hamburgerMenuCreateEditController.hamburgerMenuCreateEditComponentController;
                this.templateUrl =
                    '/Application/components/hamburgerMenu/hamburgerMenu-create-edit/hamburgerMenu-create-edit.html';
                this.controllerAs = "hamburgerMenuEditor";
            }
            return hamburgerMenuCreateEditComponent;
        }());
        directives.hamburgerMenuCreateEditComponent = hamburgerMenuCreateEditComponent;
        angular.module('SPApp').component('hamburgerMenuCreateEdit', new hamburgerMenuCreateEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-create-edit.component.js.map