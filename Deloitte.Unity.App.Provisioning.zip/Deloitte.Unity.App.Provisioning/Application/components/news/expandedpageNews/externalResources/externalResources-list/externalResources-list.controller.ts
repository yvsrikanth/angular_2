﻿module app.expandedExternalResourcesListController {

    export class externalResourcesListComponentController {

        static $inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];

        firm: string;
        externalResourcesItems: any;
        userPermissions: security.shared.IModulePermissions;
        columns: any;

        constructor(
            private $scope,
            private $rootScope,
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $routeParams
        ) { }

        $onInit() {

            this.setMemberFirm();
            this.externalResources();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
                
            });
            this.setColumns();
        }

        externalResources() {

            this.newsService.get({ firm: this.firm, region: "external-links", take: 8 }).then(result => {
                this.externalResourcesItems = result.items;
            });


        }

        setColumns() {
            this.columns = ["Resource name", "Audience", "Author", "Updated date"];
        }


        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                this.firm = this.$routeParams.firm;
            }

        }

    }
}