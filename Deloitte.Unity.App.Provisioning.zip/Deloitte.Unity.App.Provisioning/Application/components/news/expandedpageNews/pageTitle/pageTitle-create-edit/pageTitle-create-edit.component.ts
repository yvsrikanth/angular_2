﻿module app.directives {

    class pageTitleCreateComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                contentTargetItem: '@'
            };
            this.controller=pageTitleCreateController.pageTitleCreateComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/pageTitle/pageTitle-create-edit/pageTitle-create-edit.html";
            this.controllerAs = "pageTitleCreateVm";
        }

    }

    angular.module('SPApp').component('pageTitleCreate', new pageTitleCreateComponent());

}