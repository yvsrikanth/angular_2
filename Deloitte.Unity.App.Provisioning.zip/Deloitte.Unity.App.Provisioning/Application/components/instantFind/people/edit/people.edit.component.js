var app;
(function (app) {
    var directives;
    (function (directives) {
        var peopleEditComponent = (function () {
            function peopleEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/people/edit/people.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return peopleEditComponent;
        }());
        angular.module('SPApp').component('peopleEdit', new peopleEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=people.edit.component.js.map