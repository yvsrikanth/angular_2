var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationLauncherComponent = (function () {
            function applicationLauncherComponent() {
                this.bindings = {
                    headlineNewsItem: '@'
                };
                this.controller = app.applicationLauncherController.applicationLauncherComponentController;
                this.templateUrl = '/Application/components/applicationLauncher/applicationLauncher.html';
                this.controllerAs = "applicationLauncherVm";
            }
            return applicationLauncherComponent;
        }());
        angular.module('SPApp').component('applicationLauncher', new applicationLauncherComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher.component.js.map