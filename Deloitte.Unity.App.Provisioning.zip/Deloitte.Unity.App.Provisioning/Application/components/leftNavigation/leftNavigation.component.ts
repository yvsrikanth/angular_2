﻿module app.directives {

    class leftNavigationComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                leftNavigationData: '=',
            };
            this.controller = app.leftNavigationController.leftNavigationController;
            this.templateUrl = '/Application/components/leftNavigation/leftNavigation.html'
            this.controllerAs = "leftNavVm"
        }

    }

    angular.module('SPApp').component('leftNavigation', new leftNavigationComponent());

}