﻿module app.services {
    export class audiencesService {

        static $inject = ['$http', 'appSettings'];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings) {
        }

        resourcePath = '/audiences/';

        /**
         * Retrieve a list of audiences
         * @param options Request parameters
         */
        get(options?: IGetAudiencesOptions) {
            return this.$http
                .get(this.appSettings.apiUrl + this.resourcePath, { params: options || {} })
                .then(result => result.data);
        }

        /**
         * Retrieves a single audience by id
         * @param id Unique identifier or key for the audience
         * @param include Requests that optional fields or data be embedded in the response
         */
        getById(id: string, ...include: string[]) {
            var includes = include ? include.join(",") : "";
            return this.$http
                .get(this.appSettings.apiUrl + this.resourcePath + id, { params: { include: includes } })
                .then(result => result.data);
        }
    }

    /**
     * Request parameters
     */
    export interface IGetAudiencesOptions {
        /**
         * Format - int32. Number of records to skip
         */
        skip?: number;

        /**
         * Format - int32. Number of records to retrieve
         */
        take?: number;

        /**
         * Comma separated list of firm Keys
         */
        key?: string;
    }

    function myServiceFactory($rootElement): audiencesService {
        const inj = $rootElement.injector();
        return inj.instantiate(audiencesService);
    }
    angular.module("SPApp").factory('audiencesService',
        ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}