var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var headlineNews;
                (function (headlineNews) {
                    var externalResourcesCreateEditComponent = {
                        bindings: {},
                        controller: headlineNews.externalResourcesCreateEditController,
                        templateUrl: "/Application/components/news/expandedpageNews/externalResources/externalResources-create-edit/externalResources-create-edit.html",
                        controllerAs: "externalResourcesCreateEdit"
                    };
                    angular.module('SPApp').component('externalResourcesCreateEdit', externalResourcesCreateEditComponent);
                })(headlineNews = expandedpageNews.headlineNews || (expandedpageNews.headlineNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-create-edit.component.js.map