﻿module app.applicationLauncherCreateEditController {

    export class applicationLauncherCreateEditController {

        static $inject = [
            "$scope", "applicationLauncherService", "contentTargetingService", "$location", "$routeParams", "alertService", "rearrangeUtils"
        ];

        firm: string;
        applicationLauncherList: any = [];
        applicationId: any;
        dateForToday: any;
        applist: any = [];
        isSubmit: boolean = false;
        veiwedPreview: boolean = false;
        previewWrng: String = '';
        actionType: String;
        appId: String;
        headerTitle: String;
        errorMessage: String;
        livePositionChange: boolean = true;
        ordinals = new Array<number>();

        public regex: any = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

        constructor(private $scope, private applicationLauncherService: services.applicationLauncherService, private contentTargetingService: services.contentTargetingService, private $location, private $routeParams, private alertService: components.alert.alertService, private rearrangeUtils: components.itemsWithOrdinal.RearrangeUtils) {

            var self = this;
            self.applicationId = this.$routeParams.id;
            self.actionType = this.checkIfIdPresent();
            self.firm = this.$routeParams.firm;
            self.getApplicationLauncherList(0, 8);

        }

        $onInit() {



        }

        checkUrlFilter(s: any) {
            if (s) {
                if (!s.match(/^[a-zA-Z]+:\/\//)) {
                    s = 'http://' + s;
                }
                return s;
            }
        }

        checkIfIdPresent(): string {
            let self = this;
            let actionType: string;
            var id = this.$routeParams.id;

            if (id) {

                if (id.toLowerCase() === "all") {
                    self.headerTitle = 'Edit application layout';
                    actionType = "editAll";
                } else {
                    self.headerTitle = 'Edit Application';
                    actionType = "edit";
                    self.appId = id;
                }

            } else {
                self.headerTitle = 'Add Application';
                actionType = "create";
            }
            return actionType;

        }

        getApplicationLauncherList(skip, take) {
            let self = this;
            var rightNow = new Date();
            var i: number = 0;
            self.dateForToday = rightNow.toISOString().slice(0, 10);
            self.applicationLauncherService.getPageList(skip, take, self.firm).then((data: any) => {
                self.applicationLauncherList = data.items[0];

                if (this.actionType === "create") {
                    self.applist.push({
                        ordinal: 1,
                        title: "",
                        url: ""
                    });
                    i = 1;
                }
                else if (this.actionType === "editAll"){
                    i = 0;
                }

                for (var j = 0; j < self.applicationLauncherList.navigation.appLauncher.length; j++) {

                    let obj = {
                        ordinal: j + i + 1,
                        title: self.applicationLauncherList.navigation.appLauncher[j].title,
                        url: self.applicationLauncherList.navigation.appLauncher[j].url

                    };

                    self.applist.push(obj);

                }
                for (var i = 0; i < self.applist.length; i++) {
                    this.ordinals.push(i + 1);
                }
            });
        }
        onClear(item: any) {
            item.title = "";
            item.url = "";
            item.ordinal = '';

        }

        insertNewApplication() {
            let self = this;
            self.applist.push({
                ordinal: self.applist.length + 1,
                title: "",
                url: ""
            });
            this.ordinals.push(self.applist.length);
        }

        //Method called when clicked Preivew layout icon.
        updatePreview() {
            let self = this;
            this.isSubmit = false;
            let changedId = 0;
            self.veiwedPreview = true;

            if (self.actionType === "edit") {

                for (let i = 0; i < self.applicationLauncherList.navigation.appLauncher.length; i++) {
                    if (self.applicationLauncherList.navigation.appLauncher[i].title === self.appId) {
                        changedId = i;
                    }
                }

                let changedItem = self.applist[changedId];
                self.applist.splice(changedId, 1);
                self.applist.splice(changedItem.ordinal, 0, changedItem);
                changedId = changedItem.ordinal;

            } else {

                self.applist.sort((a, b) => {
                    return (a.ordinal - b.ordinal);

                });
            }

            self.applicationLauncherList.navigation.appLauncher = [];
            angular.copy(self.applist, self.applicationLauncherList.navigation.appLauncher);

            if (self.actionType === "edit") {
                self.appId = self.applicationLauncherList.navigation.appLauncher[changedId].title;
            }

        }

        updateRecords(form) {
            let self = this;
            self.isSubmit = true;
            if (form.$valid) {

                let applicationlist = self.applicationLauncherList.navigation.appLauncher.filter((item) => {
                    return item.ordinal !== '';
                });
                self.applicationLauncherList.navigation.appLauncher = applicationlist;

                self.applicationLauncherList.navigation.appLauncher.map((item) => {
                     delete item.ordinal;
                });

                if (self.veiwedPreview) {
                    self.applicationLauncherService
                        .deleteApplicationItem(self.applicationLauncherList.id, self.applicationLauncherList)
                        .then(() => {

                            self.$location.path("applicationLauncher");
                        }, response => {
                            self.isSubmit = false;
                            if (response.status === 400) {

                                this.errorMessage = response.data.message;

                            } else {
                                this.alertService.show({
                                    buttons: app.components.alert.AlertButtons.Accept,
                                    title: response.statusText,
                                    message: response.data.message,
                                    dismissText: "Ok"
                                });
                            }
                        });

                } else {
                    // please preview the app !
                    self.previewWrng = " Please preview the applisting !";
                }
            }
        }

        verifyDuplicate(index, item) {

            let selectedValue = item.ordinal;
            let self = this;
            var sorted, i, isDuplicate;
            let obj = {
                ordinal: selectedValue
            }

            if (this.livePositionChange) {
                this.rearrangeUtils.rearrangeOrdinals(item, self.applist);
                return false;
            }

            sorted = self.applist.concat().sort((a, b) => {
                if (a.ordinal > b.ordinal) return 1;
                if (a.ordinal < b.ordinal) return -1;
                return 0;
            });

            for (i = 0; i < self.applist.length; i++) {
                isDuplicate = ((sorted[i - 1] && sorted[i - 1].ordinal === sorted[i].ordinal) || (sorted[i + 1] && sorted[i + 1].ordinal === sorted[i].ordinal));
                sorted[i].form.position.$setValidity('duplicate', !isDuplicate);
            }

        };



    }
}