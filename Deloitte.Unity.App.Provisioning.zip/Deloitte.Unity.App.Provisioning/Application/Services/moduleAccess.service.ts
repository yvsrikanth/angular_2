﻿﻿module app.services {

    export class moduleAccessService {

        static $inject = ["$http", "appSettings"];

        constructor(private $http: ng.IHttpService, private appSettings: IAppSettings) {
        }

        path = "/roles/";

        getModuleAccess(skip: number, take: number, firm: string, sort?: string) {
            
            var options : any = { skip: skip, take: take, firms: firm };

            if (sort)
                options.sort = sort;

            return this.$http
                .get(this.appSettings.apiUrl + this.path, { params: options })
                .then(result => {
                    var queryResult: any = result.data;

                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }

                    return queryResult;
                });
        }

        getModuleAccessItem(id) {

            return this.$http.get(this.appSettings.apiUrl + this.path + id).then(result => result.data);
        }

        deleteModuleAccessItem(id) {

            return this.$http.delete(this.appSettings.apiUrl + this.path + id).then(result => result);
        }

        createModuleAccess(data, isNew : boolean) {

            if (isNew) {
                data.description = data.displayName;
                data.created = new Date().toISOString().slice(0, 10);
                return this.$http.post(this.appSettings.apiUrl + this.path, data).then(result => result);
            }

            return this.$http.put(this.appSettings.apiUrl + this.path + data.id, data).then(result => result);
        }

    }

    angular.module("SPApp").service("moduleAccessService", moduleAccessService);
}
