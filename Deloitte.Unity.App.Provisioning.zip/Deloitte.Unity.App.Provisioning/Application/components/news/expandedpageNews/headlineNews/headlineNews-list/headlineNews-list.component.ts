﻿namespace app.directives {
    export class expandedHeadlineNewsListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = expandedHeadlineNewsListController.headlineNewsListComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews-list/headlineNews-list.component.html";
            this.controllerAs = "headlineNewsList";
        }
    }
    angular.module("SPApp").component("expandedHeadlineNewsList", new expandedHeadlineNewsListComponent());
}