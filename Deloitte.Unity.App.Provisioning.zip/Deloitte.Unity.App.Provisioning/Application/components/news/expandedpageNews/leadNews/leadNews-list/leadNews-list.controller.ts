﻿module app.expandedLeadNewsListController {

    export class leadNewsListComponentController {

        static $inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];

        firm: string;
        leadNewsItems: any;
        userPermissions: security.shared.IModulePermissions;
        columns: any;

        constructor(
            private $scope,
            private $rootScope,
            private newsService: services.newsService,
            private securityService: security.shared.securityService,
            private $routeParams
        ) {}

        $onInit() {

            this.setMemberFirm();
            this.leadsNew();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
            this.setColumns();
        }

        leadsNew() {

             this.newsService.get({ firm: this.firm, region: "Lead", take: 4 }).then(result => {
                this.leadNewsItems = result.items;
            });
            

        }

        setColumns() {
            this.columns = ["News title", "Audience", "Author", "Updated date"];
        }


        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                this.firm = this.$routeParams.firm;
            }
            
        }

    }
}