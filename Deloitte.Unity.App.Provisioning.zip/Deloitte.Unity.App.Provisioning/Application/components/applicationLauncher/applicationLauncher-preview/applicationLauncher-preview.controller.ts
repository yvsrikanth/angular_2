﻿module app.applicationLauncherPreviewController {
    export class applicationLauncherPreviewController {
        static $inject = ['$scope', '$rootScope', '$http', '$location', '$routeParams', 'contentTargetingService', 'applicationLauncherService'];
        public applicationLauncherList: any;
        public url: any;
        public appLauncherId: any;
        public appLauncherPreviewItem: any = [];
        public dateForToday: any;
        public itemsPerPage: Number;
        public query: any;
        public isPreview: any;
        location: ng.ILocationService;
        http: ng.IHttpService;
        public firm: String;

        constructor(private $scope, private $rootScope, $http: ng.IHttpService, $location: ng.ILocationService, private $routeParams, private contentTargetingService: services.contentTargetingService, private applicationLauncherService: services.applicationLauncherService) {

            let self = this;
            self.http = $http;
            self.url = window.location.href;
            self.location = $location;
            self.firm = this.$routeParams.firm; // contentTargetingService.getFirmName();
            self.appLauncherId = $routeParams.id;
            self.itemsPerPage = 8;
            self.query = {
                skip: 0,
                take: self.itemsPerPage
            };


        }

        $onInit() {
            let self = this;
            var rightNow = new Date();
            self.appLauncherPreviewItem = [];
            this.getApplicationLauncherList(0, this.itemsPerPage);
            self.dateForToday = rightNow.toISOString().slice(0, 10);
            self.isPreview = (self.location.path() === "/applicationLauncher/preview");
           
        };




        getApplicationLauncherList(skip, take) {
            let self = this;
            var rightNow = new Date();
            self.dateForToday = rightNow.toISOString().slice(0, 10);
            self.applicationLauncherService.getPageList(skip, take, this.firm).then((data: any) => {
                self.applicationLauncherList = data.items[0].navigation.appLauncher;
            });
        }



        getaudienceName(audiences: any): any {
            let newarr = [];
            if (audiences.length > 0) {

                for (var i = 0; i < audiences.length; i++) {

                    this.contentTargetingService.getSelectedAudiencesData(audiences[i])
                        .then((res: any) => {
                            newarr.push(res.displayName);
                        });
                }
            }
            return newarr;
        }

        //check if to show Dummy text.
        checkvalidation(item: any): Boolean {
            let self = this;
            var isvalid: Boolean = false;
           if (self.isPreview) {
               return true;
           }else if((self.isPreview === false) && (item.title === self.appLauncherId)) {
                    isvalid = true;
                }
           return isvalid;
        }
    }

}