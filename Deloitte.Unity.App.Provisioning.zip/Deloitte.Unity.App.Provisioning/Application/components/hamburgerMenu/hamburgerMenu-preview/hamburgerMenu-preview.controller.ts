﻿module app.hamburgerMenuPreviewController {
    export class hamburgerMenuPreviewComponentController {

        static $inject = ["$location", "$routeParams", "hamburgerMenuService", "securityService", "contentTargetingService"];

        firm: any;
        firmKey: string;
        hamburgerMenuItem: components.hamburgerMenu.ICategory;
        userPermissions: security.shared.IModulePermissions;
        currentLevel: string;
        audiences: any;

        constructor(
            private $location,
            private $routeParams,
            private hamburgerMenuService: services.hamburgerMenuService,
            private securityService: security.shared.securityService,
            private contentTargetingService: services.contentTargetingService) {
        }

        $onInit() {

            this.currentLevel = this.$routeParams.level;
            this.firmKey = this.$routeParams.firm;
            this.getHamburgerItem();
            
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firmKey];
            });
        }

        getHamburgerItem() {

            this.hamburgerMenuService.getFirmByKey(this.firmKey).then((result: any) => {
                this.firm = result.items[0];
                let index = 1;
                for (let item of this.firm.navigation.mainMenu) {
                    if (item.code === this.$routeParams.code) {
                        this.hamburgerMenuItem = item;
                        this.hamburgerMenuItem["position"] = index;
                        break;
                    }
                    index++;
                }
                this.setSubcategoryPositions();               
            });
        }

        setSubcategoryPositions() {

            if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items)) return;

            let index = 1;
            for (let item of this.hamburgerMenuItem.items) {
                item.position = index;
                let subIndex = 1;
                if (!angular.isDefined(item.items)) return;
                for (let subItem of item.items) {
                    subItem["position"] = subIndex;
                    subIndex++;
                }

                index++;
            }
        }        
        
    }
}