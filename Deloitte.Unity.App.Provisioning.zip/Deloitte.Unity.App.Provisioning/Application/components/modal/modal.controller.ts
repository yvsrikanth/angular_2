﻿module app.components.modal {
    export class modalComponentController {

        title: string;
        message: string;
        onConfirm: () => void;
        onDismiss: () => void;
        confirmText: string;
        dismissText: string;
        noDismiss: boolean;
        buttons: components.alert.AlertButtons;
        modalId: string;
        accent: string;
        size: string;
        submitDisabled: string;

        static $inject = ["$timeout"];
        constructor(private $timeout: any) {

        }

        $onInit() {
            $(`#${this.modalId}`).on("hidden.bs.modal", () => {
                if (this.onDismiss) {
                    this.$timeout(this.onDismiss());
                }
            });
        }

        onClickDismiss(modalId) {
            $(`#${modalId}`).modal("hide");
        }
    }
}