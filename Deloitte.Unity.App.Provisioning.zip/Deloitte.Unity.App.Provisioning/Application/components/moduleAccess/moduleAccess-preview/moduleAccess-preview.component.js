var app;
(function (app) {
    var directives;
    (function (directives) {
        var moduleAccessPreviewComponent = (function () {
            function moduleAccessPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.moduleAccessPreviewController.moduleAccessPreviewComponentController;
                this.templateUrl = "/Application/components/moduleAccess/moduleAccess-preview/moduleAccess-preview.html";
                this.controllerAs = "moduleAccessPreview";
            }
            return moduleAccessPreviewComponent;
        }());
        angular.module("SPApp").component("moduleAccessPreview", new moduleAccessPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-preview.component.js.map