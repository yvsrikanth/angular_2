﻿namespace app.directives {
    export class hamburgerMenuCreateEditComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<",
                hamburgerMenuItem: "<"
            };
            this.controller = hamburgerMenuCreateEditController.hamburgerMenuCreateEditComponentController;
            this.templateUrl =
                '/Application/components/hamburgerMenu/hamburgerMenu-create-edit/hamburgerMenu-create-edit.html';
            this.controllerAs = "hamburgerMenuEditor";
        }
    }

    angular.module('SPApp').component('hamburgerMenuCreateEdit', new hamburgerMenuCreateEditComponent());
}