var app;
(function (app) {
    var services;
    (function (services) {
        var userAttributesService = (function () {
            function userAttributesService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
                this.resourcePath = "/userattributes/";
            }
            /**
             * Retrieve a list of news articles
             * @param options Request parameters
             */
            userAttributesService.prototype.get = function () {
                var params = { params: { skip: 0, take: 999999 } };
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath, params)
                    .then(function (result) { return result.data; });
            };
            /**
             * Retrieves a single news article by id
             * @param id Unique identifier or key for the news article
             * @param include Requests that optional fields or data be embedded in the response
             */
            userAttributesService.prototype.getById = function (id) {
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath + id)
                    .then(function (result) { return result.data; });
            };
            return userAttributesService;
        }());
        userAttributesService.$inject = ["$http", "appSettings"];
        services.userAttributesService = userAttributesService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(userAttributesService);
        }
        angular.module("SPApp").factory('userAttributesService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=userattributes.service.js.map