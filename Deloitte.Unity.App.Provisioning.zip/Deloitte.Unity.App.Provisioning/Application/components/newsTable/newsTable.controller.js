var app;
(function (app) {
    var components;
    (function (components) {
        var newsTable;
        (function (newsTable) {
            var newsTableComponentController = (function () {
                function newsTableComponentController($scope, $q, securityService, audienceService, alertService, newsService, firmService, userService, paginatedListFactory) {
                    this.$scope = $scope;
                    this.$q = $q;
                    this.securityService = securityService;
                    this.audienceService = audienceService;
                    this.alertService = alertService;
                    this.newsService = newsService;
                    this.firmService = firmService;
                    this.userService = userService;
                    this.paginatedListFactory = paginatedListFactory;
                    this.columnNames = ["items", "audiences", "modifiedBy", "modified"];
                    this.paginatedList = this.paginatedListFactory.instance();
                }
                newsTableComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.paginatedList.sortMethods["newsTitle"] = function (a, b) {
                        var castedA = a;
                        var castedB = b;
                        if (castedA[0].title.toLowerCase && castedB[0].title.toLowerCase)
                            return (castedA[0].title.toLowerCase() > castedB[0].title.toLowerCase() ? 1 : -1);
                        else
                            return (castedA[0].title > castedB[0].title ? 1 : -1);
                    };
                    this.loadAudiences();
                    this.securityService.getUserPermissions().then(function (permissions) {
                        _this.userPermissions = permissions[_this.firm];
                    });
                    this.paginatedList.take = 8;
                    this.reverse = false;
                    this.today = new Date().toISOString().slice(0, 10);
                };
                newsTableComponentController.prototype.$onChanges = function (changes) {
                    this.getAuthorName();
                    this.setDate();
                    if (changes.rows) {
                        this.paginatedList.setItems(this.rows || []);
                    }
                };
                newsTableComponentController.prototype.loadAudiences = function () {
                    var _this = this;
                    this.audienceService.getAudiencesData(this.firm).then(function (audiences) {
                        _this.audiences = audiences.items;
                    });
                };
                newsTableComponentController.prototype.getNameAudience = function (audienceId) {
                    var notFound = "Audience not found - " + audienceId;
                    if (!angular.isDefined(this.audiences) || audienceId === "") {
                        return notFound;
                    }
                    for (var _i = 0, _a = this.audiences; _i < _a.length; _i++) {
                        var audience = _a[_i];
                        if (audience.id === audienceId) {
                            return audience.displayName;
                        }
                    }
                    return notFound;
                };
                newsTableComponentController.prototype.getAudiencesList = function (audiences) {
                    this.audiencesByItem = [];
                    for (var _i = 0, audiences_1 = audiences; _i < audiences_1.length; _i++) {
                        var audience = audiences_1[_i];
                        this.audiencesByItem.push(this.getNameAudience(audience));
                    }
                };
                newsTableComponentController.prototype.getAuthorName = function () {
                    var _this = this;
                    if (!this.rows || this.rows.length <= 0)
                        return;
                    var ids = this.rows
                        .filter(function (item) { return item.modifiedBy && item.modifiedBy.toUpperCase() !== "SYSTEM" && item.modifiedBy.toUpperCase() !== "JOBS"; })
                        .map(function (i) { return i.modifiedBy; })
                        .filter(function (v, i, a) { return a.indexOf(v) === i; })
                        .join(",");
                    this.userService.getUserList(ids).then(function (data) {
                        for (var _i = 0, _a = _this.rows; _i < _a.length; _i++) {
                            var item = _a[_i];
                            var exist = false;
                            for (var _b = 0, _c = data.items; _b < _c.length; _b++) {
                                var author = _c[_b];
                                if (item.modifiedBy === author.id) {
                                    exist = true;
                                    item["author"] = author.attributes.name.first + " " + author.attributes.name.last;
                                    break;
                                }
                            }
                            if (!exist)
                                item["author"] = item.modifiedBy;
                        }
                    });
                };
                newsTableComponentController.prototype.deleteItem = function (item) {
                    var _this = this;
                    this.alertService.show({
                        buttons: components.alert.AlertButtons.AcceptCancel,
                        title: "Delete an entry ",
                        message: "The selected entry will be deleted. This action cannot be undone.",
                        dismissText: "Cancel",
                        confirmText: "Delete",
                        onConfirm: function () {
                            _this.onConfirmDeleteLeadNewsItem(item);
                            _this.alertService.close();
                        }
                    });
                };
                newsTableComponentController.prototype.setEnableItem = function (item) {
                    var _this = this;
                    if (item["$enableOptionDisabled"])
                        return;
                    var originalState = item.isEnabled;
                    item.isEnabled = !item.isEnabled;
                    item["$enableOptionDisabled"] = true;
                    this.newsService
                        .getById(item.id, "image")
                        .then(function (itemWithImg) {
                        itemWithImg.isEnabled = item.isEnabled;
                        return itemWithImg;
                    })
                        .then(function (itemWithImgEdited) {
                        return _this.newsService.put(itemWithImgEdited);
                    })
                        .catch(function () {
                        item.isEnabled = originalState;
                    })
                        .finally(function () {
                        item["$enableOptionDisabled"] = false;
                        if (item.isEnabled)
                            _this.setDisableAllItems(item);
                    });
                };
                newsTableComponentController.prototype.setDisableAllItems = function (item) {
                    var promises = [];
                    for (var index = 0; index < this.rows.length; index++) {
                        var row = this.rows[index];
                        //Identify items to disable
                        if (item.id !== row.id && row.isEnabled) {
                            row.isEnabled = false;
                            promises.push(this.newsService.put(row));
                        }
                    }
                    this.$q.all(promises).then(function () {
                    }, function () {
                    });
                };
                newsTableComponentController.prototype.setDetailsItem = function (data) {
                    sessionStorage.setItem("news-item", angular.toJson(data));
                };
                newsTableComponentController.prototype.onConfirmDeleteLeadNewsItem = function (item) {
                    var _this = this;
                    this.newsService.delete(item.id).then(function () {
                        _this.rows.splice(_this.rows.indexOf(item), 1);
                        _this.paginatedList.setItems(_this.rows);
                        if (!_this.rows.length) {
                            _this.deleteBlockname();
                        }
                    });
                };
                newsTableComponentController.prototype.deleteBlockname = function () {
                    var that = this;
                    this.firmService
                        .get({
                        key: this.firm
                    })
                        .then(function (response) {
                        if (response.items.length > 0) {
                            var item = response.items[0];
                            item.newsHeadlineTitle = "*";
                            return that.firmService.put(item);
                        }
                    });
                };
                newsTableComponentController.prototype.setDate = function () {
                    if (!this.rows || this.rows.length <= 0)
                        return;
                    for (var _i = 0, _a = this.rows; _i < _a.length; _i++) {
                        var row = _a[_i];
                        row.modified = new Date(row.modified).toISOString().slice(0, 10);
                    }
                };
                newsTableComponentController.prototype.sortBy = function (index) {
                    var column = index <= 1 ? "title" : (index === 2 ? "modifiedBy" : "modified");
                    if (!angular.isObject(this.rows))
                        return this.rows;
                    var array = [];
                    for (var row in this.rows) {
                        array.push(this.rows[row]);
                    }
                    array.sort(function (a, b) {
                        if (column === "title") {
                            return (a.items[0][column] > b.items[0][column] ? 1 : -1);
                        }
                        else {
                            return (a[column] > b[column] ? 1 : -1);
                        }
                    });
                    if (this.reverse)
                        array.reverse();
                    this.reverse = !this.reverse;
                    this.rows = array;
                };
                return newsTableComponentController;
            }());
            newsTableComponentController.$inject = ["$scope", "$q", "securityService", "contentTargetingService", "alertService", "newsService", "firmService", "userService", "clientSidePaginationFactory"];
            newsTable.newsTableComponentController = newsTableComponentController;
        })(newsTable = components.newsTable || (components.newsTable = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=newsTable.controller.js.map