var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedHeadlineNewsListComponent = (function () {
            function expandedHeadlineNewsListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.expandedHeadlineNewsListController.headlineNewsListComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews-list/headlineNews-list.component.html";
                this.controllerAs = "headlineNewsList";
            }
            return expandedHeadlineNewsListComponent;
        }());
        directives.expandedHeadlineNewsListComponent = expandedHeadlineNewsListComponent;
        angular.module("SPApp").component("expandedHeadlineNewsList", new expandedHeadlineNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-list.component.js.map