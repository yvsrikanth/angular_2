var app;
(function (app) {
    var contentTargetingDetailsController;
    (function (contentTargetingDetailsController) {
        var contentTargetingDetailsComponentController = (function () {
            function contentTargetingDetailsComponentController($scope, $rootScope, contentTargetingService, $http, userAttributesService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.contentTargetingService = contentTargetingService;
                this.userAttributesService = userAttributesService;
                var self = this;
                self.http = $http;
                self.url = window.location.href;
                self.contentTargetingId = self.url.substring(self.url.lastIndexOf('/') + 1);
            }
            contentTargetingDetailsComponentController.prototype.$onInit = function () {
                var _this = this;
                var rightNow = new Date();
                this.dateForToday = rightNow.toISOString().slice(0, 10);
                this.contentTargetingService.getContentTargetById(this.contentTargetingId)
                    .then(function (response) {
                    _this.contentTargetDetail = response;
                    _this.userAttributesService.get()
                        .then(function (response) {
                        var allAttributes = response['items'];
                        var _loop_1 = function (rule) {
                            var filteredAttribute = allAttributes.filter(function (a) { return a.id === rule.attribute; })[0];
                            if (filteredAttribute) {
                                rule.attribute = filteredAttribute.displayName;
                            }
                        };
                        for (var _i = 0, _a = _this.contentTargetDetail.rules; _i < _a.length; _i++) {
                            var rule = _a[_i];
                            _loop_1(rule);
                        }
                    });
                    _this.contentTargetDetail.created =
                        new Date(_this.contentTargetDetail.created).toISOString().slice(0, 10);
                });
            };
            ;
            contentTargetingDetailsComponentController.prototype.goToEdit = function (data) {
                window.location.href = "#/contentTargeting/edit/" + data;
            };
            return contentTargetingDetailsComponentController;
        }());
        contentTargetingDetailsComponentController.$inject = ['$scope', '$rootScope', 'contentTargetingService', '$http', 'userAttributesService'];
        contentTargetingDetailsController.contentTargetingDetailsComponentController = contentTargetingDetailsComponentController;
    })(contentTargetingDetailsController = app.contentTargetingDetailsController || (app.contentTargetingDetailsController = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-details.controller.js.map