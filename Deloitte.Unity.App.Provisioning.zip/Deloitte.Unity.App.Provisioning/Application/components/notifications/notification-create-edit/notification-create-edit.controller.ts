﻿module app.components.notificationCreateEditController {

    export class notificationCreateEditController extends components.news.genericNewsCreateEditController {

        static $inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService,
                "",
                "Edit notifications",
                "Create notifications",
                1,
                "homepage-notifications",
                "/notifications/" + ($routeParams.actives === "false" ? "disabled" : "active") );
        }

        fetchItems(id?: string) {
            
            if (id) {
                this.newsService
                    .getById(id)
                    .then(item => {
                        this.items = [item];
                        this.setItemsToPreview(this.items);
                        return this.items;
                    });
            }
        }
        getEmptyItem(ordinal: number, id?: string) {
            let tmp = super.getEmptyItem(ordinal, id);
            return tmp;
        }

        save(checkPreviewChange) {
            this.setItemsToPreview(this.items);
            super.save(checkPreviewChange);
        }
    }
}