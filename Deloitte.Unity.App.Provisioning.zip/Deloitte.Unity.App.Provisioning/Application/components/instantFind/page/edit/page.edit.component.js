var app;
(function (app) {
    var directives;
    (function (directives) {
        var pageEditComponent = (function () {
            function pageEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/page/edit/page.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return pageEditComponent;
        }());
        angular.module('SPApp').component('pageEdit', new pageEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=page.edit.component.js.map