var app;
(function (app) {
    var services;
    (function (services) {
        var contentTargetingService = (function () {
            function contentTargetingService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            contentTargetingService.prototype.deleteAudience = function (data) {
                var id = data.id;
                delete data['id'];
                delete data['authorAttributes'];
                //console.log(config);
                return this.$http.delete(this.appSettings.apiUrl + "/audiences/" + id, data);
            };
            contentTargetingService.prototype.contentTargetingCreate = function (id, reData, isNew) {
                if (!isNew) {
                    return this.$http.put(this.appSettings.apiUrl + "/audiences/" + id, reData);
                }
                else {
                    return this.$http.post(this.appSettings.apiUrl + "/audiences/", reData);
                }
            };
            contentTargetingService.prototype.getContentTarget = function (key, skip, take, sort) {
                var queryParams = { skip: skip, take: take, firms: key };
                if (sort) {
                    queryParams.sort = sort;
                }
                return this.$http
                    .get(this.appSettings.apiUrl + "/audiences", { params: queryParams })
                    .then(function (result) {
                    var queryResult = result.data;
                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }
                    return queryResult;
                });
            };
            contentTargetingService.prototype.getAudiencesData = function (key) {
                var queryParams = { key: key };
                return this.$http.get(this.appSettings.apiUrl + "/audiences", { params: queryParams }).then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.getAudiencesByKey = function (key) {
                return this.$http.get(this.appSettings.apiUrl + "/audiences/?firms=" + key).then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.getContentTargetById = function (id) {
                return this.$http.get(this.appSettings.apiUrl + "/audiences/" + id).then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.firmData = function () {
                if (localStorage.getItem("firmId") == null) {
                    localStorage.setItem("firmId", "0a68db4d-994d-420a-afa5-0b6ed25a782b");
                }
                var firmId = localStorage.getItem("firmId");
                this.firmItems = this.$http.get(this.appSettings.apiUrl + "/firms/" + firmId).then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.memberFirmData = function () {
                return this.$http.get(this.appSettings.apiUrl + "/firms/").then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.getAttributesList = function () {
                return this.$http.get("/Application/components/contentTargeting/contentTargeting-create-edit/jsonData/attributesList.json").then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.setFirm = function (firm) {
                this.selectedFirm = firm;
            };
            contentTargetingService.prototype.getFirmName = function () {
                return this.selectedFirm;
            };
            contentTargetingService.prototype.setAudienceId = function (id) {
                this.selectedAudienceId = id;
            };
            contentTargetingService.prototype.getAudienceId = function () {
                return this.selectedAudienceId;
            };
            contentTargetingService.prototype.getSelectedAudiencesData = function (id) {
                return this.$http.get(this.appSettings.apiUrl + "/audiences/" + id).then(function (result) { return result.data; });
            };
            contentTargetingService.prototype.updateSelectedAudiencesData = function (id, data) {
                return this.$http.put(this.appSettings.apiUrl + "/audiences/" + id, data).then(function (result) { return result.data; });
            };
            return contentTargetingService;
        }());
        contentTargetingService.$inject = ["$http", "appSettings"];
        services.contentTargetingService = contentTargetingService;
        angular.module("SPApp").service("contentTargetingService", contentTargetingService);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting.service.js.map