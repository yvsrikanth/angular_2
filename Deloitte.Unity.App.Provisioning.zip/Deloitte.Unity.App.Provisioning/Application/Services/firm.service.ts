﻿/// <reference path="../app.settings.ts" />
/// <reference path="services.model.ts" />
/// <reference path="../../scripts/typings/angularjs/angular.d.ts" />
module app.services {
    export class firmService {

        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings
        ) { }

        /**
         * Retrieves a single member firm by id
         * @param id Unique identifier or key for the member firm
         */
        get(id: string): ng.IPromise<IFirmResponseItem>;

        /**
         * Retrieve a list of site requests
         * @param options Request parameters
         */
        get(options?: IGetFirmsOptions): ng.IPromise<IPaginatedResult<IFirmResponseItem>>;
        get(options?: IGetFirmsOptions | string): ng.IPromise<IPaginatedResult<IFirmResponseItem> | IFirmResponseItem>{
            var result;
            if (!options || (typeof options === "object")) {
                result = this.$http
                    .get(this.appSettings.apiUrl + "/firms", { params: options || {} });
            } else {
                result = this.$http
                    .get(this.appSettings.apiUrl + "/firms/" + options);
            }
            return result
                .then(result => {
                    var queryResult: any = result.data;

                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }

                    return queryResult;
                });
        }

        put(data: IFirmResponseItem): ng.IPromise<any> {
            return this.$http
                .put(this.appSettings.apiUrl + "/firms/" + data.id, data)
                .then(response => response.data);
        }

    }

    export interface IGetFirmsOptions {
        /**
         * Comma separated list of firm IDs
         */
        id?: string;

        /**
         * Comma separated list of firm Keys
         */
        key?: string;

        /**
         * Format - int32. Number of records to skip
         */
        skip?: number;

        /**
         * Format - int32. Number of records to retrieve
         */
        take?: number;
    }

    export interface IFirmResponseItem {
        attributes?: string[];
        features?: any[];
        id?: string;
        footer?: string;
        key?: string;
        language?: string;
        name?: string;
        navigation?: any;
        newsHeadlineTitle?: string;
        newsPageTitle?: string;
        omnitureRsid?: string;
        publishingStorage?: number;
        teamsiteStorage?: number;
        timezone?: number;
        created?: string; 
        createdBy?: string; 
    }

    function siteFirmServiceFactory($rootElement): firmService {
        const inj = $rootElement.injector();
        return inj.instantiate(firmService);
    }
    angular.module("SPApp").factory("firmService", ["$rootElement", $rootElement => siteFirmServiceFactory($rootElement)]);
}
