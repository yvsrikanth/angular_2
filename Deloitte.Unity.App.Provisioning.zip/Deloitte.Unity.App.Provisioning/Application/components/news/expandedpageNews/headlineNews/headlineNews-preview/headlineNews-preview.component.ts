﻿module app.directives {

    class expandedHeadlineNewsPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = expandedHeadlineNewsPreviewController.headlineNewsPreviewComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews-preview/headlineNews-preview.html";
            this.controllerAs = "headlinePreview";
        }

    }

    angular.module("SPApp").component("expandedHeadlineNewsPreview", new expandedHeadlineNewsPreviewComponent());

}