﻿module app {
    declare var unityConfigKeys: any;
    
    export interface IAdalSettings {
        instance: string;
        tenant: string;
        clientId: string;
        aadEndpoints: { [identifier: string]: string };
        redirectUrl: string;
        viewportMatrix: any;
    }
    export interface IAppSettings {
        adal: IAdalSettings;
        apiUrl: string;
        subscriptionId: string;
    }

    let aadEndpoints = <any>{
        "https://graph.microsoft.com": "https://graph.microsoft.com",
        "https://resources.deloitte.com": "https://resources.deloitte.com",
        "https://outlook.office.com": "https://outlook.office.com"
    };
    aadEndpoints[unityConfigKeys.apiMapKey] = unityConfigKeys.apiMapValue;
    aadEndpoints[unityConfigKeys.alertsAadApiKey] = unityConfigKeys.alertsAadApiValue;


    export const appSettings = <IAppSettings>{
        adal: {
            instance: "https://login.microsoftonline.com/",
            tenant: "deloitte.com",
            clientId: unityConfigKeys.clientId,
            redirectUrl: unityConfigKeys.redirectUrl,
            aadEndpoints: aadEndpoints,
            viewportMatrix: () => {

                var w = window,
                    d = w.document,
                    de = d.documentElement,
                    db = d.body || d.getElementsByTagName("body")[0],
                    x = w.innerWidth || de.clientWidth || db.clientWidth,
                    y = w.innerHeight || de.clientHeight || db.clientHeight;

                return { width: x, height: y };
            }
        },
        apiUrl: unityConfigKeys.unityApiEndpointUrl,
        subscriptionId: unityConfigKeys.unityApiSubscriptionKey
    };

    angular.module("SPApp").constant("appSettings", appSettings);
}