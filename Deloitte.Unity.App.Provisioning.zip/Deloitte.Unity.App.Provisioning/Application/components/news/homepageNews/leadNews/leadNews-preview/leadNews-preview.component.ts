﻿module app.directives {

    class leadNewsPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = leadNewsPreviewController.leadNewsPreviewComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/leadNews/leadNews-preview/leadNews-preview.html";
            this.controllerAs = "leadNewsPreview";
        }

    }

    angular.module("SPApp").component("leadNewsPreview", new leadNewsPreviewComponent());

}