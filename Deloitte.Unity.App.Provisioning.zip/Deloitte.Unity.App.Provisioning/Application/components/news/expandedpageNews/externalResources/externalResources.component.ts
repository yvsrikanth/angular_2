﻿module app.directives {

    class expandedExternalResourcesComponent implements ng.IComponentOptions {

        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.controller = components.expandedExternalResources.externalResourcesComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources.component.html";
            this.controllerAs = "externalResources";
        }

    }

    angular.module("SPApp").component("expandedExternalResources", new expandedExternalResourcesComponent());

}