﻿module app.components.news.expandedpageNews.leadNews {
    export class expandedLeadNewsCreateEditController extends genericNewsCreateEditController {

        static $inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService","alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "Edit lead news", "Edit lead news", "Create lead news", 2, "Lead", "/news/expandedpageNews/leadNews");
            this.selectedLayout = this.layouts[0];
        }

        layouts = ["Column 1 - Image / Column 2 - Title", "Column 1 - Title / Column 2 - Image", "Image only"];
        selectedLayout: string;

        onFetchItems() {
            if (this.items && this.items.length)
                this.selectedLayout = this.items[0].layout;
        }

        onChangeLayout() {
            for (var index = 0; index < this.items.length; index++) {
                this.items[index].layout = this.selectedLayout;
            }
        }

        getEmptyItem(ordinal: number, id?: string) {
            var tmpResult = super.getEmptyItem(ordinal, id);
            tmpResult.layout = this.selectedLayout;
            return tmpResult;
        }
    }
}