var app;
(function (app) {
    var directives;
    (function (directives) {
        var leftNavigationComponent = (function () {
            function leftNavigationComponent() {
                this.bindings = {
                    leftNavigationData: '=',
                };
                this.controller = app.leftNavigationController.leftNavigationController;
                this.templateUrl = '/Application/components/leftNavigation/leftNavigation.html';
                this.controllerAs = "leftNavVm";
            }
            return leftNavigationComponent;
        }());
        angular.module('SPApp').component('leftNavigation', new leftNavigationComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leftNavigation.component.js.map