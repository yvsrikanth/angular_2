﻿module app.directives {

    class expandedExternalResourcesPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = expandedExternalResourcesPreviewController.externalResourcesPreviewComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources-preview/externalResources-preview.html";
            this.controllerAs = "externalResourcesPreview";
        }

    }

    angular.module("SPApp").component("expandedExternalResourcesPreview", new expandedExternalResourcesPreviewComponent());

}