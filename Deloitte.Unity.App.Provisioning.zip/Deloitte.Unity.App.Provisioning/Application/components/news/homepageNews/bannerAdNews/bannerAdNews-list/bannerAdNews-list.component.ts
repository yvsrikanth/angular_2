﻿namespace app.directives {
    export class bannerAdNewsListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = bannerAdNewsListController.bannerAdNewsListComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-list/bannerAdNews-list.component.html";
            this.controllerAs = "bannerAdNewsList";
        }
    }
    angular.module("SPApp").component("bannerAdNewsList", new bannerAdNewsListComponent());
}