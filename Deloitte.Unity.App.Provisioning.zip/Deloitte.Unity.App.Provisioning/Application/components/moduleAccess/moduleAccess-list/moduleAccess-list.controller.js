var app;
(function (app) {
    var moduleAccessListController;
    (function (moduleAccessListController) {
        var moduleAccessListComponentController = (function () {
            function moduleAccessListComponentController($scope, $rootScope, moduleAccessService, securityService, $routeParams, alertService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.moduleAccessService = moduleAccessService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
                this.alertService = alertService;
                this.totalCount = 0;
                this.sortCol = "DisplayName";
                this.asc = true;
                this.itemsPerPage = 8;
                this.query = {
                    skip: 0, take: this.itemsPerPage
                };
            }
            moduleAccessListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.moduleAccess(0, this.itemsPerPage);
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.setMemberFirm();
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            moduleAccessListComponentController.prototype.sort = function (col) {
                if (col === this.sortCol) {
                    this.asc = !this.asc;
                }
                else {
                    this.sortCol = col;
                    this.asc = true;
                }
                this.moduleAccess(this.query.skip, this.itemsPerPage);
            };
            moduleAccessListComponentController.prototype.getSortExpression = function () {
                return (this.asc ? '' : '-') + this.sortCol;
            };
            moduleAccessListComponentController.prototype.moduleAccess = function (skip, take) {
                var _this = this;
                this.moduleAccessService.getModuleAccess(skip, take, this.firm, this.getSortExpression())
                    .then(function (data) {
                    _this.query = data.query;
                    _this.moduleAccessItem = data.items;
                    _this.totalCount = data.totalCount;
                    _this.getGroupedData();
                });
            };
            moduleAccessListComponentController.prototype.getGroupedData = function () {
                for (var _i = 0, _a = this.moduleAccessItem; _i < _a.length; _i++) {
                    var item = _a[_i];
                    var modules = item.permissions.length > 0 ? [item.permissions[0].split("-")[0]] : [];
                    if (item.permissions.length > 0) {
                        for (var _b = 0, _c = item.permissions; _b < _c.length; _b++) {
                            var mod = _c[_b];
                            if (this.validateModuleExists(mod.split("-")[0], modules) === false) {
                                modules.push(mod.split("-")[0]);
                            }
                        }
                    }
                    item.permissions = modules;
                }
            };
            moduleAccessListComponentController.prototype.validateModuleExists = function (module, modules) {
                for (var _i = 0, modules_1 = modules; _i < modules_1.length; _i++) {
                    var mod = modules_1[_i];
                    if (mod === module) {
                        return true;
                    }
                }
                return false;
            };
            moduleAccessListComponentController.prototype.getModuleList = function (modules) {
                this.modulesList = modules;
            };
            moduleAccessListComponentController.prototype.deleteModuleAccessItem = function (item) {
                var _this = this;
                this.moduleId = item.id;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: 'Delete an entry ',
                    message: 'The selected entry will be deleted. This action cannot be undone.',
                    dismissText: 'Cancel',
                    confirmText: 'Delete',
                    onConfirm: function () {
                        _this.onConfirmDeleteModuleAccessItem(item);
                        _this.alertService.close();
                    }
                });
            };
            moduleAccessListComponentController.prototype.onConfirmDeleteModuleAccessItem = function (item) {
                var _this = this;
                this.moduleAccessService.deleteModuleAccessItem(this.moduleId).then(function () {
                    _this.moduleAccessItem.splice(_this.moduleAccessItem.indexOf(item), 1);
                    _this.moduleAccess(0, _this.itemsPerPage);
                });
            };
            moduleAccessListComponentController.prototype.setDetailsModuleAccessItem = function (data) {
                sessionStorage.setItem("module-access-item", angular.toJson(data));
            };
            moduleAccessListComponentController.prototype.setMemberFirm = function () {
                if (this.$routeParams.firm !== undefined && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return moduleAccessListComponentController;
        }());
        moduleAccessListComponentController.$inject = ["$scope", "$rootScope", "moduleAccessService", "securityService", "$routeParams", "alertService"];
        moduleAccessListController.moduleAccessListComponentController = moduleAccessListComponentController;
    })(moduleAccessListController = app.moduleAccessListController || (app.moduleAccessListController = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-list.controller.js.map