var app;
(function (app) {
    var directives;
    (function (directives) {
        var contentTargetingCreateComponent = (function () {
            function contentTargetingCreateComponent() {
                this.bindings = {
                    contentTargetItem: '@',
                };
                this.controller = app.contentTargetingCreateController.contentTargetingCreateComponentController;
                this.templateUrl = '/Application/components/contentTargeting/contentTargeting-create-edit/contentTargeting-create-edit.html';
                this.controllerAs = "contentTargetingCreateVm";
            }
            return contentTargetingCreateComponent;
        }());
        angular.module('SPApp').component('contentTargetingCreate', new contentTargetingCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-create-edit.component.js.map