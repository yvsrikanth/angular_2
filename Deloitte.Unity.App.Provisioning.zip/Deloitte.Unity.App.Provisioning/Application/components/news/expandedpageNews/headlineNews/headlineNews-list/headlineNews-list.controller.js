var app;
(function (app) {
    var expandedHeadlineNewsListController;
    (function (expandedHeadlineNewsListController) {
        var headlineNewsListComponentController = (function () {
            function headlineNewsListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            headlineNewsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setMemberFirm();
                this.headlineNews();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
                this.setColumns();
            };
            headlineNewsListComponentController.prototype.headlineNews = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "headline", take: 10 }).then(function (result) {
                    _this.headlineNewsItems = result.items;
                });
            };
            headlineNewsListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            headlineNewsListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return headlineNewsListComponentController;
        }());
        headlineNewsListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        expandedHeadlineNewsListController.headlineNewsListComponentController = headlineNewsListComponentController;
    })(expandedHeadlineNewsListController = app.expandedHeadlineNewsListController || (app.expandedHeadlineNewsListController = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-list.controller.js.map