﻿module app.services {
  

    export class pageTitleService {
        static $inject = ['$http','appSettings'];
        http: ng.IHttpService;
       

        public firmItems: any;
        public selectedFirm: any;
        public selectedAudienceId: String;
        public selectedFirmObj:any;

        path = "/firms/";

        constructor($http: ng.IHttpService, private appSettings: IAppSettings) {
            this.http = $http;          
        }

        deletePageTitle(newsId,reData) {
            return this.http.put(this.appSettings.apiUrl + this.path + newsId, reData);
              
        } 

        createEditPageTitle(newsId, reData) {
           
           return this.http.put(this.appSettings.apiUrl + this.path + newsId, reData);

        } 

        getPageList(skip, take, firm) {
            let configList = {
                params: {
                    "skip": skip,
                    "take": take,
                    "key" : firm
                }
            };
            return this.http.get(this.appSettings.apiUrl + this.path, configList).then(result => result.data);
        }

       getSelectedPageTitleData(firmId) {
           return this.http.get(this.appSettings.apiUrl + this.path + firmId).then(result => result.data);
        }

        setFirm(firm) {
            this.selectedFirm = firm;
        }
        setFirmObj(item) {
            this.selectedFirmObj = item;
        }
        getFirmObj() {
            return this.selectedFirmObj;
        }
        
       
        getFirmName() {
            return this.selectedFirm;
        }     
       
    }

    function myServiceFactory($rootElement): pageTitleService {
        const inj = $rootElement.injector();
        return inj.instantiate(pageTitleService);
    }
    angular.module("SPApp").factory('pageTitleService', ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}