﻿module app.components.news.expandedpageNews.thumbnailNews {
    var expandedThumbnailNewsThumbnailsPreviewComponent: ng.IComponentOptions = {

        bindings: {
            news: "<",
            maxItems: "<",
            skipSort: "<"
        },
        controller: genericNewsLayoutPreviewController,
        templateUrl: "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-thumbnailsPreview/thumbnailNews-thumbnailsPreview.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("expandedThumbnailNewsThumbnailsPreview", expandedThumbnailNewsThumbnailsPreviewComponent);
}