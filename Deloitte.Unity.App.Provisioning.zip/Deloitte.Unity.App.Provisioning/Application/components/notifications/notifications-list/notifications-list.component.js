var app;
(function (app) {
    var directives;
    (function (directives) {
        var notificationsListComponent = (function () {
            function notificationsListComponent() {
                this.bindings = {
                    firm: '=',
                    actives: "="
                };
                this.controller = app.notificationsListComponentController.notificationsListComponentController;
                this.templateUrl =
                    '/Application/components/notifications/notifications-list/notifications-list.html';
                this.controllerAs = "notificationsListCtrl";
            }
            return notificationsListComponent;
        }());
        directives.notificationsListComponent = notificationsListComponent;
        angular.module('SPApp').component('notificationsList', new notificationsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=notifications-list.component.js.map