﻿module app.directives {

    export class contentTargetingDetailsComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
                        
            this.controller = contentTargetingDetailsController.contentTargetingDetailsComponentController;
            this.templateUrl =
                '/Application/components/contentTargeting/contentTargeting-details/contentTargeting-details.html';
            this.controllerAs = "contentTargetingDetails";
        }
    }

    angular.module('SPApp').component('contentTargetingDetails', new contentTargetingDetailsComponent());

}