var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationLauncherCreateEditComponent = (function () {
            function applicationLauncherCreateEditComponent() {
                this.bindings = {
                    firm: "<",
                    id: "<"
                };
                this.controller = app.applicationLauncherCreateEditController.applicationLauncherCreateEditController;
                this.templateUrl =
                    '/Application/components/applicationLauncher/applicationLauncher-create-edit/applicationLauncher-create-edit.html';
                this.controllerAs = "appLunVm";
            }
            return applicationLauncherCreateEditComponent;
        }());
        directives.applicationLauncherCreateEditComponent = applicationLauncherCreateEditComponent;
        angular.module('SPApp').component('applicationLauncherCreateEdit', new applicationLauncherCreateEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-create-edit.component.js.map