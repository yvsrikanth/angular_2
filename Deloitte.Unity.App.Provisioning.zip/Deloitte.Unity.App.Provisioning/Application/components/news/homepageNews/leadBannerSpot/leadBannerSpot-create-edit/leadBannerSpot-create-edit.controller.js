var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var leadBannerSpotCreateEditComponentController = (function () {
                function leadBannerSpotCreateEditComponentController($scope, newsService, contentTargetingService, $routeParams, $location, alertService, $anchorScroll) {
                    this.$scope = $scope;
                    this.newsService = newsService;
                    this.contentTargetingService = contentTargetingService;
                    this.$routeParams = $routeParams;
                    this.$location = $location;
                    this.alertService = alertService;
                    this.$anchorScroll = $anchorScroll;
                    this.saving = false;
                    this.loading = false;
                    this.audiences = new Array();
                    this.onPreviewItems = false;
                    this.imgPreviewed = false;
                    this.regex = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
                }
                leadBannerSpotCreateEditComponentController.prototype.$onInit = function () {
                    this.firm = this.$routeParams.firm;
                    this.onCreate = true;
                    this.leadBannerSpot = {
                        audiences: new Array(),
                        ordinal: 1,
                        items: [{}],
                        firm: this.firm
                    };
                    this.getAudiences();
                    this.getRegionList();
                    this.getItems(this.$routeParams.id);
                };
                leadBannerSpotCreateEditComponentController.prototype.checkUrlFilter = function (s) {
                    if (s) {
                        if (!s.match(/^[a-zA-Z]+:\/\//)) {
                            s = 'http://' + s;
                        }
                        return s;
                    }
                };
                leadBannerSpotCreateEditComponentController.prototype.getAudiences = function () {
                    var _this = this;
                    this.contentTargetingService.getAudiencesData(this.firm)
                        .then(function (response) {
                        _this.audiences = response.items;
                    });
                };
                leadBannerSpotCreateEditComponentController.prototype.getAudienceName = function (id) {
                    for (var i = 0; i < this.audiences.length; i++) {
                        var aud = this.audiences[i];
                        if (aud.id === id) {
                            return aud.displayName;
                        }
                    }
                    return id;
                };
                leadBannerSpotCreateEditComponentController.prototype.getItems = function (id) {
                    var _this = this;
                    if (id != undefined) {
                        this.onCreate = false;
                        this.loading = true;
                        this.newsService.getById(id, "image")
                            .then(function (response) {
                            _this.loading = false;
                            _this.leadBannerSpot = response;
                            if (_this.leadBannerSpot.items[0].image != null) {
                                _this.radioValue = "image";
                                $('input[id=box1]').prop('checked', false);
                                $('input[id=box2]').prop('checked', true);
                                _this.previewImage = _this.leadBannerSpot.items[0].imageUrl;
                            }
                            else {
                                _this.radioValue = "html";
                                $('input[id=box1]').prop('checked', true);
                                $('input[id=box2]').prop('checked', false);
                                _this.previewHtmlContent = _this.leadBannerSpot.items[0].content;
                            }
                            _this.image = {
                                data: response.items[0].image,
                                name: response.items[0].imageUrl
                            };
                        });
                    }
                };
                leadBannerSpotCreateEditComponentController.prototype.onSelectAudience = function (audience) {
                    if (this.leadBannerSpot.audiences.indexOf(audience.id) === -1) {
                        this.leadBannerSpot.audiences.push(audience.id);
                    }
                };
                leadBannerSpotCreateEditComponentController.prototype.onRemoveAudience = function (id) {
                    var audIndex = this.leadBannerSpot.audiences.indexOf(id);
                    if (audIndex !== -1) {
                        this.leadBannerSpot.audiences.splice(audIndex, 1);
                    }
                };
                leadBannerSpotCreateEditComponentController.prototype.getRegionList = function () {
                    var _this = this;
                    this.newsService.getRegionList()
                        .then(function (response) {
                        _this.region = response.region;
                    });
                };
                leadBannerSpotCreateEditComponentController.prototype.onPreview = function () {
                    if (this.radioValue === "html") {
                        this.previewHtmlContent = this.leadBannerSpot.items[0].content;
                        this.previewImage = null;
                        this.leadBannerSpot.items[0].image = null;
                        this.leadBannerSpot.items[0].url = null;
                    }
                    else {
                        this.previewHtmlContent = null;
                        this.previewImage = this.image ? this.image.data : null;
                        this.leadBannerSpot.items[0].image = this.image ? this.image.data : null;
                        this.leadBannerSpot.items[0].content = null;
                    }
                    this.previewedItemsJson = angular.toJson(this.leadBannerSpot);
                    this.onPreviewItems = true;
                    this.imgPreviewed = true;
                };
                leadBannerSpotCreateEditComponentController.prototype.onChangeImg = function () {
                    this.imgPreviewed = false;
                };
                leadBannerSpotCreateEditComponentController.prototype.getImageText = function (item, img) {
                    return img && img.name ? img.name : ((item ? item.items[0].imageUrl : null) || "");
                };
                leadBannerSpotCreateEditComponentController.prototype.previewed = function () {
                    var currentItemsJson = angular.toJson(this.leadBannerSpot);
                    var dataPreviewed = currentItemsJson === this.previewedItemsJson;
                    return dataPreviewed && this.imgPreviewed;
                };
                leadBannerSpotCreateEditComponentController.prototype.onPublish = function (invalid) {
                    var _this = this;
                    if (invalid) {
                        this.$anchorScroll("mainView");
                        return;
                    }
                    this.onPreview();
                    this.leadBannerSpot.region = this.region[0].hiddenNews;
                    this.leadBannerSpot.items[0].description = "...";
                    this.leadBannerSpot.items[0].language = "...";
                    this.leadBannerSpot.layout = this.radioValue;
                    if (this.leadBannerSpot.items[0].title === undefined) {
                        this.leadBannerSpot.items[0].title = "...";
                    }
                    if (this.leadBannerSpot.items[0].url === undefined || this.leadBannerSpot.items[0].url === null) {
                        this.leadBannerSpot.items[0].url = "...";
                    }
                    if (this.leadBannerSpot.items[0].content === undefined || this.leadBannerSpot.items[0].content === null) {
                        this.leadBannerSpot.items[0].content = "...";
                    }
                    this.saving = true;
                    this.newsService.save(this.leadBannerSpot, !(this.$routeParams.id))
                        .then(function () {
                        _this.saving = false;
                        _this.$location.path("/news/homepageNews/leadBannerSpot");
                    }, function (error) {
                        _this.saving = false;
                        _this.alertService.show({
                            buttons: app.components.alert.AlertButtons.Accept,
                            title: error.statusText,
                            message: error.data.message,
                            dismissText: "Ok"
                        });
                    });
                };
                return leadBannerSpotCreateEditComponentController;
            }());
            leadBannerSpotCreateEditComponentController.$inject = [
                "$scope", "newsService", "contentTargetingService", "$routeParams", "$location", "alertService", "$anchorScroll"
            ];
            news.leadBannerSpotCreateEditComponentController = leadBannerSpotCreateEditComponentController;
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-create-edit.controller.js.map