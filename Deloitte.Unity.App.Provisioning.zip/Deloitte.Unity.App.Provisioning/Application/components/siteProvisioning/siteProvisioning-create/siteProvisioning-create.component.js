var app;
(function (app) {
    var components;
    (function (components) {
        var siteProvisioning;
        (function (siteProvisioning) {
            var siteProvisioningCreateComponentOptions = {
                bindings: {},
                controller: siteProvisioning.siteProvisioningCreateController,
                templateUrl: "/Application/components/siteProvisioning/siteProvisioning-create/siteProvisioning-create.component.html",
                controllerAs: "vm"
            };
            angular.module("SPApp").component("siteProvisioningCreate", siteProvisioningCreateComponentOptions);
        })(siteProvisioning = components.siteProvisioning || (components.siteProvisioning = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=siteProvisioning-create.component.js.map