﻿module app.directives {

    class expandedLeadNewsPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = expandedLeadNewsPreviewController.leadNewsPreviewComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews-preview/leadNews-preview.html";
            this.controllerAs = "leadNewsPreview";
        }

    }

    angular.module("SPApp").component("expandedLeadNewsPreview", new expandedLeadNewsPreviewComponent());

}