﻿module app.directives {

    class issueEditComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
            this.templateUrl = '/Application/components/instantFind/issue/edit/issue.edit.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('issueEdit', new issueEditComponent());
}