var app;
(function (app) {
    var hamburgerMenuPreviewController;
    (function (hamburgerMenuPreviewController) {
        var hamburgerMenuPreviewComponentController = (function () {
            function hamburgerMenuPreviewComponentController($location, $routeParams, hamburgerMenuService, securityService, contentTargetingService) {
                this.$location = $location;
                this.$routeParams = $routeParams;
                this.hamburgerMenuService = hamburgerMenuService;
                this.securityService = securityService;
                this.contentTargetingService = contentTargetingService;
            }
            hamburgerMenuPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.currentLevel = this.$routeParams.level;
                this.firmKey = this.$routeParams.firm;
                this.getHamburgerItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firmKey];
                });
            };
            hamburgerMenuPreviewComponentController.prototype.getHamburgerItem = function () {
                var _this = this;
                this.hamburgerMenuService.getFirmByKey(this.firmKey).then(function (result) {
                    _this.firm = result.items[0];
                    var index = 1;
                    for (var _i = 0, _a = _this.firm.navigation.mainMenu; _i < _a.length; _i++) {
                        var item = _a[_i];
                        if (item.code === _this.$routeParams.code) {
                            _this.hamburgerMenuItem = item;
                            _this.hamburgerMenuItem["position"] = index;
                            break;
                        }
                        index++;
                    }
                    _this.setSubcategoryPositions();
                });
            };
            hamburgerMenuPreviewComponentController.prototype.setSubcategoryPositions = function () {
                if (!angular.isDefined(this.hamburgerMenuItem) || !angular.isDefined(this.hamburgerMenuItem.items))
                    return;
                var index = 1;
                for (var _i = 0, _a = this.hamburgerMenuItem.items; _i < _a.length; _i++) {
                    var item = _a[_i];
                    item.position = index;
                    var subIndex = 1;
                    if (!angular.isDefined(item.items))
                        return;
                    for (var _b = 0, _c = item.items; _b < _c.length; _b++) {
                        var subItem = _c[_b];
                        subItem["position"] = subIndex;
                        subIndex++;
                    }
                    index++;
                }
            };
            return hamburgerMenuPreviewComponentController;
        }());
        hamburgerMenuPreviewComponentController.$inject = ["$location", "$routeParams", "hamburgerMenuService", "securityService", "contentTargetingService"];
        hamburgerMenuPreviewController.hamburgerMenuPreviewComponentController = hamburgerMenuPreviewComponentController;
    })(hamburgerMenuPreviewController = app.hamburgerMenuPreviewController || (app.hamburgerMenuPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-preview.controller.js.map