var app;
(function (app) {
    var leadNewsListController;
    (function (leadNewsListController) {
        var leadNewsListComponentController = (function () {
            function leadNewsListComponentController($scope, $rootScope, newsService, securityService, $routeParams, alertService, audienceService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
                this.alertService = alertService;
                this.audienceService = audienceService;
            }
            leadNewsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setMemberFirm();
                this.leadsNew();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
                this.setColumns();
            };
            leadNewsListComponentController.prototype.leadsNew = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "Carousal", take: 4 }).then(function (result) {
                    _this.leadNewsItems = result.items;
                });
            };
            leadNewsListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            leadNewsListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return leadNewsListComponentController;
        }());
        leadNewsListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams", "alertService", "contentTargetingService"];
        leadNewsListController.leadNewsListComponentController = leadNewsListComponentController;
    })(leadNewsListController = app.leadNewsListController || (app.leadNewsListController = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-list.controller.js.map