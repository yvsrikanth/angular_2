﻿module app.directives {
    export class moduleAccessListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = moduleAccessListController.moduleAccessListComponentController;
            this.templateUrl = "/Application/components/moduleAccess/moduleAccess-list/moduleAccess-list.component.html";
            this.controllerAs = "moduleAccessList";
        }
    }
    angular.module("SPApp").component("moduleAccessListComponent", new moduleAccessListComponent());
}