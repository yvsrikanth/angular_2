﻿module app.pageTitleCreateController {
    export class pageTitleCreateComponentController {

        static $inject = ['$scope', '$rootScope', 'pageTitleService', '$location', '$routeParams', 'contentTargetingService', 'alertService'];

        public pageListTitleItems: any;
        public pageTitleReqObj: any;

        memberFirmName: string = '';
        duplicatePageTitleError: string;
        validateFormField: boolean = false;
        newsPageTitle: string;
        actionType: string;
        headerTitle: string;
        newsId: any;
        itemsPerPage: number;
        isSubmited: boolean = false;

        constructor(
            private $scope,
            private $rootScope,
            private pageTitleService: services.pageTitleService,
            private $location: ng.ILocationService,
            private $routeParams,
            private contentTargetingService: services.contentTargetingService,
            private alertService
        ) { }

        $onInit() {
            this.itemsPerPage = 8;
            this.memberFirmName = this.$routeParams.firm;
            this.getPageListData(0, this.itemsPerPage);
            this.actionType = this.checkIfIdPresent();
            this.pageTitleReqObj = this.pageTitleService.getFirmObj();
            this.createAndEditInit();
        }

        getPageListData(skip, take) {
            let self = this;
            self.pageTitleService.getPageList(skip, take, self.memberFirmName).then((data: any) => {
                self.pageListTitleItems = data.items[0];
            });
        }



        checkIfIdPresent(): string {
            let actionType: string = '';

            var id = this.$routeParams.id;
            if (id) {
                if (id.toLowerCase() === "all") {
                    actionType = "edit";

                }
            }
            else {
                actionType = "create ";
            }

            return actionType;

        }
        createAndEditInit() {

            let self = this;

            self.pageTitleService.getPageList(0, self.itemsPerPage, self.memberFirmName).then((data: any) => {
                self.pageListTitleItems = data.items[0];
                self.newsId = self.pageListTitleItems.id;
                self.newsPageTitle = self.pageListTitleItems.newsPageTitle !== "*" ? self.pageListTitleItems.newsPageTitle : "";
                self.pageTitleReqObj = self.pageListTitleItems;
            });
            self.headerTitle = self.actionType === "edit" ? "Edit page title" : "Create page title";
        }
        backToPage() {

            this.$location.path('/news/expandedpageNews/pageTitle');
        }


        savePageTitle(form) {

            let self = this;
            self.isSubmited = true;

            self.validateFormField = true;
            self.pageTitleReqObj.newsPageTitle = self.newsPageTitle;
            if (!form.$valid) {
                self.isSubmited = false;
                return false;
            }

            if (self.actionType === "edit") {
                if (self.checkDuplicatePageTitle(self.newsPageTitle)) {
                    self.pageTitleService.createEditPageTitle(self.newsId, self.pageTitleReqObj).then(() => {
                        self.backToPage();
                    });
                }

            } else {
                if (self.checkDuplicatePageTitle(self.newsPageTitle)) {
                    self.pageTitleService.createEditPageTitle(self.pageTitleReqObj.id, self.pageTitleReqObj).then(() => {
                        self.backToPage();
                    });
                }
            }
        }

        checkDuplicatePageTitle(pageTitle: any): any {
            let self = this;
            let isValid: boolean = true;
            angular.forEach(self.pageListTitleItems, value1 => {
                if (value1.newsPageTitle === pageTitle) {
                    self.duplicatePageTitleError = "Page title name exists. Please enter a different name.";
                    isValid = false;
                    self.isSubmited = isValid;
                }
            });
            return isValid;
        }

    }
}