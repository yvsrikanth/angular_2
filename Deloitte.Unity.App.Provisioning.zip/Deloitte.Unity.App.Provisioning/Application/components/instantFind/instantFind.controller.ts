﻿module app.instantFindComponentController {
    declare var $;

    declare class checkItem {
        name: string;
        checked: boolean;
    }

    export class instantFindComponentController {
        static $inject = ['$filter', '$location', '$rootScope', 'instantFindService', 'alertService', 'securityService'];
        private types: Array<string> = new Array<string>();
        private memberFirms: Array<string> = new Array<string>();
        private allTypes: boolean;
        private allFirms: boolean;
        private items: Array<any>;
        private itemsPerPage: number = 8;
        private totalCount: number = 0;
        private params: any;
        private searchIndex: number = 0;
        private searchQuery: string;
        private isInputSearchActive: boolean = false;
        private filterTypesParam: string = '';
        private filterFirmsParam: string = '';
        private userPermissions: any;
        private isLoading: boolean = true;
        private shouldDisableExportButton: boolean = false;
        private MAX_INT: number = 999999;

        constructor(private $filter, private $location, private $rootScope,
            private instantFindService: services.instantFindService,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService) {

            this.allTypes = true;
            this.allFirms = true;
            this.searchQuery = '';
            this.params = {
                skip: 0,
                take: this.itemsPerPage,
                firm: '',
                resultType: '',
                query: ''
            };

            this.initialize();
        }

        initialize() {
            let self = this;

            this.securityService.getUserPermissions().then(function (data: any) {
                self.userPermissions = data;

                //for (var firm in data) {
                //    self.memberFirms.push(firm);
                //}
                self.memberFirms = ['US', 'UK', 'CH'];

                self.instantFindService.getTypes().then(function (data: any) {
                    self.types = data.items;
                    setTimeout(() => {
                        self.$rootScope.$apply();
                        self.searchResults();
                    }, 1000);
                });
            });
        }

        delete(item) {
            if (item.isUniversal || this.userPermissions[item.firm.trim()].instantFind.delete) {
                this.alertService.show({
                    buttons: components.alert.AlertButtons.AcceptCancel,
                    title: 'Delete item',
                    message: 'The action of deletion may take some time and cannot be undone.',
                    dismissText: 'Cancel',
                    confirmText: 'Delete',
                    onConfirm: () => {
                        this.deleteItem(item);
                        this.alertService.close();
                    }
                });
            } else {
                this.alertService.show({
                    buttons: components.alert.AlertButtons.Accept,
                    title: 'Action not allowed',
                    message: 'You do not have permissions to perform this action on '
                    + item.firm + ' member firm.',
                    dismissText: 'Ok',
                    onDismiss: () => {
                        this.alertService.close();
                    }
                });
            }
        }

        deleteItem(item) {
            this.instantFindService.deleteResultItem(item.id);
            this.search(this.params.skip, this.params.take);
        }

        getDisplayName(item) {
            if (this.isPersonItem(item)) {
                return item.data.preferredName + ' ' + item.data.lastName;
            } else {
                return item.data.displayName;
            }
        }

        search(skip: number, take: number) {
            let self = this;
            var localSearchIndex = ++this.searchIndex;
            self.isLoading = true;

            this.params.query = this.isSearching() ? this.searchQuery : '';

            this.instantFindService.search(skip, take, self.params.firm,
                self.params.query, self.params.resultType.toLowerCase()).then(function (data: any) {
                    if (localSearchIndex !== self.searchIndex) {
                        return;
                    }

                    self.params = data.query;
                    if (self.params.resultType == null) {
                        self.params.resultType = '';
                    }
                    if (self.params.firm == null) {
                        self.params.firm = '';
                    }
                    self.items = data.items;
                    self.totalCount = data.totalCount;

                    for (var i = 0; i < self.items.length; i++) {
                        self.items[i].resultType = self.items[i].resultType.toLowerCase();
                    }

                    self.isLoading = false;
                }, function () {
                    if (localSearchIndex !== self.searchIndex) {
                        return;
                    }
                });
        }

        searchResults() {
            this.params.skip = 0;
            this.search(0, this.itemsPerPage);
        }

        cancelSearch() {
            this.searchQuery = '';
            this.items = new Array<any>();
            this.searchResults();
        }

        isSearching() {
            return this.searchQuery !== '';
        }

        areThereItems() {
            return this.totalCount > 0;
        }

        areThereFilters() {
            return this.params.firm !== '' || this.params.resultType !== '';
        }

        shouldShowDeleteButton(item) {
            if (item.resultType === 'subissue' || item.resultType === 'person') {
                return false;
            }

            if (item.isUniversal) {
                return true;
            }

            return this.userPermissions[item.firm] && this.userPermissions[item.firm.trim()].instantFind.delete;
        }

        shouldShowEditButton(item) {
            if (item.isUniversal) {
                return true;
            }

            return this.userPermissions[item.firm] && this.userPermissions[item.firm.trim()].instantFind.update;
        }

        shouldShowCreateDropdown() {
            var count = 0;

            for (var firm in this.userPermissions) {
                if (this.userPermissions[firm].instantFind.create) {
                    count++;
                }
            }

            return count > 0;
        }

        getFirm(item) {
            return item.isUniversal ? this.$filter('translate')('Universal') : item.firm;
        }

        getTitleMessage() {
            if (!this.areThereItems()) {
                if (this.areThereFilters()) {
                    return this.$filter('translate')
                        ('No data is available for current selection. Please update the filters and try again.');
                } else {
                    if (this.isLoading) {
                        return this.$filter('translate')('Loading...');
                    } else {
                        return this.$filter('translate')('No results found');
                    }
                }
            }

            if (this.isSearching()) {
                return this.$filter('translate')('Search results');
            } else {
                return this.$filter('translate')('Instant find');
            }
        }

        onFocusedSearch() {
            this.isInputSearchActive = true;
        }

        onBlurSearch() {
            this.isInputSearchActive = false;
        }

        isSearchActive() {
            return this.isSearching() || this.isInputSearchActive;
        }

        isPersonItem(item) {
            return item.resultType === 'person';
        }

        extractPageApplicationData(data) {
            var content = '';
            data.forEach(function (item, index) {
                var row = item.id + '\t'
                    + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                    + item.resultType + '\t'
                    + item.data.displayName + '\t'
                    + item.data.url + '\t'
                    + item.data.isNewWindow + '\t'
                    + item.description + '\t'
                    + item.data.subtext + '\t'
                    + item.requestor.name + '\t'
                    + item.requestor.email + '\t'
                    + item.isInstantFind + '\t'
                    + item.isFrequentLink + '\t'
                    + item.tags.join(';') + '\t';
                content += index < data.length ? row + '\n' : row;
            });

            return content;
        }

        extractDdtData(data) {
            var content = '';
            data.forEach(function (item, index) {
                var row = item.id + '\t'
                    + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                    + item.resultType + '\t'
                    + item.data.displayName + '\t'
                    + item.data.url + '\t'
                    + item.data.isNewWindow + '\t'
                    + item.data.function + '\t'
                    + item.data.category + '\t'
                    + item.tags.join(';') + '\t';
                content += index < data.length ? row + '\n' : row;
            });

            return content;
        }

        extractSubissueData(data) {
            var content = '';
            data.forEach(function (item, index) {
                var row = item.id + '\t'
                    + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                    + item.resultType + '\t'
                    + item.data.id + '\t'
                    + item.data.displayName + '\t'
                    + item.data.categories.map(function (category) {
                        return category.displayName;
                    }).join(';') + '\t'
                    + item.tags.join(';') + '\t';
                content += index < data.length ? row + '\n' : row;
            });

            return content;
        }

        extractOfficeData(data) {
            var content = '';
            data.forEach(function (item, index) {
                var row = item.id + '\t'
                    + (item.isUniversal ? 'Universal' : item.firm) + '\t'
                    + item.resultType + '\t'
                    + item.data.displayName + '\t'
                    + item.data.city + '\t'
                    + item.data.state + '\t'
                    + item.data.country + '\t'
                    + item.data.postalCode + '\t'
                    + item.data.mainLine + '\t'
                    + item.data.address.split('\n').join(' ') + '\t'
                    + item.data.location + '\t'
                    + item.data.url + '\t'
                    + item.tags.join(';') + '\t';
                content += index < data.length ? row + '\n' : row;
            });

            return content;
        }

        getContentForType(resultType, data) {
            var content = 'data:text/csv;charset=utf-8,Entity ID\tMember Firm\tResult type\t';

            switch (resultType) {
                case 'office':
                    content += 'Display name\tCity\tState\tCountry\tPostal code\tMain line\tAddress\tGeo coordinates\tBook room\tTags\n';
                    content += this.extractOfficeData(data);
                    break;

                case 'application':
                    content += 'Title\tLaunch Url\tOpen in new window\tDescription\tType\tRequestor name\tRequestor email\tInstant Find\tFrequently used link\tTags\n';
                    content += this.extractPageApplicationData(data);
                    break;

                case 'page':
                    content += 'Title\tLaunch Url\tOpen in new window\tDescription\tSource\tRequestor name\tRequestor email\tInstant Find\tFrequently used link\tTags\n';
                    content += this.extractPageApplicationData(data);
                    break;

                case 'subissue':
                    content += 'Issue ID\tIssue name\tCategories\tTags\n';
                    content += this.extractSubissueData(data);
                    break;

                case 'ddt':
                    content += 'Title\tLaunch Url\tOpen in new window\tFunction\tCategory\tTags\n';
                    content += this.extractDdtData(data);
                    break;

                default:
                    return null;
            }
            
            return content;
        }

        exportData(resultType) {
            let self = this;
            this.shouldDisableExportButton = true;

            this.instantFindService.getResultItems(0, self.MAX_INT, resultType.toLowerCase()).then(function (result: any) {
                var stringContent = self.getContentForType(resultType, result.items);
                var content = encodeURI(stringContent);
                var link = document.createElement('a');
                link.setAttribute('href', content);
                link.setAttribute('download', 'InstantFind_' + resultType + (resultType === 'ddt' ? '' : 's') + '.xls');
                document.body.appendChild(link);
                setTimeout(function() {
                    link.click();
                }, 500);
                document.body.removeChild(link);
                self.shouldDisableExportButton = false;
            });
        }
    }
};