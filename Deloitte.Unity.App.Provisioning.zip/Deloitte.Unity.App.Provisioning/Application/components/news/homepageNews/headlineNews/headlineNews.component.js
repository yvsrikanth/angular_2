var app;
(function (app) {
    var directives;
    (function (directives) {
        var headlineNewsComponent = (function () {
            function headlineNewsComponent() {
                this.bindings = {
                    headlineNewsItem: '@'
                };
                this.controller = app.headlineNewsController.headlineNewsComponentController;
                this.templateUrl = '/Application/components/news/homepageNews/headlineNews/headlineNews.html';
                this.controllerAs = "headlineNews";
            }
            return headlineNewsComponent;
        }());
        angular.module('SPApp').component('headlineNews', new headlineNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews.component.js.map