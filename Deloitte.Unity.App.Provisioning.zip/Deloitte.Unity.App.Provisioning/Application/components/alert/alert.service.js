var app;
(function (app) {
    var components;
    (function (components) {
        var alert;
        (function (alert) {
            var AlertButtons;
            (function (AlertButtons) {
                AlertButtons[AlertButtons["None"] = 0] = "None";
                AlertButtons[AlertButtons["Accept"] = 1] = "Accept";
                AlertButtons[AlertButtons["AcceptCancel"] = 2] = "AcceptCancel";
            })(AlertButtons = alert.AlertButtons || (alert.AlertButtons = {}));
            var alertService = (function () {
                function alertService($rootScope, $timeout) {
                    this.$rootScope = $rootScope;
                    this.$timeout = $timeout;
                    if (!this.$rootScope.alertOptions) {
                        this.$rootScope.alertOptions = {};
                    }
                }
                alertService.prototype.show = function (options) {
                    var _this = this;
                    this.fixOptions(options);
                    this.$rootScope.alertOptions = options;
                    $("body").removeClass("modal-open");
                    $(".modal-backdrop").remove();
                    $(".modal-backdrop").off();
                    $("#modal-alert").removeData("bs.modal");
                    var modalOptions = {
                        backdrop: options.noDismiss ? "static" : true,
                        keyboard: !options.noDismiss,
                        show: true
                    };
                    $("#modal-alert").modal(modalOptions);
                    if (options.noDismiss) {
                        this.$timeout(function () {
                            $("#modal-alert").off("keydown");
                            $("#modal-alert").off("click");
                        });
                    }
                    else {
                        $("#modal-alert").on("hidden.bs.modal", function () {
                            if (options.onDismiss)
                                _this.$timeout(function () { return options.onDismiss(); });
                        });
                    }
                };
                alertService.prototype.close = function () {
                    $("#modal-alert").modal("hide");
                };
                alertService.prototype.fixOptions = function (options) {
                    if (!options.onConfirm) {
                        options.onConfirm = function () { $("#modal-alert").modal("hide"); };
                    }
                };
                return alertService;
            }());
            alertService.$inject = ["$rootScope", "$timeout"];
            alert.alertService = alertService;
            angular.module("SPApp").service("alertService", alertService);
        })(alert = components.alert || (components.alert = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=alert.service.js.map