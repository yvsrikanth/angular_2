﻿﻿module app.services {
    export class hamburgerMenuService {
        static $inject = ['$http', 'appSettings'];
        
        public firms: any[];

        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings) {

            this.firms = [];
        }

        deleteHamburgerMenuItem(firmKey: string, hamburgerMenuItem: components.hamburgerMenu.ICategory): ng.IPromise<any> {
            let self = this;
            return self.getFirmByKey(firmKey).then(result => {
                let firm = result.items[0];
                if (firm) {
                    let mainMenu = firm.navigation.mainMenu;
                    for (let index = 0; index < mainMenu.length; index++) {
                        if (mainMenu[index].title === hamburgerMenuItem.title) {
                            mainMenu.splice(index, 1);
                            break;
                        }
                    }
                    firm.navigation.mainMenu = mainMenu;
                    self.saveFirm(firm).then(() => {
                        return firm;
                    });
                }
            });
        }

        private getFirm(firmKey: string): ng.IPromise<any> {
            let self = this;
            for (let firm of self.firms) {
                if (firm.key === firmKey) {
                    return firm.value;
                }
            }
            return null;
        }

        getFirmByKey(firmKey: string): ng.IPromise<any> {
            let self = this;

            let promise = this.$http
                .get(this.appSettings.apiUrl + "/firms/?key=" + firmKey)
                .then(result => result.data);

            self.firms.push({
                key: firmKey,
                value: promise
            });

            return promise;
        }

        saveFirm(data: any): ng.IPromise<any> {
            return this.$http
                .put(this.appSettings.apiUrl + "/firms/" + data.id, data);
        }
    }

    function myServiceFactory($rootElement): hamburgerMenuService {
        const inj = $rootElement.injector();
        return inj.instantiate(hamburgerMenuService);
    }

    angular.module("SPApp").factory('hamburgerMenuService',
        ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}
