﻿module app.hamburgerMenuListController {
    export class hamburgerMenuListComponentController {
        static $inject = ["hamburgerMenuService", "securityService", "userService"];
        public hamburgerMenuItems: components.hamburgerMenu.ICategory[];
        public allHamburgerMenuItems: components.hamburgerMenu.ICategory[];

        public firm: any;
        public firmKey: string;
        public itemsPerPage: number;
        public query: any;
        public totalCount: any;
        public dateForToday: any;
        public userPermissions: security.shared.IFirmPermissions;

        sortColumn: string;
        reverse: boolean;


        constructor(private hamburgerMenuService: services.hamburgerMenuService,
            private securityService: security.shared.securityService, private userService: services.userService) {
            let self = this;

            let rightNow = new Date();
            self.dateForToday = rightNow.toISOString().slice(0, 10);

            self.itemsPerPage = 8;
            self.query = {
                skip: 0, take: self.itemsPerPage
            };

            self.getHamburgerMenu();
        }

        $onInit() {


            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
            });

            this.reverse = false;
            this.sortColumn = "title";
        }

        getHamburgerMenu() {
            let self = this;
            self.hamburgerMenuService.getFirmByKey(self.firmKey).then((result: any) => {
                self.firm = result.items[0];

                self.allHamburgerMenuItems = self.firm.navigation.mainMenu;
                self.totalCount = self.allHamburgerMenuItems.length;
                self.sortBy(this.sortColumn);
                //self.hamburgerMenu(0, self.itemsPerPage);
            });
        }

        hamburgerMenu(skip: number, take: number): void {
            let self = this;
            this.query = {
                skip: skip, take: take
            };
            self.hamburgerMenuItems = self.allHamburgerMenuItems.slice(skip, skip + take);

        }

        setAuthorNameAndCreate() {

            if (!this.firm || this.firm.length <= 0) return;

            if (this.firm.createdBy.toUpperCase() === "SYSTEM" || this.firm.createdBy.toUpperCase() === "JOBS" || this.firm.createdBy === "") {
                this.hamburgerMenuItems["createdBy"] = this.firm.createdBy;

            } else {

                this.userService.getUserList(this.firm.createdBy).then((data: any) => {
                    if (data.items.length > 0) {
                        this.hamburgerMenuItems["createdBy"] = data.items[0].attributes.name.first + " " + data.items[0].attributes.name.last;
                    } else {
                        this.hamburgerMenuItems["createdBy"] = this.firm.createdBy;
                    }

                });
            }

            this.hamburgerMenuItems["created"] = new Date(this.firm.created).toISOString().slice(0, 10);
        }

        getSubcategoryText(items: components.hamburgerMenu.ISubcategory[]): string {
            let total = items ? items.length : 0;
            if (total === 1) {
                return items[0].title;
            }
            return total + ' items';
        }

        getSubcategoryLinkText(items: components.hamburgerMenu.ISubcategory[]): string {
            let total = 0;
            let firstLinkText = '';
            for (var index = 0; items && index < items.length; index++) {
                if (items[index].items != undefined) {
                    if (firstLinkText === '') {
                        firstLinkText = items[index].items[0].title;
                    }
                    total += items[index].items.length;
                }
            }

            if (total === 1) {
                return firstLinkText;
            }
            return total + ' items';
        }

        delete(hamburgerMenuItem: components.hamburgerMenu.ICategory): void {
            let self = this;
            self.hamburgerMenuService.deleteHamburgerMenuItem(self.firmKey, hamburgerMenuItem)
                .then(() => {
                    self.allHamburgerMenuItems.splice(this.allHamburgerMenuItems.indexOf(hamburgerMenuItem), 1);
                    self.hamburgerMenuItems.splice(this.hamburgerMenuItems.indexOf(hamburgerMenuItem), 1);
                    self.totalCount = this.allHamburgerMenuItems.length;
                    self.hamburgerMenu(self.hamburgerMenuItems.length ? this.query.skip : 0, self.itemsPerPage);
                });
        }

        sortBy(column: string) {

            this.sortColumn = column;

            if (!angular.isObject(this.allHamburgerMenuItems)) return;

            var array: any = [];

            for (var item in this.allHamburgerMenuItems) {
                array.push(this.allHamburgerMenuItems[item]);
            }

            array.sort(function (a, b) {

                if (a[column] === undefined || a[column] === null) {
                    a[column] = "";
                }
                if (!b[column] === undefined || b[column] === null) {
                    b[column] = "";
                }

                if (a[column].toLowerCase && b[column].toLowerCase) {
                    return (a[column].toLowerCase() > b[column].toLowerCase() ? 1 : -1);
                } else {
                    return (a[column] > b[column] ? 1 : -1);
                }
            });

            if (this.reverse) array.reverse();
            this.reverse = !this.reverse;

            this.allHamburgerMenuItems = array;
            this.hamburgerMenu(0, this.itemsPerPage);
        }

    }
}