var app;
(function (app) {
    var pageTitleCreateController;
    (function (pageTitleCreateController) {
        var pageTitleCreateComponentController = (function () {
            function pageTitleCreateComponentController($scope, $rootScope, pageTitleService, $location, $routeParams, contentTargetingService, alertService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.pageTitleService = pageTitleService;
                this.$location = $location;
                this.$routeParams = $routeParams;
                this.contentTargetingService = contentTargetingService;
                this.alertService = alertService;
                this.memberFirmName = '';
                this.validateFormField = false;
                this.isSubmited = false;
            }
            pageTitleCreateComponentController.prototype.$onInit = function () {
                this.itemsPerPage = 8;
                this.memberFirmName = this.$routeParams.firm;
                this.getPageListData(0, this.itemsPerPage);
                this.actionType = this.checkIfIdPresent();
                this.pageTitleReqObj = this.pageTitleService.getFirmObj();
                this.createAndEditInit();
            };
            pageTitleCreateComponentController.prototype.getPageListData = function (skip, take) {
                var self = this;
                self.pageTitleService.getPageList(skip, take, self.memberFirmName).then(function (data) {
                    self.pageListTitleItems = data.items[0];
                });
            };
            pageTitleCreateComponentController.prototype.checkIfIdPresent = function () {
                var actionType = '';
                var id = this.$routeParams.id;
                if (id) {
                    if (id.toLowerCase() === "all") {
                        actionType = "edit";
                    }
                }
                else {
                    actionType = "create ";
                }
                return actionType;
            };
            pageTitleCreateComponentController.prototype.createAndEditInit = function () {
                var self = this;
                self.pageTitleService.getPageList(0, self.itemsPerPage, self.memberFirmName).then(function (data) {
                    self.pageListTitleItems = data.items[0];
                    self.newsId = self.pageListTitleItems.id;
                    self.newsPageTitle = self.pageListTitleItems.newsPageTitle !== "*" ? self.pageListTitleItems.newsPageTitle : "";
                    self.pageTitleReqObj = self.pageListTitleItems;
                });
                self.headerTitle = self.actionType === "edit" ? "Edit page title" : "Create page title";
            };
            pageTitleCreateComponentController.prototype.backToPage = function () {
                this.$location.path('/news/expandedpageNews/pageTitle');
            };
            pageTitleCreateComponentController.prototype.savePageTitle = function (form) {
                var self = this;
                self.isSubmited = true;
                self.validateFormField = true;
                self.pageTitleReqObj.newsPageTitle = self.newsPageTitle;
                if (!form.$valid) {
                    self.isSubmited = false;
                    return false;
                }
                if (self.actionType === "edit") {
                    if (self.checkDuplicatePageTitle(self.newsPageTitle)) {
                        self.pageTitleService.createEditPageTitle(self.newsId, self.pageTitleReqObj).then(function () {
                            self.backToPage();
                        });
                    }
                }
                else {
                    if (self.checkDuplicatePageTitle(self.newsPageTitle)) {
                        self.pageTitleService.createEditPageTitle(self.pageTitleReqObj.id, self.pageTitleReqObj).then(function () {
                            self.backToPage();
                        });
                    }
                }
            };
            pageTitleCreateComponentController.prototype.checkDuplicatePageTitle = function (pageTitle) {
                var self = this;
                var isValid = true;
                angular.forEach(self.pageListTitleItems, function (value1) {
                    if (value1.newsPageTitle === pageTitle) {
                        self.duplicatePageTitleError = "Page title name exists. Please enter a different name.";
                        isValid = false;
                        self.isSubmited = isValid;
                    }
                });
                return isValid;
            };
            return pageTitleCreateComponentController;
        }());
        pageTitleCreateComponentController.$inject = ['$scope', '$rootScope', 'pageTitleService', '$location', '$routeParams', 'contentTargetingService', 'alertService'];
        pageTitleCreateController.pageTitleCreateComponentController = pageTitleCreateComponentController;
    })(pageTitleCreateController = app.pageTitleCreateController || (app.pageTitleCreateController = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle-create-edit.controller.js.map