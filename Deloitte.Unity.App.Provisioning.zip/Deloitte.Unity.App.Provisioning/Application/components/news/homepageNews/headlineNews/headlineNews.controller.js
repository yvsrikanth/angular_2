var app;
(function (app) {
    var headlineNewsController;
    (function (headlineNewsController) {
        var headlineNewsComponentController = (function () {
            function headlineNewsComponentController($scope, $rootScope, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.securityService = securityService;
            }
            headlineNewsComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firms = Object.keys(_this.userPermissions).sort();
                });
            };
            return headlineNewsComponentController;
        }());
        headlineNewsComponentController.$inject = ['$scope', '$rootScope', 'securityService'];
        headlineNewsController.headlineNewsComponentController = headlineNewsComponentController;
    })(headlineNewsController = app.headlineNewsController || (app.headlineNewsController = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews.controller.js.map