var app;
(function (app) {
    var directives;
    (function (directives) {
        var pageTitleListComponent = (function () {
            function pageTitleListComponent() {
                this.bindings = {
                    firm: '='
                };
                this.controller = app.pageTitleListController.pageTitleListComponentController;
                this.templateUrl = '/Application/components/news/expandedpageNews/pageTitle/pageTitle-list/pageTitle-list.html';
                this.controllerAs = "pageTitleList";
            }
            return pageTitleListComponent;
        }());
        directives.pageTitleListComponent = pageTitleListComponent;
        angular.module('SPApp').component('pageTitleListComponent', new pageTitleListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle-list.component.js.map