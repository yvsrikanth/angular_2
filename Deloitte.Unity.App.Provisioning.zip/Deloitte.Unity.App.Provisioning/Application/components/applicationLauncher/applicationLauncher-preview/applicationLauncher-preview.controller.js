var app;
(function (app) {
    var applicationLauncherPreviewController;
    (function (applicationLauncherPreviewController_1) {
        var applicationLauncherPreviewController = (function () {
            function applicationLauncherPreviewController($scope, $rootScope, $http, $location, $routeParams, contentTargetingService, applicationLauncherService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.contentTargetingService = contentTargetingService;
                this.applicationLauncherService = applicationLauncherService;
                this.appLauncherPreviewItem = [];
                var self = this;
                self.http = $http;
                self.url = window.location.href;
                self.location = $location;
                self.firm = this.$routeParams.firm; // contentTargetingService.getFirmName();
                self.appLauncherId = $routeParams.id;
                self.itemsPerPage = 8;
                self.query = {
                    skip: 0,
                    take: self.itemsPerPage
                };
            }
            applicationLauncherPreviewController.prototype.$onInit = function () {
                var self = this;
                var rightNow = new Date();
                self.appLauncherPreviewItem = [];
                this.getApplicationLauncherList(0, this.itemsPerPage);
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.isPreview = (self.location.path() === "/applicationLauncher/preview");
            };
            ;
            applicationLauncherPreviewController.prototype.getApplicationLauncherList = function (skip, take) {
                var self = this;
                var rightNow = new Date();
                self.dateForToday = rightNow.toISOString().slice(0, 10);
                self.applicationLauncherService.getPageList(skip, take, this.firm).then(function (data) {
                    self.applicationLauncherList = data.items[0].navigation.appLauncher;
                });
            };
            applicationLauncherPreviewController.prototype.getaudienceName = function (audiences) {
                var newarr = [];
                if (audiences.length > 0) {
                    for (var i = 0; i < audiences.length; i++) {
                        this.contentTargetingService.getSelectedAudiencesData(audiences[i])
                            .then(function (res) {
                            newarr.push(res.displayName);
                        });
                    }
                }
                return newarr;
            };
            //check if to show Dummy text.
            applicationLauncherPreviewController.prototype.checkvalidation = function (item) {
                var self = this;
                var isvalid = false;
                if (self.isPreview) {
                    return true;
                }
                else if ((self.isPreview === false) && (item.title === self.appLauncherId)) {
                    isvalid = true;
                }
                return isvalid;
            };
            return applicationLauncherPreviewController;
        }());
        applicationLauncherPreviewController.$inject = ['$scope', '$rootScope', '$http', '$location', '$routeParams', 'contentTargetingService', 'applicationLauncherService'];
        applicationLauncherPreviewController_1.applicationLauncherPreviewController = applicationLauncherPreviewController;
    })(applicationLauncherPreviewController = app.applicationLauncherPreviewController || (app.applicationLauncherPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-preview.controller.js.map