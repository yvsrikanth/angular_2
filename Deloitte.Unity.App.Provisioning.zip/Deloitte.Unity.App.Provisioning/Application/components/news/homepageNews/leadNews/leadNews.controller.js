var app;
(function (app) {
    var components;
    (function (components) {
        var leadNews;
        (function (leadNews) {
            var leadNewsComponentController = (function () {
                function leadNewsComponentController($scope, $rootScope, securityService) {
                    this.$scope = $scope;
                    this.$rootScope = $rootScope;
                    this.securityService = securityService;
                }
                leadNewsComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.securityService.getUserPermissions().then(function (permissions) {
                        _this.userPermissions = permissions;
                        _this.firms = Object.keys(_this.userPermissions).sort();
                    });
                };
                return leadNewsComponentController;
            }());
            leadNewsComponentController.$inject = ["$scope", "$rootScope", "securityService"];
            leadNews.leadNewsComponentController = leadNewsComponentController;
        })(leadNews = components.leadNews || (components.leadNews = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews.controller.js.map