var app;
(function (app) {
    var services;
    (function (services) {
        var instantFindService = (function () {
            function instantFindService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
            }
            instantFindService.prototype.getResultItems = function (skip, take, resultType) {
                var queryParams = { skip: skip, take: take, resultType: resultType };
                return this.$http.get(this.appSettings.apiUrl + '/instantFind/results', { params: queryParams })
                    .then(function (result) { return result.data; });
            };
            instantFindService.prototype.getResultItem = function (id) {
                return this.$http.get(this.appSettings.apiUrl + '/instantFind/results/' + id)
                    .then(function (result) { return result.data; });
            };
            instantFindService.prototype.saveResultItem = function (item) {
                return this.$http.post(this.appSettings.apiUrl + '/instantFind/results', item);
            };
            instantFindService.prototype.updateResultItem = function (item) {
                return this.$http.put(this.appSettings.apiUrl + '/instantFind/results/' + item.id, item);
            };
            instantFindService.prototype.deleteResultItem = function (id) {
                return this.$http.delete(this.appSettings.apiUrl + '/instantFind/results/' + id);
            };
            instantFindService.prototype.getPeopleItems = function (skip, take) {
                var queryParams = { skip: skip, take: take };
                return this.$http.get(this.appSettings.apiUrl + "/users", { params: queryParams })
                    .then(function (result) { return result.data; });
            };
            instantFindService.prototype.getPeopleItem = function (id) {
                return this.$http.get(this.appSettings.apiUrl + "/users/" + id)
                    .then(function (result) { return result.data; });
            };
            instantFindService.prototype.updatePeopleItem = function (item) {
                return this.$http.post(this.appSettings.apiUrl + "/users/" + item.id + '/attributes', { attributes: item.attributes, deleteUnspecified: true });
            };
            instantFindService.prototype.search = function (skip, take, firm, query, resultType) {
                var queryParams = { skip: skip, take: take, firm: firm, query: query, resultType: resultType };
                return this.$http.get(this.appSettings.apiUrl + '/instantFind/search', { params: queryParams })
                    .then(function (result) { return result.data; });
            };
            instantFindService.prototype.getTypes = function () {
                return this.$http.get(this.appSettings.apiUrl + '/instantFind/resultTypes')
                    .then(function (result) { return result.data; });
            };
            return instantFindService;
        }());
        instantFindService.$inject = ["$http", "appSettings"];
        services.instantFindService = instantFindService;
        angular.module("SPApp").service('instantFindService', instantFindService);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=instantFind.service.js.map