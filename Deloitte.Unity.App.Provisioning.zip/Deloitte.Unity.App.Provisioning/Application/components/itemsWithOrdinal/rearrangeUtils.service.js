var app;
(function (app) {
    var components;
    (function (components) {
        var itemsWithOrdinal;
        (function (itemsWithOrdinal) {
            // ReSharper disable once InconsistentNaming
            var RearrangeUtils = (function () {
                function RearrangeUtils() {
                }
                RearrangeUtils.prototype.rearrangeGeneric = function (changed, targetArray, attr) {
                    if (!changed[attr]) {
                        return;
                    }
                    var originalLength = targetArray.length;
                    var originIndex = targetArray.indexOf(changed);
                    var stop = changed[attr] - 1;
                    var fromUpToDown = originIndex < (changed[attr] - 1);
                    var auxIndex = originIndex;
                    if (fromUpToDown) {
                        do {
                            var indx = (auxIndex === 0 ? originalLength : auxIndex) - 1;
                            targetArray[auxIndex] = targetArray[indx];
                            targetArray[auxIndex][attr] = targetArray[auxIndex][attr]
                                ? (auxIndex + 1)
                                : targetArray[auxIndex][attr];
                            auxIndex--;
                            if (auxIndex < 0)
                                auxIndex = originalLength - 1;
                        } while (auxIndex !== stop);
                    }
                    else {
                        do {
                            var indx = auxIndex === (originalLength - 1) ? 0 : auxIndex + 1;
                            targetArray[auxIndex] = targetArray[indx];
                            targetArray[auxIndex][attr] = targetArray[auxIndex][attr]
                                ? (auxIndex + 1)
                                : targetArray[auxIndex][attr];
                            auxIndex++;
                            if (auxIndex > (originalLength - 1))
                                auxIndex = 0;
                        } while (auxIndex !== stop);
                    }
                    targetArray[changed[attr] - 1] = changed;
                };
                RearrangeUtils.prototype.rearrangeOrdinals = function (changed, targetArray) {
                    this.rearrangeGeneric(changed, targetArray, "ordinal");
                };
                RearrangeUtils.prototype.rearrangePositions = function (changed, targetArray) {
                    this.rearrangeGeneric(changed, targetArray, "position");
                };
                return RearrangeUtils;
            }());
            itemsWithOrdinal.RearrangeUtils = RearrangeUtils;
            angular.module("SPApp").service('rearrangeUtils', RearrangeUtils);
        })(itemsWithOrdinal = components.itemsWithOrdinal || (components.itemsWithOrdinal = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=rearrangeUtils.service.js.map