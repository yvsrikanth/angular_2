var app;
(function (app) {
    var directives;
    (function (directives) {
        var instantFindComponent = (function () {
            function instantFindComponent() {
                this.controller = app.instantFindComponentController.instantFindComponentController;
                this.templateUrl = '/Application/components/instantFind/instantFind.html';
                this.controllerAs = "instantFindCtrl";
            }
            return instantFindComponent;
        }());
        angular.module('SPApp').component('instantFind', new instantFindComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=instantFind.component.js.map