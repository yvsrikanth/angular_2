var app;
(function (app) {
    var directives;
    (function (directives) {
        var leadBannerSpotCreateEditComponent = (function () {
            function leadBannerSpotCreateEditComponent() {
                this.bindings = {
                    firm: "<",
                    id: "<"
                };
                this.controller = app.components.news.leadBannerSpotCreateEditComponentController;
                this.templateUrl =
                    '/Application/components/news/homepageNews/leadBannerSpot/leadBannerSpot-create-edit/leadBannerSpot-create-edit.html';
                this.controllerAs = "leadBannerSpotCreateEdit";
            }
            return leadBannerSpotCreateEditComponent;
        }());
        directives.leadBannerSpotCreateEditComponent = leadBannerSpotCreateEditComponent;
        angular.module('SPApp').component('leadBannerSpotCreateEdit', new leadBannerSpotCreateEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-create-edit.component.js.map