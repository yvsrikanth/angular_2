﻿module app.components.news.expandedpageNews.thumbnailNews {
    var expandedThumbnailNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {


        },
        controller: expandedThumbnailNewsCreateEditController,
        templateUrl: "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-create-edit/thumbnailNews-create-edit.html",
        controllerAs: "leadNewsEditor"
    }

    angular.module("SPApp").component("expandedThumbnailNewsEditor", expandedThumbnailNewsCreateEditComponent);
}