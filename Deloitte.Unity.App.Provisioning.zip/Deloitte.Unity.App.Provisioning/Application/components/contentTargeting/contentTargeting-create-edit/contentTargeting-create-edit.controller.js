var app;
(function (app) {
    var contentTargetingCreateController;
    (function (contentTargetingCreateController) {
        var contentTargetingCreateComponentController = (function () {
            //routeParams: ngRoute.$routeParams;
            function contentTargetingCreateComponentController($scope, $rootScope, contentTargetingService, userAttributesService, alertService, $http, $compile, $window, $location, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.contentTargetingService = contentTargetingService;
                this.userAttributesService = userAttributesService;
                this.alertService = alertService;
                this.$compile = $compile;
                this.$routeParams = $routeParams;
                this.userAttrDetails = [];
                this.memberFirmName = '';
                this.validateFormField = false;
                this.isNew = false;
                this.validateFormFieldDuplicated = [false];
                this.isSubmited = false;
                this.http = $http;
                this.window = $window;
                this.location = $location;
            }
            contentTargetingCreateComponentController.prototype.$onInit = function () {
                var self = this;
                self.audienceId = self.$routeParams.id;
                self.actionType = (self.audienceId) ? 'edit' : 'create';
                self.createAndEditInit();
            };
            contentTargetingCreateComponentController.prototype.createAndEditInit = function () {
                var _this = this;
                var self = this;
                self.userAttributesService.get().then(function (res) {
                    self.userAttributes = res['items'].sort(function (a, b) {
                        return a.displayName.localeCompare(b.displayName);
                    });
                    if (self.actionType === "edit") {
                        self.isNew = false;
                        self.headerTitle = "Edit audience";
                        self.contentTargetingService.getSelectedAudiencesData(self.audienceId)
                            .then(function (res) {
                            self.memberFirmName = res.firm;
                            self.displayTitle = res.displayName;
                            for (var i = 0; i < res.rules.length; i++) {
                                _this.setAttributes(res, i);
                            }
                        });
                    }
                    else {
                        self.isNew = true;
                        self.memberFirmName = self.$routeParams.firm;
                        self.headerTitle = "Create new audience";
                        _this.addNewsAttributes();
                    }
                });
            };
            contentTargetingCreateComponentController.prototype.setAttributes = function (response, index) {
                var self = this;
                var rule = response.rules[index];
                var attr = this.userAttributes.filter(function (ua) {
                    return ua.id === rule['attribute'];
                });
                if (attr && attr[0]) {
                    var parsedRule = {
                        "attrArray": self.userAttributes,
                        "userAttr": attr[0],
                        "userAttrDisplayName": attr[0].displayName,
                        "userAttrOperatorName": rule.operator,
                        "selectedValues": rule.values,
                        "userAttrValueName": rule.values.join(',')
                    };
                    self.userAttrDetails.push(parsedRule);
                }
                this.sortAttributes();
            };
            contentTargetingCreateComponentController.prototype.addNewsAttributes = function () {
                var self = this;
                self.userAttrDetails.push({
                    "attrArray": self.userAttributes,
                    "userAttr": {},
                    "userAttrDisplayName": "",
                    "userAttrValueName": "",
                    "selectedValues": [],
                    "userAttrOperatorName": ""
                });
                self.validateFormField = false;
                this.sortAttributes();
            };
            contentTargetingCreateComponentController.prototype.sortAttributes = function () {
                if (!angular.isDefined(this.userAttrDetails) || !angular.isDefined(this.userAttrDetails[0].attrArray))
                    return;
                for (var _i = 0, _a = this.userAttrDetails[0].attrArray; _i < _a.length; _i++) {
                    var item = _a[_i];
                    var array = item.values.sort();
                    item.vales = array;
                }
            };
            contentTargetingCreateComponentController.prototype.removeAttribute = function (index) {
                var self = this;
                self.userAttrDetails.splice(index, 1);
            };
            contentTargetingCreateComponentController.prototype.isValidRule = function (rule) {
                var result = false;
                if (rule.userAttrDisplayName && rule.userAttrOperatorName && rule.userAttrValueName) {
                    result = true;
                }
                return result;
            };
            contentTargetingCreateComponentController.prototype.toggleValue = function (value, attribute) {
                var index = attribute.selectedValues.indexOf(value);
                if (index >= 0) {
                    attribute.selectedValues.splice(index, 1);
                }
                else {
                    attribute.selectedValues.push(value);
                }
                attribute.userAttrValueName = attribute.selectedValues.join(',');
            };
            contentTargetingCreateComponentController.prototype.saveAudience = function (form) {
                var _this = this;
                var self = this;
                var rule = [];
                self.validateFormField = true;
                this.isSubmited = true;
                angular.forEach(self.userAttrDetails, function (value) {
                    if (self.isValidRule(value)) {
                        rule.push({
                            "attribute": value.userAttr.id,
                            "operator": value.userAttrOperatorName,
                            "values": value.userAttrValueName.split(',')
                        });
                    }
                });
                var requestObj = {
                    "displayName": self.displayTitle,
                    "rules": rule
                };
                if (self.isNew) {
                    requestObj['firm'] = self.memberFirmName || 'US';
                }
                if (!form.$valid) {
                    this.isSubmited = false;
                    return false;
                }
                else {
                    self.contentTargetingService.contentTargetingCreate(self.audienceId, requestObj, self.isNew).then(function () {
                        window.history.back();
                    }, function (err) {
                        _this.isSubmited = false;
                        if (err.status === 400) {
                            self.duplicateAudienceError = err.data.message;
                        }
                        if (err.status === 500) {
                            self.alertService.show({
                                buttons: app.components.alert.AlertButtons.Accept,
                                title: "Error",
                                message: err.statusText,
                                dismissText: "Ok"
                            });
                        }
                    });
                }
            };
            contentTargetingCreateComponentController.prototype.getAttributeIndex = function (attribute) {
                return this.userAttributes.map(function (obj, index) {
                    if (obj.id === attribute) {
                        return index;
                    }
                }).filter(isFinite);
            };
            contentTargetingCreateComponentController.prototype.resetAttributeValue = function (attribute) {
                attribute.userAttrValueName = "";
                attribute.selectedValues = [];
            };
            contentTargetingCreateComponentController.prototype.anyDuplicatedAttribute = function () {
                for (var index = 0; index < this.validateFormFieldDuplicated.length; index++) {
                    if (this.validateFormFieldDuplicated[index])
                        return true;
                }
                return false;
            };
            contentTargetingCreateComponentController.prototype.verifyDuplicate = function (index, selectedValue) {
                var self = this;
                self.resetAttributeValue(self.userAttrDetails[index]);
                self.validateFormFieldDuplicated[index] = false;
                for (var j = 0; j < self.userAttrDetails.length; j++) {
                    if (index !== j && self.userAttrDetails[j].userAttr && self.userAttrDetails[index].userAttr.displayName === self.userAttrDetails[j].userAttr.displayName) {
                        self.validateFormFieldDuplicated[index] = true;
                    }
                }
                self.userAttrDetails[index].userAttrDisplayName = selectedValue.displayName;
            };
            ;
            return contentTargetingCreateComponentController;
        }());
        contentTargetingCreateComponentController.$inject = ['$scope', '$rootScope', 'contentTargetingService', 'userAttributesService', 'alertService', '$http', '$compile', '$window', '$location', '$routeParams'];
        contentTargetingCreateController.contentTargetingCreateComponentController = contentTargetingCreateComponentController;
    })(contentTargetingCreateController = app.contentTargetingCreateController || (app.contentTargetingCreateController = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-create-edit.controller.js.map