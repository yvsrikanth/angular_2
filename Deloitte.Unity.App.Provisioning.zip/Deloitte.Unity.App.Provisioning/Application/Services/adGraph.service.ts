﻿module app.services {
    export class adGraphService {

        static $inject = ["$http"];
        constructor(private $http: ng.IHttpService) {

        }

        getGroups(displayName?: string): ng.IPromise<IAdGroupResponse[]> {
            var params = {};
            if (displayName) {
                params["$filter"] = `displayName eq '${displayName}'`;
            }

            return this.$http
                .get("https://graph.microsoft.com/v1.0/deloitte.com/groups", { params: params })
                .then(response => response.data["value"]);
        }
    }

    export interface IAdGroupResponse {
        "odata.type": string;
        objectType: string;
        objectId: string;
        deletionTimestamp: number;
        description: string;
        dirSyncEnabled: boolean;
        displayName: string;
        lastDirSyncTime: any;
        mail: any;
        mailNickname: string;
        mailEnabled: boolean;
        onPremisesSecurityIdentifier: any;
        provisioningErrors: any[];
        proxyAddresses: any[];
        securityEnabled: boolean;
    }

    angular.module("SPApp").service("adGraphService", adGraphService);
}