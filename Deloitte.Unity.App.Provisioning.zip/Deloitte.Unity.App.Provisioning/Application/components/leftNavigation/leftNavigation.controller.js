var app;
(function (app) {
    var leftNavigationController;
    (function (leftNavigationController_1) {
        var leftNavigationController = (function () {
            function leftNavigationController($location, $routeParams, $route, $templateCache, securityService) {
                this.$location = $location;
                this.$routeParams = $routeParams;
                this.$route = $route;
                this.$templateCache = $templateCache;
                this.securityService = securityService;
                this.newsParams = $routeParams.one;
            }
            leftNavigationController.prototype.$onInit = function () {
                var _this = this;
                this.mergedPermissions = {};
                this.securityService
                    .getMergedPermissions()
                    .then(function (permissions) {
                    _this.mergedPermissions = permissions;
                });
            };
            leftNavigationController.prototype.hasAnyPermission = function (module) {
                return this.mergedPermissions[module]
                    && (this.mergedPermissions[module].create ||
                        this.mergedPermissions[module].read ||
                        this.mergedPermissions[module].delete ||
                        this.mergedPermissions[module].update ||
                        this.mergedPermissions[module].disable);
            };
            leftNavigationController.prototype.hasAnyHomePageNewsPermission = function () {
                return this.hasAnyPermission("homePageLeadnews") ||
                    this.hasAnyPermission("homeHeadlineNews") ||
                    this.hasAnyPermission("homePageBannerAd") ||
                    this.hasAnyPermission("homePageHiddenNews");
            };
            leftNavigationController.prototype.hasAnyExtendedPageNewsPermission = function () {
                return this.hasAnyPermission("extendedPageLeadNews") ||
                    this.hasAnyPermission("extendedPageHeadlineNews") ||
                    this.hasAnyPermission("extendedPageThumbnailNews") ||
                    this.hasAnyPermission("extendedPageExternalResources") ||
                    this.hasAnyPermission("extendedPageTitle");
            };
            leftNavigationController.prototype.hasAnyNewsPermission = function () {
                return this.hasAnyHomePageNewsPermission() ||
                    this.hasAnyExtendedPageNewsPermission();
            };
            leftNavigationController.prototype.isActive = function (viewLocation) {
                var active = false;
                var actualUrl = this.$location.path();
                if (actualUrl.indexOf(viewLocation) >= 0) {
                    active = true;
                }
                return active;
            };
            leftNavigationController.prototype.toggle = function (event) {
                localStorage.removeItem("accordion-tab-open");
                var index = $(event.currentTarget).index();
                this.currentActive = index + 1;
            };
            leftNavigationController.prototype.goTo = function (path) {
                var currentPageTemplate = this.$route.current.templateUrl;
                this.$templateCache.remove(currentPageTemplate);
                this.$route.reload();
                this.$location.path(path);
            };
            return leftNavigationController;
        }());
        leftNavigationController.$inject = ["$location", "$routeParams", "$route", "$templateCache", "securityService"];
        leftNavigationController_1.leftNavigationController = leftNavigationController;
    })(leftNavigationController = app.leftNavigationController || (app.leftNavigationController = {}));
})(app || (app = {}));
//# sourceMappingURL=leftNavigation.controller.js.map