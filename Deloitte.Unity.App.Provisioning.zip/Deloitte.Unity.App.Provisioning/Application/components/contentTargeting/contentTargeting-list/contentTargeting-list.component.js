var app;
(function (app) {
    var directives;
    (function (directives) {
        var contentTargetingListComponent = (function () {
            function contentTargetingListComponent() {
                this.bindings = {
                    firm: '='
                };
                this.controller = app.contentTargetingListController.contentTargetingListComponentController;
                this
                    .templateUrl =
                    '/Application/components/contentTargeting/contentTargeting-list/contentTargeting-list.html';
                this.controllerAs = "contentTargetingList";
            }
            return contentTargetingListComponent;
        }());
        directives.contentTargetingListComponent = contentTargetingListComponent;
        angular.module('SPApp').component('contentTargetingListComponent', new contentTargetingListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-list.component.js.map