﻿module app.services {
    const data = {
        "skip": "0",
        "take": "10"
    };


    export class applicationLauncherService {
        static $inject = ['$http', 'appSettings'];
        http: ng.IHttpService;


        public firmItems: any;
        public selectedFirm: any;
        public selectedAudienceId: String;
        public selectedFirmObj: any;


        constructor($http: ng.IHttpService, private appSettings: IAppSettings) {
            this.http = $http;
        }

        deleteApplicationItem(newsId, reData) {
            return this.http.put(this.appSettings.apiUrl + "/firms/" + newsId, reData);

        }

        createEditPageTitle(newsId, reData) {
            console.log("Sent request");
            return this.http.put(this.appSettings.apiUrl + "/firms/" + newsId, reData);

        }



        getPageList(skip, take, firm) {
            let configList = {
                params: {
                    "skip": skip,
                    "take": take,
                    "key": firm
                }
            };
            return this.http.get(this.appSettings.apiUrl + "/firms", configList).then(result => result.data);
        }

        getSelectedPageTitleData(firmId) {
            return this.http.get(this.appSettings.apiUrl + "/firms/" + firmId).then(result => result.data);
        }

        setFirm(firm) {
            this.selectedFirm = firm;
        }
        setFirmObj(item) {
            this.selectedFirmObj = item;
        }
        getFirmObj() {
            return this.selectedFirmObj;
        }

        getFirmName() {
            return this.selectedFirm;
        }

    }


    function myServiceFactory($rootElement): applicationLauncherService {
        const inj = $rootElement.injector();
        return inj.instantiate(applicationLauncherService);
    }
    angular.module("SPApp").factory('applicationLauncherService', ['$rootElement', $rootElement => myServiceFactory($rootElement)]);
}