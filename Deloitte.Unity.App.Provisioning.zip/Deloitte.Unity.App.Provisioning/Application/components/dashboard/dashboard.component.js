var app;
(function (app) {
    var directives;
    (function (directives) {
        var dashboardComponent = (function () {
            function dashboardComponent() {
                this.bindings = {
                    contentTargetItem: '@'
                };
                this.controller = app.dashboardController.dashboardComponentController;
                this.templateUrl = '/Application/components/dashboard/dashboard.html';
                this.controllerAs = "dashboard";
            }
            return dashboardComponent;
        }());
        angular.module('SPApp').component('dashboard', new dashboardComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=dashboard.component.js.map