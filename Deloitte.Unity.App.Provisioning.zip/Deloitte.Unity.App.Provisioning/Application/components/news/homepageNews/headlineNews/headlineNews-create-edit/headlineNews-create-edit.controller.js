var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var homepageNews;
            (function (homepageNews) {
                var headlineNewsCreateEditController = (function (_super) {
                    __extends(headlineNewsCreateEditController, _super);
                    function headlineNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                        return _super.call(this, 
                        // Injected dependencies
                        rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, 
                        /*pageTitleOnEditAll*/ "Edit headline news layout", 
                        /*pageTitleOnEditById*/ "Edit headline news", 
                        /*pageTitleOnCreate*/ "Create headline news", 
                        /*maxItems*/ 8, 
                        /*region*/ "Thumbnail", 
                        /*listPath*/ "/news/homepageNews/headlineNews") || this;
                    }
                    return headlineNewsCreateEditController;
                }(news.genericNewsCreateEditController));
                headlineNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                homepageNews.headlineNewsCreateEditController = headlineNewsCreateEditController;
            })(homepageNews = news.homepageNews || (news.homepageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-create-edit.controller.js.map