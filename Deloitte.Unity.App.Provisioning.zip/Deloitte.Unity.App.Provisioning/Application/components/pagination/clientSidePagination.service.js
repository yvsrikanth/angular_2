var app;
(function (app) {
    var components;
    (function (components) {
        var pagination;
        (function (pagination) {
            var clientSidePaginationFactory = (function () {
                function clientSidePaginationFactory() {
                    this.sortMethods = {};
                    this.fiterColums = [];
                    this.items = [];
                    this.result = [];
                    this.total = 0;
                    this.skip = 0;
                    this.take = 8;
                    this.sortMethods["date"] = function (a, b) {
                        var dtA = new Date(a);
                        var dtB = new Date(b);
                        return dtA.getTime() - dtB.getTime();
                    };
                }
                clientSidePaginationFactory.prototype.filterText = function () {
                    var result = [];
                    for (var index = 0; index <= this.items.length; index++) {
                        var item = this.items[index];
                        for (var attr in item) {
                            if (item.hasOwnProperty(attr)) {
                                var value = item[attr].toString();
                                if (value.includes(this.filterTextValue)) {
                                    result.push(item);
                                    break;
                                }
                            }
                        }
                    }
                    this.result = result;
                    this.total = result.length;
                };
                clientSidePaginationFactory.prototype.setItems = function (items) {
                    this.items = items;
                    this.total = items.length;
                    this.changePage(0, this.take);
                };
                clientSidePaginationFactory.prototype.orderBy = function (column, type) {
                    var that = this;
                    this.orderByColumn = column;
                    if (!angular.isObject(this.items))
                        return;
                    var array = [];
                    for (var item in this.items) {
                        array.push(this.items[item]);
                    }
                    array.sort(function (a, b) {
                        if (type && that.sortMethods[type]) {
                            return that.sortMethods[type](a[column], b[column]);
                        }
                        if (a[column] === undefined || a[column] === null) {
                            a[column] = "";
                        }
                        if (!b[column] === undefined || b[column] === null) {
                            b[column] = "";
                        }
                        if (a[column].toLowerCase && b[column].toLowerCase) {
                            return (a[column].toLowerCase() > b[column].toLowerCase() ? 1 : -1);
                        }
                        else {
                            return (a[column] > b[column] ? 1 : -1);
                        }
                    });
                    if (this.orderReverse)
                        array.reverse();
                    this.orderReverse = !this.orderReverse;
                    this.items = array;
                    this.changePage(this.skip, this.take);
                };
                clientSidePaginationFactory.prototype.changePage = function (skip, take) {
                    this.skip = skip;
                    this.take = take;
                    this.result = this.items.slice(skip, skip + take);
                };
                return clientSidePaginationFactory;
            }());
            pagination.clientSidePaginationFactory = clientSidePaginationFactory;
            angular.module("SPApp").factory("clientSidePaginationFactory", [function () { return { instance: function () { return new clientSidePaginationFactory(); } }; }]);
        })(pagination = components.pagination || (components.pagination = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=clientSidePagination.service.js.map