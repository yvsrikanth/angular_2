﻿module app.moduleAccessPreviewController {

    export class moduleAccessPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "moduleAccessService", "$location", "alertService", "securityService"];

        id: string;
        edit: boolean;
        moduleAccessItem: any;
        userPermissions: security.shared.IModulePermissions;


        constructor(private $scope, private $rootScope, private $routeParams, private moduleAccessService: services.moduleAccessService, private $location, private alertService: components.alert.alertService, private securityService: security.shared.securityService) {

            this.getDetailsModuleAccessItem();
        }

        $onInit() {

            this.securityService.getUserPermissions().then(permissions => {
                this.setModuleAccessParams();
                this.userPermissions = permissions[this.moduleAccessItem.firm];
            });
        }

        setModuleAccessParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
            }
            if (angular.isDefined(this.$routeParams.edit)) {
                this.edit = this.$routeParams.edit;
                console.log("this.edit", this.edit);
            }
        }

        getDetailsModuleAccessItem() {

            if (sessionStorage.getItem("module-access-item")) {
                let data = angular.fromJson(sessionStorage.getItem("module-access-item"));
                this.moduleAccessItem = data;
                return;

            } else if (!angular.isDefined(this.id)) {
                return;
            }

            let that = this;
            that.moduleAccessService.getModuleAccessItem(that.id).then(item => {

                that.moduleAccessItem = item;

            }, response => {

                that.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: response.statusText,
                    dismissText: "Ok"
                });

                that.$location.path("/moduleAccess");
            });
        }

    }
}