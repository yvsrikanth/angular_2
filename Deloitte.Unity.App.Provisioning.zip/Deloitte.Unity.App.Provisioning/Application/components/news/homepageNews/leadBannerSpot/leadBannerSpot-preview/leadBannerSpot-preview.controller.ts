﻿module app.leadBannerSpotPreviewController {

    export class leadBannerSpotPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService", "contentTargetingService"];

        id: string;
        firm: string;
        edit: boolean;
        leadBannerSpotItem: any;
        selectedItem: any;
        audiences: any;
        userPermissions: security.shared.IModulePermissions;


        constructor(
            private $scope,
            private $rootScope,
            private $routeParams,
            private newsService: services.newsService,
            private $location,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService,
            private audienceService: services.contentTargetingService
        ) {}

        $onInit() {

            this.setleadBannerSpotParams();
            this.leadBannerSpotItem = [];
            this.getDetailsLeadBannerSpotItem();
            
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setleadBannerSpotParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
            }
        }

        getDetailsLeadBannerSpotItem() {

            if (!angular.isDefined(this.id)) {
                this.redirectToHome("Params can't be identified");
            }

            if (angular.isDefined(this.id)) {
                this.requestLeadBannerSpotItem();
                return;
            }

        }

        requestLeadBannerSpotItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.leadBannerSpotItem.push(data);
                this.setSelectedItem();

            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.leadBannerSpotItem.push(item);
                }, response => {
                    this.redirectToHome(response.statusText);
                    });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {
            
            this.selectedItem = this.leadBannerSpotItem[0];
            if (!angular.isDefined(this.firm)) { this.firm = this.selectedItem.firm; }
            this.loadAudiences();
        }


        loadAudiences() {

            let that = this;

            that.audiences = [];
            for (let audience of that.selectedItem.audiences) {

                that.audienceService.getContentTargetById(audience).then((data: any) => {
                    that.audiences.push(data.displayName);
                }, () => {
                    that.audiences.push("Item Not Found - " + audience);
                });
            }
        }

        getImageSrc() {
            if (this.selectedItem && this.selectedItem.items && this.selectedItem.items.length) {
                return this.selectedItem.items[0].imageUrl || this.selectedItem.items[0].image;
            } else {
                return null;
            }
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/homepageNews/leadBannerSpot");
        }

    }
}