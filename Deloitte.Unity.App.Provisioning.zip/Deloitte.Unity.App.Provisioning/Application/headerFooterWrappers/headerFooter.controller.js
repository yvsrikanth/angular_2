var app;
(function (app) {
    var headerFooterWrappers;
    (function (headerFooterWrappers) {
        var headerFooterComponentController = (function () {
            function headerFooterComponentController($rootScope, $timeout, unityCommonService, $element, securityService, userService, firmService) {
                this.$rootScope = $rootScope;
                this.$timeout = $timeout;
                this.unityCommonService = unityCommonService;
                this.$element = $element;
                this.securityService = securityService;
                this.userService = userService;
                this.firmService = firmService;
                this.alertItems = [];
                this.notificationsList = [];
                this.userInformation = {};
                this.scLinks = [];
            }
            headerFooterComponentController.prototype.$onInit = function () {
                var _this = this;
                window["userApiData"] = {
                    userMemberFirm: ""
                };
                this.userInformation = this.$rootScope.userInfo.profile;
                var username = this.userInformation.unique_name.split("@")[0];
                this.userService
                    .getUserPermissions(username)
                    .then(function (userPermissions) {
                    window["userGroupsArray"] = userPermissions.groups;
                });
                this.userService
                    .getUser(username)
                    .then(function (userDetails) {
                    window["userAudienceArray"] = userDetails.audiences;
                    var memberFirm = "";
                    if (userDetails.attributes && userDetails.attributes.externalId) {
                        memberFirm = userDetails.attributes.externalId.memberFirm;
                    }
                    window["userApiData"].userMemberFirm = memberFirm;
                    if (!sessionStorage.getItem("firmKey"))
                        sessionStorage.setItem("firmKey", memberFirm);
                    _this.firmService
                        .get(memberFirm)
                        .then(function (result) {
                        var resultAsArray = result;
                        if (result.newsHeadlineTitle) {
                            _this.firmItems = result;
                            _this.newsHeadlineTitle = result.newsHeadlineTitle;
                        }
                        else if (resultAsArray.items && resultAsArray.items.length) {
                            _this.firmItems = resultAsArray.items[0];
                            _this.newsHeadlineTitle = resultAsArray.items[0].newsHeadlineTitle;
                        }
                        if (!_this.newsHeadlineTitle) {
                            _this.newsHeadlineTitle = "My news";
                        }
                    });
                });
                //Alert Data method invokation by passing user Name
                this.unityCommonService
                    .alertData(username)
                    .then(function (results) {
                    _this.alertItems = results.data;
                });
                window["isAdminUser"] = true;
            };
            return headerFooterComponentController;
        }());
        headerFooterComponentController.$inject = ["$rootScope", "$timeout", "unityCommonService", "$element", "securityService", "userService", "firmService"];
        headerFooterWrappers.headerFooterComponentController = headerFooterComponentController;
    })(headerFooterWrappers = app.headerFooterWrappers || (app.headerFooterWrappers = {}));
})(app || (app = {}));
//# sourceMappingURL=headerFooter.controller.js.map