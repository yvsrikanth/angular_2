﻿module app.components.news.expandedpageNews.leadNews {
    var expandedLeadNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {


        },
        controller: expandedLeadNewsCreateEditController,
        templateUrl: "/Application/components/news/expandedpageNews/leadNews/leadNews-create-edit/leadNews-create-edit.html",
        controllerAs: "leadNewsEditor"
    }

    angular.module("SPApp").component("expandedLeadNewsEditor", expandedLeadNewsCreateEditComponent);
}