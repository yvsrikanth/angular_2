﻿module app.newsItemController {

    export class newsItemComponentController {

        static $inject = ["$scope", "$rootScope","contentTargetingService"];
       
        audiences: any;
        item: any;

        constructor(private $scope, private $rootScope, private audienceService: services.contentTargetingService) {
        }

        $onInit() {
            this.loadAudiences();
        }

        loadAudiences() {
            
            let that = this;

            that.audiences = [];
            for (let audience of that.item.audiences) {

                that.audienceService.getContentTargetById(audience).then((data: any) => {
                    that.audiences.push(data.displayName);
                }, () => {
                    that.audiences.push("Item Not Found (" + audience + ")");
                });
            }
        }
    }

}