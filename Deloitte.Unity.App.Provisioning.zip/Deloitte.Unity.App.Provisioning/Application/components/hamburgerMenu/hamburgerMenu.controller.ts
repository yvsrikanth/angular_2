﻿module app.hamburgerMenuController {

    export class hamburgerMenuComponentController {
        static $inject = ['securityService'];
        public firms: any;
        public userPermissions: security.shared.IFirmPermissions;
        public whenOneItem: any;

        constructor(private securityService: security.shared.securityService) {
            let self = this;
            self.whenOneItem = 1;          
        }

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firms = Object.keys(permissions).sort();
            });
        }

    }
}