var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var headlineNews;
                (function (headlineNews) {
                    var expandedHeadlineNewsCreateEditComponent = {
                        bindings: {},
                        controller: headlineNews.expandedHeadlineNewsCreateEditController,
                        templateUrl: "/Application/components/news/expandedpageNews/headlineNews/headlineNews-create-edit/headlineNews-create-edit.html",
                        controllerAs: "expandedHeadlineNewsCreateEdit"
                    };
                    angular.module('SPApp').component('expandedHeadlineNewsCreateEdit', expandedHeadlineNewsCreateEditComponent);
                })(headlineNews = expandedpageNews.headlineNews || (expandedpageNews.headlineNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-create-edit.component.js.map