﻿namespace app.directives {
    export class headlineNewsListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: '='
            };
            this.controller = headlineNewsListController.headlineNewsListComponentController;
            this.templateUrl = '/Application/components/news/homepageNews/headlineNews/headlineNews-list/headlineNews-list.html';
            this.controllerAs = "headlineNewsList";
        }
    }

    angular.module('SPApp').component('headlineNewsListComponent', new headlineNewsListComponent());
}