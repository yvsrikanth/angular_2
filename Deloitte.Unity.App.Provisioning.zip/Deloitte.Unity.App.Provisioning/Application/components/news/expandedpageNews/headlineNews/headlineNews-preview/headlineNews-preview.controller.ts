﻿module app.expandedHeadlineNewsPreviewController {

    export class headlineNewsPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService", "hamburgerMenuService"];

        id: string;
        firm: string;
        edit: boolean;
        headlineNewsItem: any[];
        selectedItem: any;
        showTitle: boolean;
        firmData: any;
        resourceTitle: string;
        buttonText: string;
        userPermissions: security.shared.IModulePermissions;


        constructor(
            private $scope,
            private $rootScope,
            private $routeParams,
            private newsService: services.newsService,
            private $location,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService,
            private firmService: services.hamburgerMenuService
        ) {}

        $onInit() {

            this.setHeadLineNewsParams();
            this.headlineNewsItem = [];
            for (var itemIndex = 0; itemIndex < 10; itemIndex++) {
                this.headlineNewsItem.push(components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "headline"));
            }
            this.getDetailsHeadLineNewsItem();
            this.getFirmData();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setHeadLineNewsParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
                this.resourceTitle = "Headline news preview";
                this.buttonText = "Edit news";
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
                this.resourceTitle = "Headline news layout preview";
                this.buttonText = "Edit layout";
            }
        }

        setItemsOnPositions(items: components.news.INewsArticleData[]) {
            components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.headlineNewsItem);
        }

        getDetailsHeadLineNewsItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllHeadlineNewsData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestHeadlineNewsItem();
                return;
            }

        }

        requestAllHeadlineNewsData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "headline", take: 10 }).then(result => {
                this.setItemsOnPositions(result.items);
            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        requestHeadlineNewsItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.setItemsOnPositions([data]);
                this.setSelectedItem();

            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.setItemsOnPositions([item]);
                }, response => {
                    this.redirectToHome(response.statusText);
                    });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {
            
            this.selectedItem = this.headlineNewsItem[0];
            if(!angular.isDefined(this.firm)) {this.firm = this.selectedItem.firm;}
            this.showTitle = this.headlineNewsItem.length > 1;
        }

        getFirmData() {
            this.firmService.getFirmByKey(this.firm).then(data => {
                this.firmData = data.items[0];
            });
        }

        sortByPosition() {

            if (!angular.isObject(this.headlineNewsItem)) return;
            
            this.headlineNewsItem = app.components.news.genericNewsCreateEditController.processOrdinalSoring(this.headlineNewsItem);

        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/expandedpageNews/headlineNews");
        }

    }
}