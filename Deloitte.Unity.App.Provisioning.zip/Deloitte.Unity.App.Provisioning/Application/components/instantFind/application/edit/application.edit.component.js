var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationEditComponent = (function () {
            function applicationEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/application/edit/application.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return applicationEditComponent;
        }());
        angular.module('SPApp').component('applicationEdit', new applicationEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=application.edit.component.js.map