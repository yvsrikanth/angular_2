var app;
(function (app) {
    var moduleAccessPreviewController;
    (function (moduleAccessPreviewController) {
        var moduleAccessPreviewComponentController = (function () {
            function moduleAccessPreviewComponentController($scope, $rootScope, $routeParams, moduleAccessService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.moduleAccessService = moduleAccessService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
                this.getDetailsModuleAccessItem();
            }
            moduleAccessPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.setModuleAccessParams();
                    _this.userPermissions = permissions[_this.moduleAccessItem.firm];
                });
            };
            moduleAccessPreviewComponentController.prototype.setModuleAccessParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                }
                if (angular.isDefined(this.$routeParams.edit)) {
                    this.edit = this.$routeParams.edit;
                    console.log("this.edit", this.edit);
                }
            };
            moduleAccessPreviewComponentController.prototype.getDetailsModuleAccessItem = function () {
                if (sessionStorage.getItem("module-access-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("module-access-item"));
                    this.moduleAccessItem = data;
                    return;
                }
                else if (!angular.isDefined(this.id)) {
                    return;
                }
                var that = this;
                that.moduleAccessService.getModuleAccessItem(that.id).then(function (item) {
                    that.moduleAccessItem = item;
                }, function (response) {
                    that.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: "Error",
                        message: response.statusText,
                        dismissText: "Ok"
                    });
                    that.$location.path("/moduleAccess");
                });
            };
            return moduleAccessPreviewComponentController;
        }());
        moduleAccessPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "moduleAccessService", "$location", "alertService", "securityService"];
        moduleAccessPreviewController.moduleAccessPreviewComponentController = moduleAccessPreviewComponentController;
    })(moduleAccessPreviewController = app.moduleAccessPreviewController || (app.moduleAccessPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-preview.controller.js.map