﻿module app.components.news.expandedpageNews.headlineNews {

    var externalResourcesCreateEditComponent: ng.IComponentOptions = {

        bindings: {


        },
        controller: externalResourcesCreateEditController,
        templateUrl: "/Application/components/news/expandedpageNews/externalResources/externalResources-create-edit/externalResources-create-edit.html",
        controllerAs: "externalResourcesCreateEdit"
    }

    angular.module('SPApp').component('externalResourcesCreateEdit', externalResourcesCreateEditComponent);

}