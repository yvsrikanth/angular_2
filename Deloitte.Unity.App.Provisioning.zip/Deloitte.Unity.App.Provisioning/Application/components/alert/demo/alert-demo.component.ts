﻿angular.module("SPApp")
    .component("alertDemo", {
        template: `
                <div>
                    <table>
                        <thead>
                            <tr>
                                <th>Ejemplo</th>
                                <th>Descripcion</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <button role="button" ng-click="onInfoClick()">Info con click</button>
                                </td>
                                <td>
                                    Mostrar mensajes de información y maneja onDismiss para saber cuando se ha presionado el boton Principal
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <button role="button" ng-click="onInfo()">Info</button>
                                </td>
                                <td>
                                    Mostrar mensajes de información, como confirmaciones o instrucciones
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <button role="button" ng-click="onError()">Error</button>
                                </td>
                                <td>
                                    Mostrar mensajes de error
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <button role="button" ng-click="onConfirm()">Confirmacion</button>
                                </td>
                                <td>
                                    Solicitar confirmación del usuario
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <button role="button" ng-click="onLoad()">Bloquear</button>
                                </td>
                                <td>
                                    Congela la experiecia de usuario, por ejemplo mientras se completa una petición
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>`,
        controller: function ($scope: ng.IScope | any, alertService: app.components.alert.alertService) {

            $scope.onInfoClick = () => {
                alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Listo",
                    message: "Se han guardado los datos exitosamente",
                    dismissText: "Aceptar",
                    onDismiss: () => {
                        alert("Has cerrado el modal");
                    }
                });
            }

            $scope.onInfo = () => {
                alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Listo",
                    message: "Se han guardado los datos exitosamente",
                    dismissText: "Aceptar"
                });
            }

            $scope.onError = () => {
                alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: "No se pudo completar la operación.",
                    dismissText: "Aceptar"
                });
            }

            $scope.onConfirm = () => {
                alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: "Advertencia",
                    message: "No podra deshacer esta opción. ¿Está seguro que desea continuar?",
                    dismissText: "Cancelar",
                    confirmText: "Continuar",
                    onConfirm: () => {
                        $scope.onLoad();
                    }
                });
            }


            $scope.onLoad = () => {
                alertService.show({
                    buttons: app.components.alert.AlertButtons.None,
                    title: "Eliminando",
                    message: "Esto puede tomar unos segundos...",
                    noDismiss: true
                });
                setTimeout(() => {
                    $scope.$apply(() => {
                        $scope.onInfo();
                    });
                }, 3000);
            }
        }
    });