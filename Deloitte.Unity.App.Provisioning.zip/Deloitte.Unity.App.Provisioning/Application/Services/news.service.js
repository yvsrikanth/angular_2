var app;
(function (app) {
    var services;
    (function (services) {
        var newsService = (function () {
            function newsService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
                this.resourcePath = "/news/";
            }
            /**
             * Retrieve a list of news articles
             * @param options Request parameters
             */
            newsService.prototype.get = function (options) {
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath, { params: options || {} })
                    .then(function (result) {
                    var queryResult = result.data;
                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }
                    return queryResult;
                });
                ;
            };
            /**
             * Retrieves a single news article by id
             * @param id Unique identifier or key for the news article
             * @param include Requests that optional fields or data be embedded in the response
             */
            newsService.prototype.getById = function (id) {
                var include = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    include[_i - 1] = arguments[_i];
                }
                var includes = include ? include.join(",") : "";
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath + id, { params: { include: includes } })
                    .then(function (result) { return result.data; });
            };
            /**
             * Create a news article
             * @param data Request body
             */
            newsService.prototype.post = function (data) {
                return this.$http
                    .post(this.appSettings.apiUrl + this.resourcePath, data)
                    .then(function (result) { return result.data; });
            };
            /**
             * Replaces the attributes in a news article
             * @param data Request body
             */
            newsService.prototype.put = function (data) {
                return this.$http
                    .put(this.appSettings.apiUrl + this.resourcePath + data.id, data)
                    .then(function (result) { return result.data; });
            };
            /**
             * Deletes a news article
             * @param id Unique identifier or key for the news article
             */
            newsService.prototype.delete = function (id) {
                return this.$http
                    .delete(this.appSettings.apiUrl + this.resourcePath + id)
                    .then(function (result) { return result.data; });
            };
            newsService.prototype.save = function (data, isNew) {
                return isNew ? this.post(data) : this.put(data);
            };
            newsService.prototype.getNewsByFirmAndRegion = function (firm, region, take, skip) {
                if (skip === void 0) { skip = 0; }
                var queryParams = { firm: firm, region: region, take: take, skip: skip };
                return this.get(queryParams);
            };
            newsService.prototype.getRegionList = function () {
                return this.$http.get("/Application/components/news/jsonDataNewsRegion/newsRegion.json").then(function (result) { return result.data; });
            };
            return newsService;
        }());
        newsService.$inject = ["$http", "appSettings"];
        services.newsService = newsService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(newsService);
        }
        angular.module("SPApp").factory('newsService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=news.service.js.map