﻿module app.directives {

    class bannerAdNewsPreviewComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {

            this.bindings = {
                id: "<"
            };
            this.controller = bannerAdNewsPreviewController.bannerAdNewsPreviewComponentController;
            this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-preview/bannerAdNews-preview.html";
            this.controllerAs = "bannerAdNewsPreview";
        }

    }

    angular.module("SPApp").component("bannerAdNewsPreview", new bannerAdNewsPreviewComponent());

}