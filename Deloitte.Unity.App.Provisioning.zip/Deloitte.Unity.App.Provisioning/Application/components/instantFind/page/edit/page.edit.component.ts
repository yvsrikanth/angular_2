﻿module app.directives {

    class pageEditComponent implements ng.IComponentOptions {
        
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
            this.templateUrl = '/Application/components/instantFind/page/edit/page.edit.html';
            this.controllerAs = "instantFindCtrl";
        }
    }

    angular.module('SPApp').component('pageEdit', new pageEditComponent());
}