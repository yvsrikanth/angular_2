﻿module app.services {

    export class userService {

        static $inject = ["$http", "appSettings"];
        constructor(private $http: ng.IHttpService, private appSettings: IAppSettings) {

        }

        /**
         * Retrieves the current user, including optional properties like permissions
         */
        getUser(): ng.IPromise<IUser>;

        /**
         * Retrieves a single user by id/ alias
         * @param id Unique identifier for the user profile
         */
        getUser(id: string): ng.IPromise<IUser>;

        getUser(id?: string): ng.IPromise<IUser> {
            return this.$http
                //.get(id ? (this.appSettings.apiUrl + "/users/" + id) : "/Assets/scripts/mock-current-user.json")
                .get(this.appSettings.apiUrl + "/users/" + (id || "current")) 
                .then(response => <IUser>response.data);
        }


        /**
         * Retrieves the current user, including optional properties like permissions
         */
        getUserPermissions(): ng.IPromise<IUserPermissions>;

        /**
         * Retrieves the permissions for the specified user
         * @param id Unique identifier for the user profile
         */
        getUserPermissions(id: string): ng.IPromise<IUserPermissions>;

        getUserPermissions(id?: string): ng.IPromise<IUserPermissions> {
            return this.$http
                .get(this.appSettings.apiUrl + `/users/${id||'current'}/permissions`)
                .then(response => <IUser>response.data);
        }

        getUserList(id?: string): ng.IPromise<IUser> {
            return this.$http
                .get(this.appSettings.apiUrl + "/users/?id=" + id)
                .then(response => <IUser>response.data);
        }
    }
    export interface IUser {
        id?: string;
        attributes?: IUserAttributes;
        audiences?: string[];
    }

    export interface IUserPermissions {
        permissions?: IUserPermission[];
        groups?: string[];
    }

    export interface IUserPermission {
        firm: string;
        key: string;
    }

    export interface IUserAttributes {
        firstName?: string;
        lastName?: string;
        preferredName?: string;
        externalId?: IUserExternalId;
    }

    export interface IUserExternalId {
        currentGuid?: string;
        guid?: string;
        memberFirm?: string;
        personId?: string;
    }

    angular.module("SPApp").service("userService", userService);
}