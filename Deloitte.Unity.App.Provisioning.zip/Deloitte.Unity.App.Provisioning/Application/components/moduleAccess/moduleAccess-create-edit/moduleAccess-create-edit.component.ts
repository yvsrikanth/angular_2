﻿module app.directives {

    class moduleAccessCreateEditComponent implements ng.IComponentOptions {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<",
                id: "<"
            };
            this.controller = moduleAccessCreateEditController.moduleAccessCreateEditComponentController;
            this.templateUrl = "/Application/components/moduleAccess/moduleAccess-create-edit/moduleAccess-create-edit.html";
            this.controllerAs = "moduleAccessCreate";
        }

    }

    angular.module("SPApp").component("moduleAccessCreate", new moduleAccessCreateEditComponent());

}