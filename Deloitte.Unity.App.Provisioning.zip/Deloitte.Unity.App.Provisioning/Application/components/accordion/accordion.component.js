var app;
(function (app) {
    var components;
    (function (components) {
        var accordion;
        (function (accordion) {
            var accordionComponent = (function () {
                function accordionComponent() {
                    this.bindings = {
                        accordionId: "@"
                    };
                    this.controller = accordion.accordionComponentController;
                    this.templateUrl = "/Application/components/accordion/accordion.component.html";
                    this.controllerAs = "accordion";
                    this.transclude = true;
                }
                return accordionComponent;
            }());
            accordion.accordionComponent = accordionComponent;
            angular.module("SPApp").component("accordion", new accordionComponent());
        })(accordion = components.accordion || (components.accordion = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=accordion.component.js.map