var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var leadNews;
                (function (leadNews) {
                    var expandedLeadNewsCreateEditController = (function (_super) {
                        __extends(expandedLeadNewsCreateEditController, _super);
                        function expandedLeadNewsCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            var _this = _super.call(this, rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "Edit lead news", "Edit lead news", "Create lead news", 2, "Lead", "/news/expandedpageNews/leadNews") || this;
                            _this.layouts = ["Column 1 - Image / Column 2 - Title", "Column 1 - Title / Column 2 - Image", "Image only"];
                            _this.selectedLayout = _this.layouts[0];
                            return _this;
                        }
                        expandedLeadNewsCreateEditController.prototype.onFetchItems = function () {
                            if (this.items && this.items.length)
                                this.selectedLayout = this.items[0].layout;
                        };
                        expandedLeadNewsCreateEditController.prototype.onChangeLayout = function () {
                            for (var index = 0; index < this.items.length; index++) {
                                this.items[index].layout = this.selectedLayout;
                            }
                        };
                        expandedLeadNewsCreateEditController.prototype.getEmptyItem = function (ordinal, id) {
                            var tmpResult = _super.prototype.getEmptyItem.call(this, ordinal, id);
                            tmpResult.layout = this.selectedLayout;
                            return tmpResult;
                        };
                        return expandedLeadNewsCreateEditController;
                    }(news.genericNewsCreateEditController));
                    expandedLeadNewsCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    leadNews.expandedLeadNewsCreateEditController = expandedLeadNewsCreateEditController;
                })(leadNews = expandedpageNews.leadNews || (expandedpageNews.leadNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-create-edit.controller.js.map