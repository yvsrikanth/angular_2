var app;
(function (app) {
    var components;
    (function (components) {
        var siteProvisioning;
        (function (siteProvisioning) {
            var siteProvisioningListController = (function () {
                function siteProvisioningListController(siteRequestService, paginatedListFactory, $routeParams) {
                    this.siteRequestService = siteRequestService;
                    this.paginatedListFactory = paginatedListFactory;
                    this.$routeParams = $routeParams;
                    this.loaded = false;
                    this.isAdmin = false;
                    this.paginatedList = this.paginatedListFactory.instance();
                }
                siteProvisioningListController.prototype.$onInit = function () {
                    var _this = this;
                    this.isAdmin = this.$routeParams.isAdmin === "true";
                    this.siteRequestService
                        .getSitesDetails()
                        .then(function (data) {
                        _this.paginatedList.setItems(data);
                        _this.loaded = true;
                    });
                };
                siteProvisioningListController.prototype.toggleExpandedItem = function (item) {
                    if (this.expandedItem === item) {
                        this.expandedItem = null;
                    }
                    else {
                        this.expandedItem = item;
                    }
                };
                return siteProvisioningListController;
            }());
            siteProvisioningListController.$inject = ["siteRequestService", "clientSidePaginationFactory", "$routeParams"];
            siteProvisioning.siteProvisioningListController = siteProvisioningListController;
        })(siteProvisioning = components.siteProvisioning || (components.siteProvisioning = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=siteProvisioning-list.controller.js.map