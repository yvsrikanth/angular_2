﻿module app.directives {

    export class applicationLauncherPreviewComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {

            this.controller = applicationLauncherPreviewController.applicationLauncherPreviewController;
            this.templateUrl =
                '/Application/components/applicationLauncher/applicationLauncher-preview/applicationLauncher-preview.html';
            this.controllerAs = "applicationLauncherPreview";
        }
    }

    angular.module('SPApp').component('applicationLauncherPreview', new applicationLauncherPreviewComponent());

}