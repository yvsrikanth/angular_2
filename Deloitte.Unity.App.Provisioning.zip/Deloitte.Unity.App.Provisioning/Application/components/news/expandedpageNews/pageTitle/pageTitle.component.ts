﻿module app.directives {

    class pageTitleComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                pageTitleItem: '@'
            };
            this.controller = pageTitleController.pageTitleComponentController;
            this.templateUrl = '/Application/components/news/expandedpageNews/pageTitle/pageTitle.html';
            this.controllerAs = "pageTitle";
        }
    }

    angular.module('SPApp').component('pageTitle', new pageTitleComponent());

}