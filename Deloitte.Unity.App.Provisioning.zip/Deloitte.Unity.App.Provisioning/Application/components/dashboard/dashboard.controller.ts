﻿module app.dashboardController {
    const operator = ["Less than", "Equal", "Greater than", "Not Equal"];
    
    export interface IKeyMap {
        text: string;
        value: string;
    }

    export interface ICardPermission {
        card: boolean;
        create: boolean;
        edit: boolean;
        preview: boolean;
    }

    export class dashboardComponentController {
        static $inject = [
            "$location", "contentTargetingService", "securityService", "newsService", "applicationLauncherService",
            "moduleAccessService", "alertService","pageTitleService"
        ];

        firmWithPermissions: any;
        userPermissions: security.shared.IFirmPermissions;
        joinFirm: string = "Deloitte ";
        cardsPermissions = {
            homePageNews: <ICardPermission> null,
            expandedPageNews: <ICardPermission> null,
            contentTargeting: <ICardPermission> null,
            applicationLauncher: <ICardPermission> null,
            hamburgerMenu: <ICardPermission> null,
            notifications: <ICardPermission> null,
            moduleAccess: <ICardPermission> null,
            instantFind: <ICardPermission>null
        }
        errorMsg:String = '';
        showErrorMsg: boolean = false;
        requestedPermissions = {
            homepageNews: [
                "homePageLeadnews",
                "homeHeadlineNews",
                "homePageBannerAd",
                "homePageHiddenNews"
            ],
            expandedpageNews: [
                "extendedPageTitle",
                "extendedPageLeadNews",
                "extendedPageHeadlineNews",
                "extendedPageThumbnailNews",
                "extendedPageExternalResources"
            ]
        }
        availableNewsTypes = {
            homepageNews: [
                {
                    text: "Lead news",
                    value: "leadNews"
                },
                {
                    text: "Headline news",
                    value: "headlineNews"
                },
                {
                    text: "Banner ad",
                    value: "bannerAdNews"
                },
                {
                    text: "Lead banner spot",
                    value: "leadBannerSpot"
                }
            ],
            expandedpageNews: [
                {
                    text: "Page title",
                    value: "pageTitle"
                },
                {
                    text: "Lead news",
                    value: "leadNews"
                },
                {
                    text: "Headline news",
                    value: "headlineNews"
                },
                {
                    text: "Thumbnail news",
                    value: "thumbnailNews"
                },
                {
                    text: "External resource",
                    value: "externalResources"
                }
            ],
            contentTargeting: [
                {
                    text: "Audiences",
                    value: "contentTargeting"
                }
            ]
        };
        moduleContentTargeting = "contentTargeting";
        moduleSystemNotifications = "systemNotifications";
        moduleHamburgerMenu = "hamburgerMenu";
        moduleApplicationLauncher = "applicationLauncher";
        moduleModuleAccess = "moduleAccess";
        moduleInstantFind = "instantFind";

        cardsData = {
            contentTargeting: {},
            notifications: {}
        }
        modalTitle: string;
        selectedOptions: Object;
        currentAvailableNewsTypes: Array<IKeyMap>;
        firmAudiences: Array<Object>;
        availableFirms: Array<Object>;
        itemLeadBanner: components.news.INewsArticleResult[] = [];
        moduleAccessByFirm: Array<Object>;
        firmNotifications: Array<Object>;
        firmApplications: Array<Object>;
        MAX_ITEMS: number = 99999999;

        constructor(private $location: ng.ILocationService,
            private contentTargetingService: services.contentTargetingService,
            private securityService: security.shared.securityService,
            private newsService: services.newsService,
            private applicationLauncherService: services.applicationLauncherService,
            private moduleAccessService: services.moduleAccessService,
            private alertService: app.components.alert.alertService,
            private pageTitleService: services.pageTitleService) {
            
        }

        $onInit() {
            
            this.securityService.getUserPermissions()
                .then(permissions => {
                    this.userPermissions = permissions;
                    this.initializeCardPermissions();
                    this.firmWithPermissions = Object.keys(permissions).sort();
                    this.setAudiencesByFirm();
                    this.setCurrentNotifications();
                    this.getModulesToDisplay();
                    this.setLeadBannerSpotItem();
                });
        }

        initializeCardPermissions() {
            for (let key in this.cardsPermissions) {
                this.cardsPermissions[key] = {
                    create: false,
                    edit: false,
                    preview: false
                }
            }
        }

        getModulesToDisplay() {
            for (let firm of this.firmWithPermissions) {
                this.displayModuleContentTargeting(firm);
                this.displayModuleHomePageNews(firm);
                this.displayModuleExpandedPageNews(firm);
                this.displayModuleHeader(firm);
                this.displayModuleNotifications(firm);
                this.displayModuleAccess(firm);
                this.displayModuleInstantFind(firm);
            }
            this.setCardsToDisplay();
        }

        displayModuleContentTargeting(firm) {
            if (this.userPermissions[firm][this.moduleContentTargeting].create) {
                this.cardsPermissions.contentTargeting.create = true;
            }
            if (this.userPermissions[firm][this.moduleContentTargeting].update) {
                this.cardsPermissions.contentTargeting.edit = true;
            }
        }

        displayModuleHomePageNews(firm) {
            for (let permission of this.requestedPermissions.homepageNews) {
                if (this.userPermissions[firm][permission].create) {
                    this.cardsPermissions.homePageNews.create = true;
                }
            }

            for (let permission of this.requestedPermissions.homepageNews) {
                if (this.userPermissions[firm][permission].update) {
                    this.cardsPermissions.homePageNews.edit = true;
                }
            }

            for (let permission of this.requestedPermissions.homepageNews) {
                if (this.userPermissions[firm][permission].read) {
                    this.cardsPermissions.homePageNews.preview = true;
                }
            }
        }

        displayModuleExpandedPageNews(firm) {
            for (let permission of this.requestedPermissions.expandedpageNews) {
                if (this.userPermissions[firm][permission].create) {
                    this.cardsPermissions.expandedPageNews.create = true;
                }
            }

            for (let permission of this.requestedPermissions.expandedpageNews) {
                if (this.userPermissions[firm][permission].update) {
                    this.cardsPermissions.expandedPageNews.edit = true;
                }
            }

            for (let permission of this.requestedPermissions.expandedpageNews) {
                if (this.userPermissions[firm][permission].read) {
                    this.cardsPermissions.expandedPageNews.preview = true;
                }
            }
        }

        displayModuleHeader(firm) {
            if (this.userPermissions[firm][this.moduleApplicationLauncher].create) {
                this.cardsPermissions.applicationLauncher.create = true;
            }
            if (this.userPermissions[firm][this.moduleApplicationLauncher].update) {
                this.cardsPermissions.applicationLauncher.edit = true;
            }
            if (this.userPermissions[firm][this.moduleApplicationLauncher].read) {
                this.cardsPermissions.applicationLauncher.preview = true;
            }
            if (this.userPermissions[firm][this.moduleHamburgerMenu].create) {
                this.cardsPermissions.hamburgerMenu.create = true;
            }
        }

        displayModuleNotifications(firm) {
            if (this.userPermissions[firm][this.moduleSystemNotifications].create) {
                this.cardsPermissions.notifications.create = true;
            }
            if (this.userPermissions[firm][this.moduleSystemNotifications].update) {
                this.cardsPermissions.notifications.edit = true;
            }
        }

        displayModuleAccess(firm) {
            if (this.userPermissions[firm][this.moduleModuleAccess].create) {
                this.cardsPermissions.moduleAccess.create = true;
            }
            if (this.userPermissions[firm][this.moduleModuleAccess].update) {
                this.cardsPermissions.moduleAccess.edit = true;
            }
            if (this.userPermissions[firm][this.moduleModuleAccess].read) {
                this.cardsPermissions.moduleAccess.preview = true;
            }
        }

        displayModuleInstantFind(firm) {
            if (this.userPermissions[firm][this.moduleInstantFind].read ||
                this.userPermissions[firm][this.moduleInstantFind].update) {
                this.cardsPermissions.instantFind.card = true;
            }
        }

        setAudiencesByFirm() {

            if (!angular.isDefined(this.firmWithPermissions)) {
                return; }

            for (let firm of this.firmWithPermissions) {
                this.contentTargetingService.getAudiencesByKey(firm)
                    .then(res => {
                        this.cardsData.contentTargeting[firm] = res["totalCount"];
                    });
            }
            
        }

        setCurrentNotifications() {
            let options = {
                take: this.MAX_ITEMS
            };
            let activeCounter = 0;
            let disabledCounter = 0;
            for (let firm of this.firmWithPermissions) {
                this.newsService.getNewsByFirmAndRegion(firm, "homepage-notifications", options.take)
                    .then(res => {
                        for (let notification of res.items) {
                            if (notification
                                .isEnabled &&
                                (notification.firm === "CH" || notification.firm === "UK")) activeCounter++;
                            if (!notification
                                .isEnabled &&
                                (notification.firm === "CH" || notification.firm === "UK")) disabledCounter++;
                        }
                        this.cardsData.notifications["active"] = activeCounter;
                        this.cardsData.notifications["disabled"] = disabledCounter;
                    });
            }
        }

        setLeadBannerSpotItem() {

            for (let firm of this.firmWithPermissions) {
                this.newsService.get({ firm: firm, region: "hiddenNews" }).then(result => {
                    for (let lead of result.items) {
                        if (lead.isEnabled) {
                            this.itemLeadBanner[firm] = lead;
                        }
                    }
                });
            }
            
            

        }

        setCardsToDisplay() {
            for (let key in this.cardsPermissions) {
                for (let perm in this.cardsPermissions[key]) {
                    if (this.cardsPermissions[key][perm]) {
                        this.cardsPermissions[key].card = true;
                    }
                }
            }
        }

        select(type, value) {
            this.showErrorMsg = false; 
            if (type === "firm" && this.selectedOptions["target"]) {
                let target = this.selectedOptions["target"];
                switch (target) {
                case "contentTargeting":
                    this.setFirmAudiences(value);
                    break;

                case "notifications":
                    this.setFirmNotifications(value);
                    break;

                case "applicationLauncher":
                    this.setFirmApplications(value);
                    break;

                case "moduleAccess":
                    this.setFirmModuleAccess(value);
                    break;

                default:
                    break;
                }
            }
            this.selectedOptions[type] = value;
        }

        getAllowedFirms(requestedPermissions, action) {
            return this.firmWithPermissions
                .filter(f => {
                    for (let req of requestedPermissions) {
                        let permission = this.userPermissions[f][req];
                        if (action === "edit") {
                            action = "update";
                        }
                        if (action === "preview") {
                            action = "read";
                        }
                        if (permission && permission[action]) {
                            return true;
                        }
                    }
                })
                .map(f => {
                    return {
                        text: `${this.joinFirm} ${f}`,
                        value: f
                    }
                });
        }

        setFirmAudiences(firm) {
            this.contentTargetingService.getAudiencesByKey(firm)
                .then(audiences => {
                    this.firmAudiences = audiences["items"];
                });
        }

        setFirmModuleAccess(firm) {
            this.moduleAccessService.getModuleAccess(0, this.MAX_ITEMS, firm)
                .then(response => {
                    this.moduleAccessByFirm = response["items"];
                });
        }

        setFirmNotifications(firm) {
            this.newsService.getNewsByFirmAndRegion(firm, null, this.MAX_ITEMS, 0)
                .then(notifications => {
                    this.firmNotifications = notifications["items"].map(n => {
                        if (n.items.length) {
                            return {
                                name: n.items[0].description,
                                id: n.id
                            }
                        }
                    });
                });
        }

        setFirmApplications(firm) {
            this.applicationLauncherService.getPageList(0, this.MAX_ITEMS, firm)
                .then(applications => {
                    this.firmApplications = applications["items"][0].navigation.appLauncher.map(a => {
                        return {
                            name: a.title,
                            id: a.title
                        }
                    });
                });
        }

        redirectNews() {
            let self = this;
            if (!this.selectedOptions) {
                return;
            }
            try {
                let path;
                let search;
                let region = this.selectedOptions["region"];
                let action = this.selectedOptions["action"];
                let firm = this.selectedOptions["firm"];
                let newsType = this.selectedOptions["newsType"]["value"];
                let item: components.news.INewsArticleResult = this.itemLeadBanner[firm];


                if (action === "preview") {

                    if (newsType === "pageTitle" || (newsType === "leadBannerSpot" && !item)) {
                        this.errorMsg = newsType === "pageTitle" ? "Preview is not available for this news type." : "There is not an active lead banner spot to preview.";
                        this.showErrorMsg = true;
                        return;
                    }
                    else {
                        path = (newsType !== "leadBannerSpot") ? `/news/${region}/${newsType}/preview/all/${firm}` : path = `/news/${region}/${newsType}/preview/${item.id}`;
                        this.navigateToLocation(path, search);
                    }
                } else if (action === "create" && region === "expandedpageNews" && newsType === "pageTitle") {
                    path = `/news/${region}/${newsType}/${action}`;
                    search = { firm };
                        this.pageTitleService.getPageList(0, 8, firm).then((response: any) =>{

                            self.validateExpandedpageNewsPageTitle(path, search, response );

                        });

                } else if (action === "edit") {

                    if (newsType === 'leadBannerSpot' && !item) {
                        this.errorMsg = "There is not an active lead banner spot to edit.";
                        this.showErrorMsg = true;
                        return;
                    }

                    action = (newsType !== "leadBannerSpot") ? "edit/all" : `edit/${item.id}`;
                    path = `/news/${region}/${newsType}/${action}`;
                    if (!firm) {
                            path = "";
                        }
                    search = { firm };
                    if (region === "expandedpageNews" && newsType === "pageTitle") {
                        this.pageTitleService.getPageList(0, 8, firm).then((response: any) => {

                            self.validateExpandedpageNewsPageTitleForEdit(path, search, response);
                        });
                    } else {
                        this.navigateToLocation(path, search);
                    }
                    
                    
                        
                    } else {
                        path = `/news/${region}/${newsType}/${action}`;
                        if (!firm) {
                            path = "";
                        }
                        search = { firm };
                        this.navigateToLocation(path, search);
                    }
                

               
                

            } catch (error) {
                $("body").removeClass("modal-open");
                this.alertService.show({
                    title: "Something went wrong",
                    buttons: components.alert.AlertButtons.Accept
                });
            }
        }

        navigateToLocation(path, search) {
            $("body").removeClass("modal-open");
            if (!search) {
                search = "";
            }
            this.$location.path(path).search(search);
        }

        validateExpandedpageNewsPageTitle(path, search, response) {
                        
            this.pageTitleService.setFirmObj(response.items[0]);
            if (response.items[0].newsPageTitle === "*" || response.items[0].newsPageTitle === "") {
                this.navigateToLocation(path, search);
            } else {

                this.navigateToLocation(path.replace("create", "edit/all"), search);
            }
        }

        validateExpandedpageNewsPageTitleForEdit(path, search, response) {
            
            this.pageTitleService.setFirmObj(response.items[0]);
            if (response.items[0].newsPageTitle === "*" || response.items[0].newsPageTitle === "") {
                this.errorMsg = "Page title does not exists. Create a new one.";
                this.showErrorMsg = true;
                return false;
            } else
            {
                this.navigateToLocation(path, search);
            }
        }

        redirect() {
            if (!this.selectedOptions) {
                return;
            }
            let path;
            let search;
            try {
                let target = this.selectedOptions["target"];
                let action = this.selectedOptions["action"];
                let firm = this.selectedOptions["firm"];
                path = `/${target}/${action}/`;

                switch (this.selectedOptions["target"]) {
                case "contentTargeting":
                {
                    if (action === "create") {
                        path += firm;
                    } else {
                        let id = this.selectedOptions["audience"]["id"];
                        path += id;
                    }
                    break;
                }

                case "notifications":
                {
                    if (action === "create") {
                        path += firm;

                    } else {
                        let id = this.selectedOptions["notification"]["id"];
                        path += id;
                    }
                    break;
                }

                case "hamburgerMenu":
                {
                    if (action === "create") {
                        path += firm + "/new/1";
                    }
                    break;
                }

                case "applicationLauncher":
                {
                    if (action === "create") {
                        search = { firm };
                    }
                    if (action === "edit") {
                        let id = this.selectedOptions["application"]["id"];
                        path += id;
                        search = { firm };
                    }
                    if (action === "preview") {
                        let id = this.selectedOptions["application"]["id"];
                        path += id;
                    }
                    break;
                }

                case "moduleAccess":
                {
                    if (action === "create") {
                        path += firm;
                    }
                    if (action === "edit") {
                        let id = this.selectedOptions["permission"]["id"];
                        path += `${id}/${firm}`;
                    }
                    if (action === "preview") {
                        let id = this.selectedOptions["permission"]["id"];
                        path += id;
                    }
                    break;
                }

                default:
                    break;
                }
                $("body").removeClass("modal-open");
                if (!search) {
                    search = "";
                }
                this.$location.path(path).search(search);
            } catch (error) {
                $("body").removeClass("modal-open");
                this.alertService.show({
                    title: "Something went wrong",
                    buttons: components.alert.AlertButtons.Accept
                });
            }
        }

        createEditPreviewNews(region, action, title) {
            this.showErrorMsg = false;
            this.modalTitle = title;
            const requestedPermissions = this.requestedPermissions[region];
            this.currentAvailableNewsTypes = this.availableNewsTypes[region];
            this.selectedOptions = {
                action,
                region,
                firm: "",
                newsType: ""
            }
            this.availableFirms = this.getAllowedFirms(requestedPermissions, action);
        }

        setupModal(type, action, title) {
            this.modalTitle = title;
            this.selectedOptions = {
                action,
                target: type,
                firm: ""
            }
            switch (type) {
            case "contentTargeting":
                this.selectedOptions["audience"] = "";
                this.availableFirms = this.getAllowedFirms([this.moduleContentTargeting], action);
                break;

            case "moduleAccess":
                this.selectedOptions["permission"] = "";
                this.availableFirms = this.getAllowedFirms([this.moduleModuleAccess], action);
                break;

            case "notifications":
                this.selectedOptions["notification"] = "";
                this.availableFirms = this.getAllowedFirms([this.moduleSystemNotifications], action);
                break;

            case "applicationLauncher":
                this.selectedOptions["application"] = "";
                this.availableFirms = this.getAllowedFirms([this.moduleApplicationLauncher], action);
                break;

            case "hamburgerMenu":
                this.availableFirms = this.getAllowedFirms([this.moduleHamburgerMenu], action);
                break;

            default:
                break;
            }
        }

        submitDisabled(modal) {
            if (typeof this.selectedOptions === "undefined") {
                return true;
            }

            const firm = this.selectedOptions["firm"];
            if (firm == null || firm === "") {
                return true;
            }

            switch (modal) {
            case "newsModal":
                if (this.selectedOptions["newsType"] == null) {
                    return true;
                }
                const newtypetext = this.selectedOptions["newsType"]["text"];

                return newtypetext == null ||
                    newtypetext === "";
            case "contentTargeting":
                if (this.selectedOptions["audience"] == null) {
                    return true;
                }
                const audiencedisplayname = this.selectedOptions["audience"]["displayName"];

                return audiencedisplayname == null ||
                    audiencedisplayname === "";
            case "notificationsModal":
                if (this.selectedOptions["notification"] == null) {
                    return true;
                }
                const notificationName = this.selectedOptions["notification"]["name"];

                return notificationName == null ||
                    notificationName === "";
            case "applicationModal":
                if (this.selectedOptions["application"] == null) {
                    return true;
                }
                const applicationname = this.selectedOptions["application"]["name"];

                return applicationname == null ||
                    applicationname === "";
            case "moduleAccess":
                if (this.selectedOptions["permission"] === null) {
                    return true;
                }

            default:
                return false;
            }
        }
    }
}