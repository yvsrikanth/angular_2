var app;
(function (app) {
    var directives;
    (function (directives) {
        var paginationComponent = (function () {
            function paginationComponent() {
                this.bindings = {
                    skip: '<',
                    take: '<',
                    totalCount: '<',
                    onChangePage: '&',
                    showFirstLastButtons: '@'
                };
                this.controller = app.components.pagination.paginationComponentController;
                this.templateUrl = '/Application/components/pagination/pagination.component.html';
                this.controllerAs = 'pagination';
            }
            return paginationComponent;
        }());
        directives.paginationComponent = paginationComponent;
        angular.module('SPApp').component('paginationComponent', new paginationComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=pagination.component.js.map