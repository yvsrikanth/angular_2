var app;
(function (app) {
    var directives;
    (function (directives) {
        var issueEditComponent = (function () {
            function issueEditComponent() {
                this.controller = app.instantFindEditComponentController.instantFindEditComponentController;
                this.templateUrl = '/Application/components/instantFind/issue/edit/issue.edit.html';
                this.controllerAs = "instantFindCtrl";
            }
            return issueEditComponent;
        }());
        angular.module('SPApp').component('issueEdit', new issueEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=issue.edit.component.js.map