﻿module app.moduleAccessController {

    export class moduleAccessComponentController {

        static $inject = ["$scope", "$rootScope", "securityService"];
        userPermissions: security.shared.IFirmPermissions;
        firms: any;

        constructor(
            private $scope,
            private $rootScope,
            private securityService: security.shared.securityService
        ) {}

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firms = Object.keys(this.userPermissions).sort();
            });
        }
    }
}