var app;
(function (app) {
    var directives;
    (function (directives) {
        var contentTargetingDetailsComponent = (function () {
            function contentTargetingDetailsComponent() {
                this.controller = app.contentTargetingDetailsController.contentTargetingDetailsComponentController;
                this.templateUrl =
                    '/Application/components/contentTargeting/contentTargeting-details/contentTargeting-details.html';
                this.controllerAs = "contentTargetingDetails";
            }
            return contentTargetingDetailsComponent;
        }());
        directives.contentTargetingDetailsComponent = contentTargetingDetailsComponent;
        angular.module('SPApp').component('contentTargetingDetails', new contentTargetingDetailsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=contentTargeting-details.component.js.map