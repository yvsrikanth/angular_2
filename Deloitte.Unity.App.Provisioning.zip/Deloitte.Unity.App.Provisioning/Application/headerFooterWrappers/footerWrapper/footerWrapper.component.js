var app;
(function (app) {
    var headerFooterWrappers;
    (function (headerFooterWrappers) {
        var footerWrapper;
        (function (footerWrapper) {
            footerWrapper.footerWrapperComponent = {
                templateUrl: "/Application/headerFooterWrappers/footerWrapper/footerWrapper.component.html",
                controller: headerFooterWrappers.headerFooterComponentController,
                controllerAs: "vm"
            };
        })(footerWrapper = headerFooterWrappers.footerWrapper || (headerFooterWrappers.footerWrapper = {}));
    })(headerFooterWrappers = app.headerFooterWrappers || (app.headerFooterWrappers = {}));
})(app || (app = {}));
//# sourceMappingURL=footerWrapper.component.js.map