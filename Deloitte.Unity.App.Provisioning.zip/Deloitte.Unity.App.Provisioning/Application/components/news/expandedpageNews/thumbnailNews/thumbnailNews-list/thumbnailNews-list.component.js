var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedThumbnailNewsListComponent = (function () {
            function expandedThumbnailNewsListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.expandedThumbnailNewsListController.thumbnailNewsListComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-list/thumbnailNews-list.component.html";
                this.controllerAs = "thumbnailNewsList";
            }
            return expandedThumbnailNewsListComponent;
        }());
        directives.expandedThumbnailNewsListComponent = expandedThumbnailNewsListComponent;
        angular.module("SPApp").component("expandedThumbnailNewsList", new expandedThumbnailNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-list.component.js.map