var app;
(function (app) {
    var directives;
    (function (directives) {
        var moduleAccessComponent = (function () {
            function moduleAccessComponent() {
                this.bindings = {
                    moduleAccessItem: "@"
                };
                this.controller = app.moduleAccessController.moduleAccessComponentController;
                this.templateUrl = "/Application/components/moduleAccess/moduleAccess.html";
                this.controllerAs = "moduleAccess";
            }
            return moduleAccessComponent;
        }());
        angular.module("SPApp").component("moduleAccess", new moduleAccessComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess.component.js.map