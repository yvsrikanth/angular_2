var app;
(function (app) {
    var expandedThumbnailNewsPreviewController;
    (function (expandedThumbnailNewsPreviewController) {
        var thumbnailNewsPreviewComponentController = (function () {
            function thumbnailNewsPreviewComponentController($scope, $rootScope, $routeParams, newsService, $location, alertService, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.$routeParams = $routeParams;
                this.newsService = newsService;
                this.$location = $location;
                this.alertService = alertService;
                this.securityService = securityService;
            }
            thumbnailNewsPreviewComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setThumbnailNewsParams();
                this.thumbnailNewsItem = [];
                this.getDetailsThumbnailNewsItem();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            thumbnailNewsPreviewComponentController.prototype.setThumbnailNewsParams = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                    this.resourceTitle = "Thumbnail news preview";
                    this.buttonText = "Edit news";
                }
                if (angular.isDefined(this.$routeParams.firm)) {
                    this.firm = this.$routeParams.firm;
                    this.resourceTitle = "Thumbnail news layout preview";
                    this.buttonText = "Edit layout";
                }
            };
            thumbnailNewsPreviewComponentController.prototype.getDetailsThumbnailNewsItem = function () {
                if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                    this.redirectToHome("Params can't be identified");
                }
                if (angular.isDefined(this.firm)) {
                    this.requestAllThumbnailNewsData();
                    return;
                }
                if (angular.isDefined(this.id)) {
                    this.requestThumbnailNewsItem();
                    return;
                }
            };
            thumbnailNewsPreviewComponentController.prototype.requestAllThumbnailNewsData = function () {
                var _this = this;
                var promise;
                promise = this.newsService.get({ firm: this.firm, region: "Thumbnail-newstab", take: 14 }).then(function (result) {
                    _this.thumbnailNewsItem = result.items;
                    _this.sortByPosition();
                });
                promise.then(function () {
                    _this.setSelectedItem();
                });
            };
            thumbnailNewsPreviewComponentController.prototype.requestThumbnailNewsItem = function () {
                var _this = this;
                if (sessionStorage.getItem("news-item")) {
                    var data = angular.fromJson(sessionStorage.getItem("news-item"));
                    this.thumbnailNewsItem.push(data);
                    this.setSelectedItem();
                }
                else {
                    var promise;
                    promise = this.newsService.getById(this.id).then(function (item) {
                        _this.thumbnailNewsItem.push(item);
                    }, function (response) {
                        _this.redirectToHome(response.statusText);
                    });
                    promise.then(function () {
                        _this.setSelectedItem();
                    });
                }
            };
            thumbnailNewsPreviewComponentController.prototype.setSelectedItem = function () {
                this.selectedItem = this.thumbnailNewsItem[0];
                if (!angular.isDefined(this.firm)) {
                    this.firm = this.selectedItem.firm;
                }
                this.showTitle = this.thumbnailNewsItem.length > 1;
            };
            thumbnailNewsPreviewComponentController.prototype.redirectToHome = function (msg) {
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: msg,
                    dismissText: "Ok"
                });
                this.$location.path("/news/expandedpageNews/thumbnailNews");
            };
            thumbnailNewsPreviewComponentController.prototype.sortByPosition = function () {
                if (!angular.isObject(this.thumbnailNewsItem))
                    return;
                var array = [];
                for (var item in this.thumbnailNewsItem) {
                    array.push(this.thumbnailNewsItem[item]);
                }
                array.sort(function (a, b) {
                    return (a["ordinal"] > b["ordinal"] ? 1 : -1);
                });
                this.thumbnailNewsItem = array;
            };
            return thumbnailNewsPreviewComponentController;
        }());
        thumbnailNewsPreviewComponentController.$inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];
        expandedThumbnailNewsPreviewController.thumbnailNewsPreviewComponentController = thumbnailNewsPreviewComponentController;
    })(expandedThumbnailNewsPreviewController = app.expandedThumbnailNewsPreviewController || (app.expandedThumbnailNewsPreviewController = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-preview.controller.js.map