﻿module app.components.news {
    export class genericNewsLayoutPreviewController {
        news: INewsArticleData[];
        selectedNew: INewsArticleData;
        maxItems: number;
        skipSort: boolean;

        $onChanges(changes) {
            if (!this.skipSort) {
                this.news = genericNewsCreateEditController.processOrdinalSoring(this.news);
            }


            if (!this.selectedNew && this.news && this.news.length)
                this.selectedNew = genericNewsLayoutPreviewController.firtsWithId(this.news);
            this.setMaxItems();
        }

        static firtsWithId(news: components.news.INewsArticleResult[]) {
            if (!news.length)
                return null;

            for (var i = 0; i < news.length; i++) {
                if (news[i].id)
                    return news[i];
            }
            return news[0];
        }

        onSetSelectedPreviewItem(item: INewsArticleData) {
            this.selectedNew = item;
        }

        getSrc(item: INewsArticleData, attr?: string) {
            if (!attr)
                attr = "image";
            var attrUrl = attr + "Url";

            if (item && item.items && item.items.length)
                return item.items[0][attr] || item.items[0][attrUrl];

            return null;
        }

        hasSrc(item: INewsArticleData, attr?: string) {
            return this.getSrc(item, attr);
        }

        setMaxItems() {

            if (!angular.isDefined(this.maxItems)) {
                return;
            }

            let newsTemp: any = [this.maxItems];
            for (let index = 0; index < this.maxItems; index++) {
                newsTemp[index] = {};
            }
            for (let item of this.news) {
                newsTemp[item.ordinal - 1] = item;
            }
            this.news = newsTemp;

        }
    }
}