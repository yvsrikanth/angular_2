﻿module app.components.newsTable {
    export class newsTableComponentController {


        static $inject = ["$scope", "$q", "securityService", "contentTargetingService", "alertService", "newsService", "firmService", "userService", "clientSidePaginationFactory"];

        audiences: any;
        audiencesByItem: any;
        userPermissions: security.shared.IModulePermissions;
        paginatedList: pagination.clientSidePaginationFactory<components.news.INewsArticleResult>;
        firm: string;
        rows: components.news.INewsArticleResult[];
        today: string;
        reverse: boolean;
        columnNames = ["items", "audiences", "modifiedBy", "modified"];

        constructor(
            private $scope: ng.IScope,
            private $q: ng.IQService,
            private securityService: security.shared.securityService,
            private audienceService: services.contentTargetingService,
            private alertService: components.alert.alertService,
            private newsService: services.newsService,
            private firmService: services.firmService,
            private userService: services.userService,
            private paginatedListFactory: any
        ) {
            this.paginatedList = this.paginatedListFactory.instance();
        }


        $onInit() {

            this.paginatedList.sortMethods["newsTitle"] = (a, b) => {
                var castedA = <components.news.INewsArticleDataItem[]>a;
                var castedB = <components.news.INewsArticleDataItem[]>b;

                if (castedA[0].title.toLowerCase && castedB[0].title.toLowerCase)
                    return (castedA[0].title.toLowerCase() > castedB[0].title.toLowerCase() ? 1 : -1);
                else
                    return (castedA[0].title > castedB[0].title ? 1 : -1);
            };

            this.loadAudiences();
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });
            this.paginatedList.take = 8;
            this.reverse = false;
            this.today = new Date().toISOString().slice(0, 10);
        }

        $onChanges(changes) {
            this.getAuthorName();
            this.setDate();
            if (changes.rows) {
                this.paginatedList.setItems(this.rows || []);
            }
        }

        loadAudiences() {

            this.audienceService.getAudiencesData(this.firm).then((audiences: any) => {
                this.audiences = audiences.items;
            });

        }

        getNameAudience(audienceId) {


            let notFound = "Audience not found - " + audienceId;

            if (!angular.isDefined(this.audiences) || audienceId === "") { return notFound; }

            for (let audience of this.audiences) {

                if (audience.id === audienceId) { return audience.displayName; }
            }

            return notFound;
        }

        getAudiencesList(audiences) {
            this.audiencesByItem = [];

            for (let audience of audiences) {
                this.audiencesByItem.push(this.getNameAudience(audience));
            }

        }

        getAuthorName() {

            if (!this.rows || this.rows.length <= 0) return;


            var ids = this.rows
                .filter(item => item.modifiedBy && item.modifiedBy.toUpperCase() !== "SYSTEM" && item.modifiedBy.toUpperCase() !== "JOBS")
                .map(i => (i.modifiedBy as string))
                .filter((v, i, a) => a.indexOf(v) === i)
                .join(",");

            this.userService.getUserList(ids).then((data: any) => {

                for (let item of this.rows) {
                    let exist = false;
                    for (let author of data.items) {
                        if (item.modifiedBy === author.id) {
                            exist = true;
                            item["author"] = author.attributes.name.first + " " + author.attributes.name.last;
                            break;
                        }
                    }
                    if (!exist) item["author"] = item.modifiedBy;
                }
            });


        }

        deleteItem(item) {

            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: "Delete an entry ",
                message: "The selected entry will be deleted. This action cannot be undone.",
                dismissText: "Cancel",
                confirmText: "Delete",
                onConfirm: () => {
                    this.onConfirmDeleteLeadNewsItem(item);
                    this.alertService.close();
                }
            });
        }

        setEnableItem(item: components.news.INewsArticleResult) {
            if (item["$enableOptionDisabled"])
                return;

            var originalState = item.isEnabled;
            item.isEnabled = !item.isEnabled;
            item["$enableOptionDisabled"] = true;
            this.newsService
                .getById(item.id, "image")
                .then(itemWithImg => {
                    itemWithImg.isEnabled = item.isEnabled;
                    return itemWithImg;
                })
                .then(itemWithImgEdited => {
                    return this.newsService.put(itemWithImgEdited);
                })
                .catch(() => {
                    item.isEnabled = originalState;
                })
                .finally(() => {
                    item["$enableOptionDisabled"] = false;
                    if (item.isEnabled) this.setDisableAllItems(item);
                });
        }

        setDisableAllItems(item: components.news.INewsArticleResult) {

            var promises = [];

            for (var index = 0; index < this.rows.length; index++) {
                var row = this.rows[index] as components.news.INewsArticleResult;

                //Identify items to disable
                if (item.id !== row.id && row.isEnabled) {
                    row.isEnabled = false;
                    promises.push(this.newsService.put(row));
                }
            }

            this.$q.all(promises).then(() => {
            }, () => {
            });
        }

        setDetailsItem(data) {
            sessionStorage.setItem("news-item", angular.toJson(data));
        }

        onConfirmDeleteLeadNewsItem(item) {

            this.newsService.delete(item.id).then(() => {
                this.rows.splice(this.rows.indexOf(item), 1);
                this.paginatedList.setItems(this.rows);
                if (!this.rows.length) {
                    this.deleteBlockname();
                }
            });
        }

        deleteBlockname() {
            var that = this;
            this.firmService
                .get({
                    key: this.firm
                })
                .then(response => {
                    if (response.items.length > 0) {
                        var item = response.items[0];
                        item.newsHeadlineTitle = "*";

                        return that.firmService.put(item);
                    }
                });
        }

        setDate() {

            if (!this.rows || this.rows.length <= 0) return;
            for (let row of this.rows) {
                row.modified = new Date(row.modified).toISOString().slice(0, 10);
            }
        }

        sortBy(index: number) {

            let column = index <= 1 ? "title" : (index === 2 ? "modifiedBy" : "modified");

            if (!angular.isObject(this.rows)) return this.rows;

            var array = [];
            for (var row in this.rows) {
                array.push(this.rows[row]);
            }

            array.sort(function (a, b) {

                if (column === "title") {
                    return (a.items[0][column] > b.items[0][column] ? 1 : -1);
                } else {
                    return (a[column] > b[column] ? 1 : -1);
                }
            });

            if (this.reverse) array.reverse();
            this.reverse = !this.reverse;

            this.rows = array;

        }

    }
}