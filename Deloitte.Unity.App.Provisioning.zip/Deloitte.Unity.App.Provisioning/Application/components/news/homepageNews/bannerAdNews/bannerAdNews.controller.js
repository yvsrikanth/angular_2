var app;
(function (app) {
    var components;
    (function (components) {
        var bannerAdNews;
        (function (bannerAdNews) {
            var bannerAdNewsComponentController = (function () {
                function bannerAdNewsComponentController($scope, $rootScope, $compile, securityService) {
                    this.$scope = $scope;
                    this.$rootScope = $rootScope;
                    this.$compile = $compile;
                    this.securityService = securityService;
                }
                bannerAdNewsComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.securityService.getUserPermissions().then(function (permissions) {
                        _this.userPermissions = permissions;
                        _this.firms = Object.keys(_this.userPermissions).sort();
                    });
                };
                return bannerAdNewsComponentController;
            }());
            bannerAdNewsComponentController.$inject = ["$scope", "$rootScope", "$compile", "securityService"];
            bannerAdNews.bannerAdNewsComponentController = bannerAdNewsComponentController;
        })(bannerAdNews = components.bannerAdNews || (components.bannerAdNews = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews.controller.js.map