﻿module app.hamburgerMenuWizardController {
    export class hamburgerMenuWizardComponentController {

        static $inject = ["$location", "$routeParams"];
        
        isPreview: boolean;
        currentLevel: string;
        currentRoute: string;

        constructor(
            private $location,
            private $routeParams) {
            let self = this;
            self.currentLevel = self.$routeParams.level ? self.$routeParams.level : '1';
            self.currentRoute = self.$location.path().split('/')[2];
        }

        getUrl(level: string): string {
            let self = this;
            if (!self.isPreview) {
                return null;
            }
            return '#/hamburgerMenu/' + self.currentRoute + '/' + self.$routeParams.firm + '/' + self.$routeParams.code + '/' + level;
        }
    }
}