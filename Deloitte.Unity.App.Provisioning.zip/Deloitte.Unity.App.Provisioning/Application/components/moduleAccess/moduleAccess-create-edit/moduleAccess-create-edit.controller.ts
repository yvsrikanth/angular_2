﻿module app.moduleAccessCreateEditController {

    export class moduleAccessCreateEditComponentController {

        static $inject = ["moduleAccessService", "securityService", "$routeParams", "alertService", "$location", "adGraphService"];

        id: string;
        firm: string;
        userPermissions: security.shared.IModulePermissions;
        modelUserPermissions: security.shared.IModulePermissions = {};
        moduleAccessItem: any;
        errorMessage: string;
        isNew: boolean;
        isSubmited: boolean = false;

        constructor(
            private moduleAccessService: services.moduleAccessService,
            private securityService: security.shared.securityService,
            private $routeParams,
            private alertService: components.alert.alertService,
            private $location,
            private adGraphService: services.adGraphService
        ) { }

        $onInit() {

            this.moduleAccessItem = {};
            this.setMemberFirm();

            this.securityService.getUserPermissions().then(permissions => {

                this.userPermissions = permissions[this.firm];
                this.initModelPermissions();

            });


        }

        countSelecteds(group: security.shared.IPermissions, countDisabled: boolean) {
            var trues = 0;

            if (group.create) trues++;
            if (group.delete) trues++;
            if (group.read) trues++;
            if (group.update) trues++;

            if (countDisabled && group.disable) trues++;

            return trues;
        }

        anySelected(group: security.shared.IPermissions, countDisabled: boolean) {
            return this.countSelecteds(group, countDisabled) > 0;
        }

        allSelected(group: security.shared.IPermissions, countDisabled: boolean) {
            return this.countSelecteds(group, countDisabled) === (countDisabled ? 5 : 4);
        }

        initModelPermissions() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.setModuleAccessId();
                this.getModuleAccessInfo();
                this.isNew = false;
            } else {
                this.initCreateUserPermissions();
                this.isNew = true;
            }
        }

        initCreateUserPermissions() {

            for (let module in this.userPermissions) {
                this.modelUserPermissions[module] =
                    {
                        create: false,
                        read: false,
                        update: false,
                        delete: false,
                        disable: false
                    }
            }
        }

        initEditUserPermissions() {

            if (!angular.isDefined(this.moduleAccessItem)) {
                return;
            }

            for (let module in this.userPermissions) {


                let create = this.moduleAccessItem.permissions.indexOf(module + "-create") !== -1;
                let read = this.moduleAccessItem.permissions.indexOf(module + "-read") !== -1;
                let update = this.moduleAccessItem.permissions.indexOf(module + "-update") !== -1;
                let del = this.moduleAccessItem.permissions.indexOf(module + "-delete") !== -1;
                let disable = this.moduleAccessItem.permissions.indexOf(module + "-disable") !== -1;

                this.modelUserPermissions[module] =
                    {
                        create: create,
                        read: read,
                        update: update,
                        delete: del,
                        disable: disable
                    }
            }

        }

        getModuleAccessInfo() {

            let that = this;
            that.moduleAccessService.getModuleAccessItem(that.id).then(item => {

                that.moduleAccessItem = item;
                that.initEditUserPermissions();

            }, response => {

                that.alertService.show({
                    buttons: app.components.alert.AlertButtons.Accept,
                    title: "Error",
                    message: response.statusText,
                    dismissText: "Ok"
                });

                that.$location.path("/moduleAccess");
            });
        }

        setMemberFirm() {

            if (angular.isDefined(this.$routeParams.firm)) {
                if (!angular.isDefined(this.firm)) { this.firm = this.$routeParams.firm; }
                this.moduleAccessItem.firm = this.firm;
            }
        }

        setModuleAccessId() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
            }

        }

        validateFormFields() {

            if (this.moduleAccessItem.firm === null || !angular.isDefined(this.moduleAccessItem.firm) || this.moduleAccessItem.firm === "") {
                this.errorMessage = "The member firm is required";
                return false;
            }
            if (this.moduleAccessItem.group === null || !angular.isDefined(this.moduleAccessItem.group) || this.moduleAccessItem.group === "") {
                this.errorMessage = "The AD Group is required";
                return false;
            }
            if (this.moduleAccessItem.displayName === null || !angular.isDefined(this.moduleAccessItem.displayName) || this.moduleAccessItem.displayName === "") {
                this.errorMessage = "The Permission set name is required";
                return false;
            }

            this.getListPermissions();
            if (this.moduleAccessItem.permissions.length <= 0) {
                this.errorMessage = "At least one permission is required";
                return false;
            }

            this.errorMessage = "";
            return true;

        }

        getListPermissions() {

            let listPermissions = [];
            angular.forEach(this.modelUserPermissions, function (permissions, module) {

                angular.forEach(permissions, function (access, permission) {
                    if (access === true) { listPermissions.push(module + "-" + permission); }
                });

            });

            this.moduleAccessItem.permissions = listPermissions;
        }
        
        isAdGroupValid() {
            return this.moduleAccessItem.group;
        }

        saveModuleAccess() {

            let that = this;
            that.isSubmited = true;

            if (!that.validateFormFields() || !this.isAdGroupValid()) {
                that.isSubmited = false;
                return;
            }

            that.moduleAccessService.createModuleAccess(this.moduleAccessItem, this.isNew).then(() => {

                that.$location.path("/moduleAccess");

            }, response => {
                that.isSubmited = false;
                if (response.status === 400) {

                    this.errorMessage = response.data.message;

                } else {

                    that.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: response.statusText !== "" ? response.statusText : 'Server error',
                        message: response.data !== null ? response.data.message : 'Server error',
                        dismissText: "Ok"
                    });
                }
            });

        }

        checkAllModulesPermissions(module) {

            let check = angular.element("#box_all_" + module)[0]["checked"];
            this.modelUserPermissions[module] =
                {
                    create: check,
                    read: check,
                    update: check,
                    delete: check,
                    disable: check
                };
        }

    }

}