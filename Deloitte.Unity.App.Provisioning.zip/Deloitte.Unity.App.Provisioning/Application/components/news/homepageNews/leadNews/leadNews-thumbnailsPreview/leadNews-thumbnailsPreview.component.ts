﻿module app.components.news.homepageNews.leadNews {
    var leadNewsThumbnailsPreviewComponent: ng.IComponentOptions = {

        bindings: {
            news: "<",
            selectedNew: "=?",
            skipSort: "<"
        },
        controller: genericNewsLayoutPreviewController,
        templateUrl: "/Application/components/news/homepageNews/leadNews/leadNews-thumbnailsPreview/leadNews-thumbnailsPreview.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("leadNewsThumbnailsPreview", leadNewsThumbnailsPreviewComponent);
}