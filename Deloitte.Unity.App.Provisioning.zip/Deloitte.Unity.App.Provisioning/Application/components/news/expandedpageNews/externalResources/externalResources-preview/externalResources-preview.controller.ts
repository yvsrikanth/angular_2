﻿module app.expandedExternalResourcesPreviewController {

    export class externalResourcesPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];

        id: string;
        firm: string;
        externalResourcesItem: any;
        selectedItem: any;
        showTitle: boolean;
        resourceTitle: string;
        buttonText: string;
        userPermissions: security.shared.IModulePermissions;


        constructor(
            private $scope,
            private $rootScope,
            private $routeParams,
            private newsService: services.newsService,
            private $location,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService
        ) { }

        $onInit() {

            this.setParams();
            this.externalResourcesItem = [];
            this.getDetailsExternalResourcesItem();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        setParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
                this.resourceTitle = "Preview external resource";
                this.buttonText = "Edit resource";
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
                this.resourceTitle = "External resource layout preview";
                this.buttonText = "Edit layout";
            }
        }

        getDetailsExternalResourcesItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllExternalResourceData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestExternalResourcesItem();
                return;
            }

        }

        requestAllExternalResourceData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "external-links", take: 8 }).then(result => {
                this.externalResourcesItem = result.items;
                this.externalResourcesItem.sort((a, b) => a.ordinal - b.ordinal)

            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        requestExternalResourcesItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.externalResourcesItem.push(data);
                this.setSelectedItem();

            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.externalResourcesItem.push(item);
                }, response => {
                    this.redirectToHome(response.statusText);
                });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {

            this.selectedItem = this.externalResourcesItem[0];
            if (!angular.isDefined(this.firm)) { this.firm = this.selectedItem.firm; }
            this.showTitle = this.externalResourcesItem.length > 1;
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/expandedpageNews/externalResources");
        }
    }
}