var app;
(function (app) {
    var services;
    (function (services) {
        var adGraphService = (function () {
            function adGraphService($http) {
                this.$http = $http;
            }
            adGraphService.prototype.getGroups = function (displayName) {
                var params = {};
                if (displayName) {
                    params["$filter"] = "displayName eq '" + displayName + "'";
                }
                return this.$http
                    .get("https://graph.microsoft.com/v1.0/deloitte.com/groups", { params: params })
                    .then(function (response) { return response.data["value"]; });
            };
            return adGraphService;
        }());
        adGraphService.$inject = ["$http"];
        services.adGraphService = adGraphService;
        angular.module("SPApp").service("adGraphService", adGraphService);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=adGraph.service.js.map