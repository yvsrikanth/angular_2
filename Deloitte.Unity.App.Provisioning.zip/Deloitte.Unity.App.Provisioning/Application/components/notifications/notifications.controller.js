var app;
(function (app) {
    var notificationsComponentController;
    (function (notificationsComponentController_1) {
        var notificationsComponentController = (function () {
            function notificationsComponentController(securityService) {
                this.securityService = securityService;
            }
            notificationsComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    //this.firms = Object.keys(this.userPermissions).sort();
                    _this.validatePermissionFirms();
                });
                this.actives = this.type === "active";
            };
            notificationsComponentController.prototype.validatePermissionFirms = function () {
                this.firms = [];
                var tmpFirms = Object.keys(this.userPermissions).sort();
                for (var _i = 0, tmpFirms_1 = tmpFirms; _i < tmpFirms_1.length; _i++) {
                    var item = tmpFirms_1[_i];
                    if (item === "CH" || item === "UK") {
                        this.firms.push(item);
                    }
                }
            };
            return notificationsComponentController;
        }());
        notificationsComponentController.$inject = ['securityService'];
        notificationsComponentController_1.notificationsComponentController = notificationsComponentController;
    })(notificationsComponentController = app.notificationsComponentController || (app.notificationsComponentController = {}));
})(app || (app = {}));
//# sourceMappingURL=notifications.controller.js.map