var app;
(function (app) {
    var headerFooterWrappers;
    (function (headerFooterWrappers) {
        var headerWrapper;
        (function (headerWrapper) {
            headerWrapper.headerWrapperComponent = {
                templateUrl: "/Application/headerFooterWrappers/headerWrapper/headerWrapper.component.html",
                controller: headerFooterWrappers.headerFooterComponentController,
                controllerAs: "vm"
            };
        })(headerWrapper = headerFooterWrappers.headerWrapper || (headerFooterWrappers.headerWrapper = {}));
    })(headerFooterWrappers = app.headerFooterWrappers || (app.headerFooterWrappers = {}));
})(app || (app = {}));
//# sourceMappingURL=headerWrapper.component.js.map