var app;
(function (app) {
    var directives;
    (function (directives) {
        var pageTitleCreateComponent = (function () {
            function pageTitleCreateComponent() {
                this.bindings = {
                    contentTargetItem: '@'
                };
                this.controller = app.pageTitleCreateController.pageTitleCreateComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/pageTitle/pageTitle-create-edit/pageTitle-create-edit.html";
                this.controllerAs = "pageTitleCreateVm";
            }
            return pageTitleCreateComponent;
        }());
        angular.module('SPApp').component('pageTitleCreate', new pageTitleCreateComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle-create-edit.component.js.map