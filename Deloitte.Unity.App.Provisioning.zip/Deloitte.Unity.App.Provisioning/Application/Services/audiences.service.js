var app;
(function (app) {
    var services;
    (function (services) {
        var audiencesService = (function () {
            function audiencesService($http, appSettings) {
                this.$http = $http;
                this.appSettings = appSettings;
                this.resourcePath = '/audiences/';
            }
            /**
             * Retrieve a list of audiences
             * @param options Request parameters
             */
            audiencesService.prototype.get = function (options) {
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath, { params: options || {} })
                    .then(function (result) { return result.data; });
            };
            /**
             * Retrieves a single audience by id
             * @param id Unique identifier or key for the audience
             * @param include Requests that optional fields or data be embedded in the response
             */
            audiencesService.prototype.getById = function (id) {
                var include = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    include[_i - 1] = arguments[_i];
                }
                var includes = include ? include.join(",") : "";
                return this.$http
                    .get(this.appSettings.apiUrl + this.resourcePath + id, { params: { include: includes } })
                    .then(function (result) { return result.data; });
            };
            return audiencesService;
        }());
        audiencesService.$inject = ['$http', 'appSettings'];
        services.audiencesService = audiencesService;
        function myServiceFactory($rootElement) {
            var inj = $rootElement.injector();
            return inj.instantiate(audiencesService);
        }
        angular.module("SPApp").factory('audiencesService', ['$rootElement', function ($rootElement) { return myServiceFactory($rootElement); }]);
    })(services = app.services || (app.services = {}));
})(app || (app = {}));
//# sourceMappingURL=audiences.service.js.map