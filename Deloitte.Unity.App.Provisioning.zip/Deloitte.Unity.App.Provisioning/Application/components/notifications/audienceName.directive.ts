﻿module app.directives {
    export interface IAudienceNameScope extends ng.IScope {
        audienceId: string;
        name: string;
    }

    class AudienceName implements ng.IDirective {
        
        restrict = 'A';
        template = '{{name}}<ng-transclude></ng-transclude>';
        transclude = true;
        scope: any = {
            audienceId: '='
        }

        constructor(private audiencesService: services.audiencesService) { }

        link = (scope: IAudienceNameScope) => {
            scope.name = scope.audienceId;
            this.audiencesService.getById(scope.audienceId)
                .then(res => {
                    scope.name = res['displayName'];
                }, () => {
                    scope.name = "Audience not found";
                });
        }

        static factory(): ng.IDirectiveFactory {
            const directive = (audiencesService) => new AudienceName(audiencesService);
            directive.$inject = ['audiencesService'];
            return directive;
        }
    }
    angular.module('SPApp').directive('audienceName', AudienceName.factory());
}