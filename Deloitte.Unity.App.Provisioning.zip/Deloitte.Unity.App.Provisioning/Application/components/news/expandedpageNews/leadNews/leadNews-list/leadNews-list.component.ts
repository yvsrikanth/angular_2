﻿namespace app.directives {
    export class expandedLeadNewsListComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                firm: "<"
            };
            this.controller = expandedLeadNewsListController.leadNewsListComponentController;
            this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews-list/leadNews-list.component.html";
            this.controllerAs = "leadNewsList";
        }
    }
    angular.module("SPApp").component("expandedLeadNewsList", new expandedLeadNewsListComponent());
}