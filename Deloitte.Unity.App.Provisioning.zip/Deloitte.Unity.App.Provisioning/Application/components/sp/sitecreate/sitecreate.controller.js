/// <reference path="../../../services/user.service.ts" />
/// <reference path="../../../../scripts/typings/angularjs/angular.d.ts" />
/// <reference path="../../../services/sitetype.service.ts" />
/// <reference path="../../../services/firm.service.ts" />
/// <reference path="../../../services/unity.service.ts" />
/// <reference path="../../../services/siterequestfield.service.ts" />
/// <reference path="../../../services/siterequest.service.ts" />
var app;
(function (app) {
    var components;
    (function (components) {
        var sitecreate;
        (function (sitecreate) {
            var sitecreateComponentController = (function () {
                function sitecreateComponentController(userService, siteRequestFieldService, siteRequestService, firmService, siteTypeService) {
                    this.userService = userService;
                    this.siteRequestFieldService = siteRequestFieldService;
                    this.siteRequestService = siteRequestService;
                    this.firmService = firmService;
                    this.siteTypeService = siteTypeService;
                }
                sitecreateComponentController.prototype.$onInit = function () {
                    var _this = this;
                    this.userService.getUser("rperla").then(function (data) {
                        _this.test = data;
                        _this.userName = data.attributes.preferredName;
                        //this.userFirm = data.attributes.firm.toLowerCase();
                        //console.log(data.attributes.firm);
                    });
                    //temp
                    this.siteRequestFieldService
                        .get({ skip: 0, take: 50, firm: "us" })
                        .then(function (data) {
                        console.log(data);
                        _this.firmFields = data.items;
                    });
                    this.firmService
                        .get({ skip: 0, take: 1, key: "us" })
                        .then(function (data) {
                        _this.firmData = data.items[0];
                    });
                    //End!!! Temp
                    this.siteTypeService
                        .get({ skip: 0, take: 10 })
                        .then(function (data) {
                        _this.siteTypes = data;
                    });
                };
                //  this.DynamicFormData = $window.fieldsColl;
                sitecreateComponentController.prototype.submitForm = function (isFormValid) {
                    var firmVals = {};
                    firmVals["key"] = "test";
                    firmVals["value"] = "test";
                    //preparing firm values
                    //prepare site request JSON
                    var siteRequest = {};
                    siteRequest["title"] = this.title;
                    siteRequest["url"] = this.url;
                    siteRequest["sitetype"] = this.siteType;
                    siteRequest["requestor"] = this.pcontact;
                    siteRequest["originalRequestor"] = this.sponser;
                    siteRequest["primaryAdministrator"] = this.pcontact;
                    siteRequest["isSearchable"] = this.isSearch;
                    siteRequest["additionalAdmin"] = ["test", "test"];
                    siteRequest["description"] = this.breason;
                    siteRequest["exception"] = "No Exceptions";
                    siteRequest["firm"] = this.firmData.key;
                    siteRequest["firmValues"] = [firmVals];
                    siteRequest["language"] = this.firmData.language;
                    siteRequest["status"] = "Requested";
                    siteRequest["timeZone"] = this.firmData.timezone;
                    siteRequest["size"] = this.firmData.publishingStorage;
                    siteRequest["omnitureRSID"] = "78687d9f-1e5b-4aaa-a680-154bf95c3eae";
                    //posting form data to API
                    this.siteRequestService.post(siteRequest).then(function () {
                        //navigate to reports page !!!
                        console.log("Done !!!");
                    });
                };
                sitecreateComponentController.prototype.onSiteTypeChange = function (selectedVal) {
                    console.log(selectedVal);
                    if (selectedVal == "ps") {
                        angular.element("#publishingSite").css("display", "block");
                        angular.element("#teamSite").css("display", "none");
                        angular.element("#blogSite").css("display", "none");
                    }
                    else if (selectedVal == "ts") {
                        angular.element("#publishingSite").css("display", "none");
                        angular.element("#teamSite").css("display", "block");
                        angular.element("#blogSite").css("display", "none");
                    }
                    else {
                        angular.element("#publishingSite").css("display", "none");
                        angular.element("#teamSite").css("display", "none");
                        angular.element("#blogSite").css("display", "block");
                    }
                };
                return sitecreateComponentController;
            }());
            sitecreateComponentController.$inject = ["userService", "siteRequestFieldService", "siteRequestService", "firmService", "siteTypeService"];
            sitecreate.sitecreateComponentController = sitecreateComponentController;
        })(sitecreate = components.sitecreate || (components.sitecreate = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=sitecreate.controller.js.map