var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var notificationCreateEditController;
        (function (notificationCreateEditController_1) {
            var notificationCreateEditController = (function (_super) {
                __extends(notificationCreateEditController, _super);
                function notificationCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                    return _super.call(this, 
                    // Injected dependencies
                    rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "", "Edit notifications", "Create notifications", 1, "homepage-notifications", "/notifications/" + ($routeParams.actives === "false" ? "disabled" : "active")) || this;
                }
                notificationCreateEditController.prototype.fetchItems = function (id) {
                    var _this = this;
                    if (id) {
                        this.newsService
                            .getById(id)
                            .then(function (item) {
                            _this.items = [item];
                            _this.setItemsToPreview(_this.items);
                            return _this.items;
                        });
                    }
                };
                notificationCreateEditController.prototype.getEmptyItem = function (ordinal, id) {
                    var tmp = _super.prototype.getEmptyItem.call(this, ordinal, id);
                    return tmp;
                };
                notificationCreateEditController.prototype.save = function (checkPreviewChange) {
                    this.setItemsToPreview(this.items);
                    _super.prototype.save.call(this, checkPreviewChange);
                };
                return notificationCreateEditController;
            }(components.news.genericNewsCreateEditController));
            notificationCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
            notificationCreateEditController_1.notificationCreateEditController = notificationCreateEditController;
        })(notificationCreateEditController = components.notificationCreateEditController || (components.notificationCreateEditController = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=notification-create-edit.controller.js.map