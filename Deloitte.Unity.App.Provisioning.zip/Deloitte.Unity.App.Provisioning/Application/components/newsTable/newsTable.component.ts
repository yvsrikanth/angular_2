﻿module app.components.newsTable {
    export class newsTableComponent implements ng.IComponentController {

        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                columns: "<",
                rows: "<",
                firm: "@",
                module: "@",
                linkButton: "=",
                editButton: "=",
                deleteButton: "=",
                visibleButton: "=",
                editUrl: "@",
                previewUrl: "@"
            };
            this.controller = newsTable.newsTableComponentController;
            this.templateUrl = "/Application/components/newsTable/newsTable.component.html";
            this.controllerAs = "table";
        }
    }
    angular.module("SPApp").component("newsTable", new newsTableComponent());
}