var app;
(function (app) {
    var directives;
    (function (directives) {
        var moduleAccessCreateEditComponent = (function () {
            function moduleAccessCreateEditComponent() {
                this.bindings = {
                    firm: "<",
                    id: "<"
                };
                this.controller = app.moduleAccessCreateEditController.moduleAccessCreateEditComponentController;
                this.templateUrl = "/Application/components/moduleAccess/moduleAccess-create-edit/moduleAccess-create-edit.html";
                this.controllerAs = "moduleAccessCreate";
            }
            return moduleAccessCreateEditComponent;
        }());
        angular.module("SPApp").component("moduleAccessCreate", new moduleAccessCreateEditComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-create-edit.component.js.map