﻿namespace app.directives {
    export class applicationLauncherListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: '='
            };
            this.controller = applicationLauncherListController.applicationLauncherListComponentController;
            this.templateUrl = '/Application/components/applicationLauncher/applicationLauncher-list/applicationLauncher-list.html';
            this.controllerAs = "applicationLauncherListVm";
        }
    }

    angular.module('SPApp').component('applicationLauncherListComponent', new applicationLauncherListComponent());
}