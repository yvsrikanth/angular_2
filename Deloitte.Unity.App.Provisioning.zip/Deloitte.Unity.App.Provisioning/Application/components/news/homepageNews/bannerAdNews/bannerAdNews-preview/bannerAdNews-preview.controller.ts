﻿module app.bannerAdNewsPreviewController {

    export class bannerAdNewsPreviewComponentController {

        static $inject = ["$scope", "$rootScope", "$routeParams", "newsService", "$location", "alertService", "securityService"];

        id: string;
        firm: string;
        edit: boolean;
        bannerAdNewsItem: any[];
        selectedItem: any;
        showTitle: boolean;
        resourceTitle: string;
        buttonText: string;
        userPermissions: security.shared.IModulePermissions;

        constructor(private $scope, private $rootScope, private $routeParams, private newsService: services.newsService, private $location, private alertService: components.alert.alertService,
            private securityService: security.shared.securityService) {

        }

        $onInit() {

            this.setParams();
            this.bannerAdNewsItem = [];
            for (var itemIndex = 0; itemIndex < 6; itemIndex++) {
                this.bannerAdNewsItem.push(components.news.genericNewsCreateEditController.getEmptyItem(itemIndex + 1, this.firm, "BannerAd"));
            }
            this.getDetailsBannerAdNewsItem();

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions[this.firm];
            });

        }

        moreThanOneWithId(news: components.news.INewsArticleResult[]) {
            var idCounter = 0;

            for (var i = 0; i < news.length; i++) {
                if (news[i].id) {
                    idCounter++;
                }
            }

            return idCounter !== 1;
        }

        setParams() {

            if (angular.isDefined(this.$routeParams.id)) {
                this.id = this.$routeParams.id;
                this.resourceTitle = "Banner ad preview";
                this.buttonText = "Edit news";
            }

            if (angular.isDefined(this.$routeParams.firm)) {
                this.firm = this.$routeParams.firm;
                this.resourceTitle = "Banner ad layout preview";
                this.buttonText = "Edit layout";
            }
        }

        setItemsOnPositions(items: components.news.INewsArticleData[]) {
            components.news.genericNewsCreateEditController.setItemsOnPositions(items, this.bannerAdNewsItem);
        }

        getDetailsBannerAdNewsItem() {

            if (!angular.isDefined(this.id) && !angular.isDefined(this.firm)) {
                this.redirectToHome("Params can't be identified");
            }


            if (angular.isDefined(this.firm)) {
                this.requestAllBannerAdNewsData();
                return;
            }

            if (angular.isDefined(this.id)) {
                this.requestBannerAdNewsItem();
                return;
            }

        }

        requestAllBannerAdNewsData() {

            var promise;
            promise = this.newsService.get({ firm: this.firm, region: "BannerAd", take: 6 }).then(result => {
                this.setItemsOnPositions(result.items);
            });

            promise.then(() => {
                this.setSelectedItem();
            });
        }

        requestBannerAdNewsItem() {

            if (sessionStorage.getItem("news-item")) {
                let data = angular.fromJson(sessionStorage.getItem("news-item"));
                this.setItemsOnPositions([data]);
                this.setSelectedItem();

            } else {
                var promise;
                promise = this.newsService.getById(this.id).then(item => {
                    this.setItemsOnPositions([item]);
                }, response => {
                    this.redirectToHome(response.statusText);
                    });

                promise.then(() => {
                    this.setSelectedItem();
                });
            }

        }

        setSelectedItem() {
            
            this.selectedItem = this.bannerAdNewsItem[0];
            if(!angular.isDefined(this.firm)) {this.firm = this.selectedItem.firm;}
            this.showTitle = this.bannerAdNewsItem.length > 1;
        }

        redirectToHome(msg) {
            this.alertService.show({
                buttons: app.components.alert.AlertButtons.Accept,
                title: "Error",
                message: msg,
                dismissText: "Ok"
            });

            this.$location.path("/news/homepageNews/bannerAdNews");
        }

    }
}