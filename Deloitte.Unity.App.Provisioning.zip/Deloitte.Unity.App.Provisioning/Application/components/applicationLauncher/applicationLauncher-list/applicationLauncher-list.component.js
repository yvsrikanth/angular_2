var app;
(function (app) {
    var directives;
    (function (directives) {
        var applicationLauncherListComponent = (function () {
            function applicationLauncherListComponent() {
                this.bindings = {
                    firm: '='
                };
                this.controller = app.applicationLauncherListController.applicationLauncherListComponentController;
                this.templateUrl = '/Application/components/applicationLauncher/applicationLauncher-list/applicationLauncher-list.html';
                this.controllerAs = "applicationLauncherListVm";
            }
            return applicationLauncherListComponent;
        }());
        directives.applicationLauncherListComponent = applicationLauncherListComponent;
        angular.module('SPApp').component('applicationLauncherListComponent', new applicationLauncherListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=applicationLauncher-list.component.js.map