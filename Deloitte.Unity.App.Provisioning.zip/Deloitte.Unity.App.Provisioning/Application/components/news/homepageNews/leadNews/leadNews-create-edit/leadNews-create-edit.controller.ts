﻿module app.components.news.homepageNews.leadNews {
    export class leadNewsCreateEditController extends genericNewsCreateEditController {

        static $inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, "Edit lead news layout", "Edit lead news", "Create lead news", 4, "Carousal", "/news/homepageNews/leadNews");
        }

        onSave(invalid) {
            this.setItemsToPreview(this.items);
            if (!this.validateOrdinal(this.previewItems))
                return;
            this.save(this.previewItems, null, invalid);
            //Removed modal to maintain consistency
            //$("#previewConfirmModal").modal("show");
        }
    }
}