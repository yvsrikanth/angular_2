var app;
(function (app) {
    var hamburgerMenuWizardController;
    (function (hamburgerMenuWizardController) {
        var hamburgerMenuWizardComponentController = (function () {
            function hamburgerMenuWizardComponentController($location, $routeParams) {
                this.$location = $location;
                this.$routeParams = $routeParams;
                var self = this;
                self.currentLevel = self.$routeParams.level ? self.$routeParams.level : '1';
                self.currentRoute = self.$location.path().split('/')[2];
            }
            hamburgerMenuWizardComponentController.prototype.getUrl = function (level) {
                var self = this;
                if (!self.isPreview) {
                    return null;
                }
                return '#/hamburgerMenu/' + self.currentRoute + '/' + self.$routeParams.firm + '/' + self.$routeParams.code + '/' + level;
            };
            return hamburgerMenuWizardComponentController;
        }());
        hamburgerMenuWizardComponentController.$inject = ["$location", "$routeParams"];
        hamburgerMenuWizardController.hamburgerMenuWizardComponentController = hamburgerMenuWizardComponentController;
    })(hamburgerMenuWizardController = app.hamburgerMenuWizardController || (app.hamburgerMenuWizardController = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenuWizard.controller.js.map