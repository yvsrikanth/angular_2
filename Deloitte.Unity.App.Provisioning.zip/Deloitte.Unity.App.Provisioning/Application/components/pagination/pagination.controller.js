var app;
(function (app) {
    var components;
    (function (components) {
        var pagination;
        (function (pagination) {
            var paginationComponentController = (function () {
                function paginationComponentController() {
                }
                paginationComponentController.prototype.$onChanges = function (changes) {
                    this.currentPage = (this.skip / this.take) + 1;
                    this.lastPage = Math.ceil((this.totalCount || 1) / this.take);
                    if (this.currentPage > this.lastPage) {
                        this.skip = this.skip - this.take;
                        this.setPage(this.lastPage);
                    }
                    this.pages = this.buildPages(this.skip, this.take, this.totalCount);
                };
                paginationComponentController.prototype.setPage = function (page, force) {
                    if (force || this.currentPage !== page) {
                        var start = (page - 1) * this.take;
                        this.skip = start;
                        this.currentPage = page;
                        this.pages = this.buildPages(this.skip, this.take, this.totalCount);
                        this.doRequest();
                    }
                };
                paginationComponentController.prototype.onGoTo = function () {
                    //Should we need to ask to the user the page to go to?
                };
                paginationComponentController.prototype.onSelectPage = function (page) {
                    if (page) {
                        this.setPage(page);
                    }
                    else {
                        this.onGoTo();
                    }
                };
                paginationComponentController.prototype.onNextPage = function () {
                    if (this.currentPage !== this.lastPage) {
                        this.setPage(this.currentPage + 1);
                    }
                };
                paginationComponentController.prototype.onNextPrevious = function () {
                    if (this.currentPage !== 1) {
                        this.setPage(this.currentPage - 1);
                    }
                };
                paginationComponentController.prototype.isFirstPage = function () {
                    return this.isCurrentPage(1);
                };
                paginationComponentController.prototype.isLastPage = function () {
                    return this.isCurrentPage(this.lastPage);
                };
                paginationComponentController.prototype.isCurrentPage = function (page) {
                    return this.currentPage === page;
                };
                paginationComponentController.prototype.doRequest = function () {
                    this.onChangePage({
                        $event: {
                            skip: this.skip,
                            take: this.take
                        }
                    });
                };
                /**
                 * Builds and returns an array of page indexes from the specified parameters
                 * @param skip Number of items to skip
                 * @param take Number of items to take
                 * @param total Total number of items in the data store
                 */
                paginationComponentController.prototype.buildPages = function (skip, take, total) {
                    /*
                    var skip = 40, total = 121, take = 20;
                    var skip = 0, total = 121, take = 20;
                    /**/
                    var page = (skip / take) + 1;
                    var pages = Math.ceil(total / take);
                    var result = [];
                    if (pages > 7) {
                        result.push(1);
                        if (page < 5) {
                            for (var i = 2; i <= 5; i++) {
                                result.push(i);
                            }
                            result.push(0);
                        }
                        else if (page > pages - 4) {
                            result.push(0);
                            for (var i = pages - 4; i < pages; i++) {
                                result.push(i);
                            }
                        }
                        else {
                            result.push(0);
                            for (var i = page - 1; i <= page + 1; i++) {
                                result.push(i);
                            }
                            result.push(0);
                        }
                        result.push(pages);
                    }
                    else {
                        if (!pages) {
                            result.push(1);
                        }
                        else {
                            for (var i = 0; i < pages; i++) {
                                result.push(i + 1);
                            }
                        }
                    }
                    return result;
                };
                return paginationComponentController;
            }());
            paginationComponentController.$inject = [];
            pagination.paginationComponentController = paginationComponentController;
        })(pagination = components.pagination || (components.pagination = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=pagination.controller.js.map