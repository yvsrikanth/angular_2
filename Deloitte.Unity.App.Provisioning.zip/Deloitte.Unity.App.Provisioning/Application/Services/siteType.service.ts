﻿module app.services {
    export class siteTypeService {
        
        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings
        ) { }

        /**
         * Retrieve a list of site requests
         * @param options Request parameters
         */
        get(options?: IPaginatedQuery): ng.IPromise<IPaginatedResult<ISiteType>> {
            return this.$http
                .get(this.appSettings.apiUrl + "/siteTypes", { params: options || {} })
                .then(result => result.data);
        }
    }

    export interface ISiteType {
        description?: string;
        id?: string;
        siteType?: string;
        template?: string;
        additionalAdmin?: string[];
        isSearchable?: boolean;
    }

    function siteTypeServiceFactory($rootElement): siteTypeService {
        const inj = $rootElement.injector();
        return inj.instantiate(siteTypeService);
    }
    angular.module("SPApp").factory("siteTypeService", ["$rootElement", $rootElement => siteTypeServiceFactory($rootElement)]);
}
