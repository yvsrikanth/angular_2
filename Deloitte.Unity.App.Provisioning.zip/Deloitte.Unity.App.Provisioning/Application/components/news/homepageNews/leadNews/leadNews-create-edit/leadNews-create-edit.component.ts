﻿module app.components.news.homepageNews.leadNews {
    var leadNewsCreateEditComponent: ng.IComponentOptions = {

        bindings: {


        },
        controller: leadNewsCreateEditController,
        templateUrl: "/Application/components/news/homepageNews/leadNews/leadNews-create-edit/leadNews-create-edit.html",
        controllerAs: "leadNewsEditor"
    }

    angular.module("SPApp").component("leadNewsEditor", leadNewsCreateEditComponent);
}