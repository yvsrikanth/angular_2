﻿module app.services {

    export class unitySPService {

        static $inject = ["$http", "appSettings"];
        constructor(
            private $http: ng.IHttpService,
            private appSettings: IAppSettings
        ) { 
        }
        
        userData() {
            return this.$http
                .get(this.appSettings.apiUrl + "/user/users/rperla")
                .then(result => result.data);
        }
    }

    function SPServiceFactory($rootElement): unitySPService {
        const inj = $rootElement.injector();
        return inj.instantiate(unitySPService);
    }
    angular.module("SPApp").factory("unitySPService", ["$rootElement", $rootElement => SPServiceFactory($rootElement)]);
}
