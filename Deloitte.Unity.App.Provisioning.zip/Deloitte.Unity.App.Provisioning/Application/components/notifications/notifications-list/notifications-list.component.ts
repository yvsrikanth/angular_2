﻿namespace app.directives {
    export class notificationsListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: '=',
                actives: "="
            };
            this.controller = notificationsListComponentController.notificationsListComponentController;
            this.templateUrl =
                '/Application/components/notifications/notifications-list/notifications-list.html';
            this.controllerAs = "notificationsListCtrl";
        }
    }

    angular.module('SPApp').component('notificationsList', new notificationsListComponent());
}