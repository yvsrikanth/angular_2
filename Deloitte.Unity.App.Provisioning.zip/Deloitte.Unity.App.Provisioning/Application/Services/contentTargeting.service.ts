﻿﻿module app.services {

    export class contentTargetingService {
        static $inject = ["$http", "appSettings"];
        public firmItems: any;
        public selectedFirm: any;
        public selectedAudienceId: String;


        public firmId: "US";

        constructor(private $http: ng.IHttpService, private appSettings: IAppSettings) {
        }

        deleteAudience(data) {

            let id = data.id;
            delete data['id'];
            delete data['authorAttributes'];

            //console.log(config);
            return this.$http.delete(this.appSettings.apiUrl + "/audiences/" + id, data);
        }

        contentTargetingCreate(id, reData, isNew) {
            if (!isNew) {
                return this.$http.put(this.appSettings.apiUrl + "/audiences/" + id, reData);
            } else {
                return this.$http.post(this.appSettings.apiUrl + "/audiences/", reData);
            }
        }       
        
        getContentTarget(key, skip, take, sort?) { 
            var queryParams: any = { skip: skip, take: take, firms: key };
            if (sort) {
                queryParams.sort = sort;
            }                   
            return this.$http
                .get(this.appSettings.apiUrl + "/audiences", { params: queryParams })
                .then(result => {
                    var queryResult: any = result.data;

                    if (queryResult.items && queryResult.items.length) {
                        for (var i = 0; i < queryResult.items.length; i++) {
                            if (queryResult.items[i].modified)
                                queryResult.items[i].modified = new Date(queryResult.items[i].modified).toISOString();
                            if (queryResult.items[i].created)
                                queryResult.items[i].created = new Date(queryResult.items[i].created).toISOString();
                        }
                    }

                    return queryResult;
                });
        }

        getAudiencesData(key) {
            var queryParams = { key };
            return this.$http.get(this.appSettings.apiUrl + "/audiences", { params: queryParams }).then(result => result.data);
        }

        getAudiencesByKey(key) {
            return this.$http.get(this.appSettings.apiUrl + "/audiences/?firms=" + key).then(result => result.data);
        }

        getContentTargetById(id) {
            return this.$http.get(this.appSettings.apiUrl + "/audiences/" + id).then(result => result.data);
        }

        firmData() {
            if (localStorage.getItem("firmId") == null) {
                localStorage.setItem("firmId", "0a68db4d-994d-420a-afa5-0b6ed25a782b");
            }
            let firmId = localStorage.getItem("firmId");
            this.firmItems = this.$http.get(this.appSettings.apiUrl + "/firms/" + firmId).then(result => result.data);
        }

        memberFirmData() {
            return this.$http.get(this.appSettings.apiUrl + "/firms/").then(result => result.data);
        }

        getAttributesList() {
            return this.$http.get("/Application/components/contentTargeting/contentTargeting-create-edit/jsonData/attributesList.json").then(result => result.data);
        }

        setFirm(firm) {
            this.selectedFirm = firm;
        }

        getFirmName() {
            return this.selectedFirm;
        }

        setAudienceId(id) {
            this.selectedAudienceId = id;
        }

        getAudienceId() {
            return this.selectedAudienceId;
        }

        getSelectedAudiencesData(id) {
            return this.$http.get(this.appSettings.apiUrl + "/audiences/" + id).then(result => result.data);
        }

        updateSelectedAudiencesData(id, data) {
            return this.$http.put(this.appSettings.apiUrl + "/audiences/" + id, data).then(result => result.data);
        }

    }

    angular.module("SPApp").service("contentTargetingService", contentTargetingService);
}
