var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var thumbnailNews;
                (function (thumbnailNews) {
                    var expandedThumbnailNewsCreateEditComponent = {
                        bindings: {},
                        controller: thumbnailNews.expandedThumbnailNewsCreateEditController,
                        templateUrl: "/Application/components/news/expandedpageNews/thumbnailNews/thumbnailNews-create-edit/thumbnailNews-create-edit.html",
                        controllerAs: "leadNewsEditor"
                    };
                    angular.module("SPApp").component("expandedThumbnailNewsEditor", expandedThumbnailNewsCreateEditComponent);
                })(thumbnailNews = expandedpageNews.thumbnailNews || (expandedpageNews.thumbnailNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-create-edit.component.js.map