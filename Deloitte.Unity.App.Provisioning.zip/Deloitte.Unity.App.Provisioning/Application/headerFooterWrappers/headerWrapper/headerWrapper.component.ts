﻿module app.headerFooterWrappers.headerWrapper {

    export var headerWrapperComponent: ng.IComponentOptions =
        {
            templateUrl: "/Application/headerFooterWrappers/headerWrapper/headerWrapper.component.html",
            controller: headerFooterComponentController,
            controllerAs: "vm"
        };
}