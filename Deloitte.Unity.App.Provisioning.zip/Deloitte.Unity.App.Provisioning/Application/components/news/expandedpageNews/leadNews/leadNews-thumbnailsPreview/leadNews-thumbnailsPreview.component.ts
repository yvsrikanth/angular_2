﻿module app.components.news.expandedpageNews.leadNews {
    var leadNewsThumbnailsPreviewComponent: ng.IComponentOptions = {

        bindings: {
            news: "<",
            skipSort: "<"
        },
        controller: genericNewsLayoutPreviewController,
        templateUrl: "/Application/components/news/expandedpageNews/leadNews/leadNews-thumbnailsPreview/leadNews-thumbnailsPreview.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("expandedLeadNewsThumbnailsPreview", leadNewsThumbnailsPreviewComponent);
}