var app;
(function (app) {
    var directives;
    (function (directives) {
        var notificationCreateEditComponent = {
            bindings: {},
            controller: app.components.notificationCreateEditController.notificationCreateEditController,
            templateUrl: '/Application/components/notifications/notification-create-edit/notification-create-edit.html',
            controllerAs: "notificationCreateEditCtrl"
        };
        angular.module('SPApp').component('notificationCreateEdit', notificationCreateEditComponent);
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=notification-create-edit.component.js.map