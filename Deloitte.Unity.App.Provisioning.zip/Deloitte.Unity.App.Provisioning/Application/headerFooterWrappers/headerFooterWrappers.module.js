var app;
(function (app) {
    var headerFooterWrappers;
    (function (headerFooterWrappers) {
        angular
            .module("SPApp.headerFooter", [
            "headerFooterApp"
        ])
            .component("headerWrapper", headerFooterWrappers.headerWrapper.headerWrapperComponent)
            .component("footerWrapper", headerFooterWrappers.footerWrapper.footerWrapperComponent);
    })(headerFooterWrappers = app.headerFooterWrappers || (app.headerFooterWrappers = {}));
})(app || (app = {}));
//# sourceMappingURL=headerFooterWrappers.module.js.map