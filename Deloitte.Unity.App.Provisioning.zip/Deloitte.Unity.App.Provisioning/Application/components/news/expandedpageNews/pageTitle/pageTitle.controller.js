var app;
(function (app) {
    var pageTitleController;
    (function (pageTitleController) {
        var pageTitleComponentController = (function () {
            function pageTitleComponentController($scope, $rootScope, securityService) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.securityService = securityService;
            }
            pageTitleComponentController.prototype.$onInit = function () {
                var _this = this;
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions;
                    _this.firms = Object.keys(_this.userPermissions).sort();
                    ;
                });
            };
            return pageTitleComponentController;
        }());
        pageTitleComponentController.$inject = ['$scope', '$rootScope', 'securityService'];
        pageTitleController.pageTitleComponentController = pageTitleComponentController;
    })(pageTitleController = app.pageTitleController || (app.pageTitleController = {}));
})(app || (app = {}));
//# sourceMappingURL=pageTitle.controller.js.map