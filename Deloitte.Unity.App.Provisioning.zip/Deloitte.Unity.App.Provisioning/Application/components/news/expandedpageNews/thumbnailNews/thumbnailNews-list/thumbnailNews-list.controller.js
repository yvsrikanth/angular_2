var app;
(function (app) {
    var expandedThumbnailNewsListController;
    (function (expandedThumbnailNewsListController) {
        var thumbnailNewsListComponentController = (function () {
            function thumbnailNewsListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            thumbnailNewsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setMemberFirm();
                this.thumbnailNews();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
                this.setColumns();
            };
            thumbnailNewsListComponentController.prototype.thumbnailNews = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "Thumbnail-newstab", take: 14 }).then(function (result) {
                    _this.headlineNewsItems = result.items;
                });
            };
            thumbnailNewsListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            thumbnailNewsListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return thumbnailNewsListComponentController;
        }());
        thumbnailNewsListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        expandedThumbnailNewsListController.thumbnailNewsListComponentController = thumbnailNewsListComponentController;
    })(expandedThumbnailNewsListController = app.expandedThumbnailNewsListController || (app.expandedThumbnailNewsListController = {}));
})(app || (app = {}));
//# sourceMappingURL=thumbnailNews-list.controller.js.map