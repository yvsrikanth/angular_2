﻿module app.directives {
    export class contentTargetingListComponent implements ng.IComponentController {
        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                firm: '='
            };
            this.controller = contentTargetingListController.contentTargetingListComponentController;
            this
                .templateUrl =
                '/Application/components/contentTargeting/contentTargeting-list/contentTargeting-list.html';
            this.controllerAs = "contentTargetingList";
        }
    }

    angular.module('SPApp').component('contentTargetingListComponent', new contentTargetingListComponent());
}