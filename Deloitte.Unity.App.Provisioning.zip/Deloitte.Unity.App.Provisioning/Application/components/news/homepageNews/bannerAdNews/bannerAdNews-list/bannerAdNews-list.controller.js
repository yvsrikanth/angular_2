var app;
(function (app) {
    var bannerAdNewsListController;
    (function (bannerAdNewsListController) {
        var bannerAdNewsListComponentController = (function () {
            function bannerAdNewsListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            bannerAdNewsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setColumns();
                this.setMemberFirm();
                this.bannerAdNews();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            bannerAdNewsListComponentController.prototype.bannerAdNews = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "BannerAd", take: 6 }).then(function (result) {
                    _this.bannerAdItems = result.items;
                });
            };
            bannerAdNewsListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            bannerAdNewsListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return bannerAdNewsListComponentController;
        }());
        bannerAdNewsListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        bannerAdNewsListController.bannerAdNewsListComponentController = bannerAdNewsListComponentController;
    })(bannerAdNewsListController = app.bannerAdNewsListController || (app.bannerAdNewsListController = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-list.controller.js.map