﻿module app.directives {

    class headlineNewsComponent implements ng.IComponentOptions {

        public bindings: any;
        public controller: any;
        public templateUrl: string;
        public controllerAs: string;

        constructor() {
            this.bindings = {
                headlineNewsItem: '@'
            };
            this.controller = headlineNewsController.headlineNewsComponentController;
            this.templateUrl = '/Application/components/news/homepageNews/headlineNews/headlineNews.html';
            this.controllerAs = "headlineNews";
        }
    }

    angular.module('SPApp').component('headlineNews', new headlineNewsComponent());

}