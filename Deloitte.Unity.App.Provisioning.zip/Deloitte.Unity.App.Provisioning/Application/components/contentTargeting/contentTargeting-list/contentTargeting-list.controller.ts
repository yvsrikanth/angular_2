﻿module app.contentTargetingListController {


    export class contentTargetingListComponentController {

        static $inject = ['$scope', '$rootScope', 'contentTargetingService', 'securityService', '$attrs', 'alertService', 'userAttributesService', 'userService'];
        contentTargetItem: any[];
        firm: any;
        attributesData: any;
        displayTitle: String;
        itemsPerPage: Number;
        query: any;
        totalCount: any;
        memberFirm: String;
        dateForToday: any;
        authors: any;
        userPermissions: security.shared.IFirmPermissions;
        currentPage: Number;
        sortCol: string = "DisplayName";
        asc: boolean = true;
        allAttributes: any[];
        listAuthors: any[];

        constructor(
            private $scope,
            private $rootScope,
            private contentTargetingService: services.contentTargetingService,
            private securityService: security.shared.securityService,
            private $routeParams,
            private alertService: components.alert.alertService,
            private userAttributesService: services.userAttributesService,
            private userService: services.userService
        ) { }

        $onInit() {

            this.itemsPerPage = 8;
            this.query = {
                skip: 0, take: this.itemsPerPage
            };
            this.fetchAttributes();
            this.contentTarget(0, this.itemsPerPage);

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
            });
        }

        sort(col: string) {
            if (col === this.sortCol) {
                this.asc = !this.asc;
            } else {
                this.sortCol = col;
                this.asc = true;
            }
            this.contentTarget(this.currentPage, this.itemsPerPage);
        }

        getSortExpression() {
            return (this.asc ? '' : '-') + this.sortCol;
        }

        fetchAttributes() {
            this.userAttributesService.get()
                .then(allAttributes => {
                    this.allAttributes = allAttributes.items;
                });
        }

        contentTarget(skip, take) {
            let self = this;
            var rightNow = new Date();
            this.currentPage = skip;
            self.dateForToday = rightNow.toISOString().slice(0, 10);

            this.listAuthors = null;
            self.contentTargetingService.getContentTarget(this.firm, skip, take, this.getSortExpression()).then((data: any) => {

                self.contentTargetItem = data.items;
                self.totalCount = data.totalCount;

                for (let i = 0; i < this.contentTargetItem.length; i++) {
                    this.contentTargetItem[i].created =
                        new Date(this.contentTargetItem[i].created).toISOString().slice(0, 10);
                }

                self.contentTargetingService.memberFirmData().then((memberData: any) => {
                    angular.forEach(memberData.items, memberFirmValue => {
                        angular.forEach(data.items, value1 => {
                            if (value1.firm === memberFirmValue.key) {
                                value1.firm = memberFirmValue.name;
                            }
                        });
                    });
                });

                var ids = this.contentTargetItem
                    .filter(item => item.modifiedBy && item.modifiedBy.toUpperCase() !== "SYSTEM" && item.modifiedBy.toUpperCase() !== "JOBS")
                    .map(i => <string>i.modifiedBy)
                    .filter((v, i, a) => a.indexOf(v) === i);
                this.getAuthors(ids);
            });
        }

        getAttrName(id: string) {
            if (this.allAttributes) {
                if (this.allAttributes.length) {
                    var match = this.allAttributes.filter(a => a.id === id)[0];
                    if (match)
                        return match.displayName;
                } 
            } else {
                return "";
            }
            return id;
        }

        getAttributeData(data) {
            this.attributesData = data.rules;
            this.displayTitle = data.displayName;
        }

        gotoCreateAudience(params) {
            if (params.firm) {
                this.contentTargetingService.setFirm(params.firm);
            }
            if (params.audienceID) {
                this.contentTargetingService.setAudienceId(params.audienceID);
            }
        }

        getAuthors(ids: string[]) {
            var idsStr = ids.join(",");
            this.userService
                .getUserList(idsStr)
                .then((data: any) => {
                    this.listAuthors = data.items;
                })
// ReSharper disable once UnusedParameter
                .catch(error => {
                    this.listAuthors = [];
                });
        }

        getAuthorName(id: string) {
            if (this.listAuthors) {
                if (this.listAuthors.length) {
                    var author = this.listAuthors.filter(a => a.id === id)[0];
                    if (author)
                        return author.attributes.name.first + " " + author.attributes.name.last;
                } 
            } else {
                return "";
            }

            return id;
        }

        deleteAttribute(data) {
            this.alertService.show({
                buttons: components.alert.AlertButtons.AcceptCancel,
                title: 'Delete an entry',
                message: 'The selected entry will be deleted. This action cannot be undone',
                dismissText: 'Cancel',
                confirmText: 'Delete',
                onConfirm: () => {
                    this.contentTargetingService.deleteAudience(data)
                        .then(() => {

                            this.contentTargetItem.splice(this.contentTargetItem.indexOf(data), 1);
                            this.contentTarget(this.currentPage, this.itemsPerPage);
                            this.alertService.close();

                        }, err => {

                            this.alertService.show({
                                buttons: app.components.alert.AlertButtons.Accept,
                                title: err.statusText !== "" ? err.statusText : "Server error",
                                message: err.data !== null ? err.data.message : "Server error",
                                dismissText: "Ok"
                            });
                        });
                }
            });
        }
    }
}