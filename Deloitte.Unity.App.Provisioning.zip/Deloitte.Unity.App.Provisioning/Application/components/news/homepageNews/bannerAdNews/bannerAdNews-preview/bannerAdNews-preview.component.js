var app;
(function (app) {
    var directives;
    (function (directives) {
        var bannerAdNewsPreviewComponent = (function () {
            function bannerAdNewsPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.bannerAdNewsPreviewController.bannerAdNewsPreviewComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-preview/bannerAdNews-preview.html";
                this.controllerAs = "bannerAdNewsPreview";
            }
            return bannerAdNewsPreviewComponent;
        }());
        angular.module("SPApp").component("bannerAdNewsPreview", new bannerAdNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-preview.component.js.map