var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedExternalResourcesPreviewComponent = (function () {
            function expandedExternalResourcesPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.expandedExternalResourcesPreviewController.externalResourcesPreviewComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/externalResources/externalResources-preview/externalResources-preview.html";
                this.controllerAs = "externalResourcesPreview";
            }
            return expandedExternalResourcesPreviewComponent;
        }());
        angular.module("SPApp").component("expandedExternalResourcesPreview", new expandedExternalResourcesPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-preview.component.js.map