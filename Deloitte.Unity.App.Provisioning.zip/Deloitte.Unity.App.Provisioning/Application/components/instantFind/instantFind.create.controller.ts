﻿module app.instantFindCreateComponentController {
    declare var $;
    export class instantFindCreateComponentController {
        static $inject = ['$filter', '$location', 'instantFindService', 'alertService', 'securityService'];
        public types: Array<string> = new Array<string>();
        public memberFirms: Array<string> = new Array<string>();
        private currentItem: any;
        private currentTag: string;
        private isSubmited: boolean = false;
        private userPermissions: any;
        private isCreating: boolean = false;

        constructor(private $filter, private $location,
            private instantFindService: services.instantFindService,
            private alertService: components.alert.alertService,
            private securityService: security.shared.securityService) {
            let self = this;
            var currentType = $location.path().split('/')[2].toLowerCase();

            self.securityService.getUserPermissions().then(function (data: any) {
                self.userPermissions = data;
                self.checkUserPermissions();
            });

            self.types = [this.$filter('translate')('Web application'),
                this.$filter('translate')('Mobile application')];

            this.currentItem = {
                data: {
                    subtext: ''
                },
                firm: currentType === 'ddt' ? 'US' : '',
                isUniversal: currentType === 'office',
                resultType: currentType,
                requestor: {
                    name: currentType === 'office' || currentType === 'ddt' ? '-' : '',
                    email: currentType === 'office' || currentType === 'ddt' ? '-' : ''
                },
                isInstantFind: true,
                tags: []
            }
            this.currentTag = '';
        }

        create(form) {
            let self = this;
            this.isSubmited = true;
            self.isCreating = true;

            if (form.$invalid || this.noCheckboxSelected()) {
                self.isCreating = false;
                return;
            }

            if (this.currentItem.isUniversal && this.currentItem.resultType !== 'office') {
                this.currentItem.firm = 'Universal';
            }

            if (this.currentItem.isUniversal || this.userPermissions[this.currentItem.firm.trim()].instantFind.create) {
                this.instantFindService.saveResultItem(this.currentItem).then(function () {
                    self.isCreating = false;
                    self.$location.path('/instantFind');
                }, function () {
                    self.isCreating = false;
                    self.showErrorOnSave();
                });
            } else {
                self.isCreating = false;
                this.alertService.show({
                    buttons: components.alert.AlertButtons.Accept,
                    title: 'Action not allowed',
                    message: 'You do not have permissions to perform this action on '
                        + this.currentItem.firm + ' member firm.',
                    dismissText: 'Ok',
                    onDismiss: () => {
                        this.alertService.close();
                    }
                });
            }
        }

        checkUserPermissions() {
            var count = 0;

            for (var firm in this.userPermissions) {
                if (this.userPermissions[firm].instantFind.create) {
                    this.memberFirms.push(firm);
                    count++;
                }
            }

            if (count === 0) {
                this.alertService.show({
                    buttons: components.alert.AlertButtons.Accept,
                    title: 'Action not allowed',
                    message: 'You do not have permissions to perform this action.',
                    dismissText: 'Ok',
                    onDismiss: () => {
                        this.alertService.close();
                        this.$location.path('/instantFind');
                    }
                });
            }
        }

        cancel() {
            this.$location.path('/instantFind');
        }

        showErrorOnSave() {
            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: 'Error',
                message: 'An error has occurred. Please try again.',
                dismissText: 'Ok',
                onDismiss: () => {
                    this.alertService.close();
                }
            });
        }

        selectedUniversal() {
            if (this.currentItem.isUniversal) {
                this.currentItem.firm = '';
            }
        }

        shouldDisableTestLink() {
            return this.currentItem.data == undefined
                || this.currentItem.data.url == undefined
                || this.currentItem.data.url === '';
        }

        formatUrl() {
            if (this.shouldDisableTestLink()) {
                return;
            }

            if (this.currentItem.data.url.indexOf('http://') < 0
                && this.currentItem.data.url.indexOf('https://') < 0) {
                return 'http://' + this.currentItem.data.url;
            } else {
                return this.currentItem.data.url;
            }
        }

        isEmptyTag() {
            return this.currentTag === '';
        }

        addTag() {
            if (this.currentItem.tags.indexOf(this.currentTag) < 0) {
                this.currentItem.tags.push(this.currentTag);
            }
            this.currentTag = '';
        }

        removeTag(index: number) {
            this.currentItem.tags.splice(index, 1);
        }

        hasError(field) {
            return field.$error.required && this.isSubmited;
        }

        shouldDisableSubmitButton(form) {
            if (this.isCreating) {
                return true;
            }

            if (this.currentItem.resultType === 'application'
                || this.currentItem.resultType === 'page') {
                return this.isSubmited && (form.$invalid || this.noCheckboxSelected());
            }

            return form.$invalid && this.isSubmited;
        }

        noCheckboxSelected() {
            if (this.currentItem.resultType !== 'application'
                && this.currentItem.resultType !== 'page') {
                return false;
            }

            return this.isSubmited &&
                (!this.currentItem.isInstantFind && !this.currentItem.isFrequentLink);
        }
    }
};