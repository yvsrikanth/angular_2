var app;
(function (app) {
    var directives;
    (function (directives) {
        var bannerAdNewsListComponent = (function () {
            function bannerAdNewsListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.bannerAdNewsListController.bannerAdNewsListComponentController;
                this.templateUrl = "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-list/bannerAdNews-list.component.html";
                this.controllerAs = "bannerAdNewsList";
            }
            return bannerAdNewsListComponent;
        }());
        directives.bannerAdNewsListComponent = bannerAdNewsListComponent;
        angular.module("SPApp").component("bannerAdNewsList", new bannerAdNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=bannerAdNews-list.component.js.map