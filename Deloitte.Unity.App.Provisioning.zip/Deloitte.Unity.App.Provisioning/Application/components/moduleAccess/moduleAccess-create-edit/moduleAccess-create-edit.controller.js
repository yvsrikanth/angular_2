var app;
(function (app) {
    var moduleAccessCreateEditController;
    (function (moduleAccessCreateEditController) {
        var moduleAccessCreateEditComponentController = (function () {
            function moduleAccessCreateEditComponentController(moduleAccessService, securityService, $routeParams, alertService, $location, adGraphService) {
                this.moduleAccessService = moduleAccessService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
                this.alertService = alertService;
                this.$location = $location;
                this.adGraphService = adGraphService;
                this.modelUserPermissions = {};
                this.isSubmited = false;
            }
            moduleAccessCreateEditComponentController.prototype.$onInit = function () {
                var _this = this;
                this.moduleAccessItem = {};
                this.setMemberFirm();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                    _this.initModelPermissions();
                });
            };
            moduleAccessCreateEditComponentController.prototype.countSelecteds = function (group, countDisabled) {
                var trues = 0;
                if (group.create)
                    trues++;
                if (group.delete)
                    trues++;
                if (group.read)
                    trues++;
                if (group.update)
                    trues++;
                if (countDisabled && group.disable)
                    trues++;
                return trues;
            };
            moduleAccessCreateEditComponentController.prototype.anySelected = function (group, countDisabled) {
                return this.countSelecteds(group, countDisabled) > 0;
            };
            moduleAccessCreateEditComponentController.prototype.allSelected = function (group, countDisabled) {
                return this.countSelecteds(group, countDisabled) === (countDisabled ? 5 : 4);
            };
            moduleAccessCreateEditComponentController.prototype.initModelPermissions = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.setModuleAccessId();
                    this.getModuleAccessInfo();
                    this.isNew = false;
                }
                else {
                    this.initCreateUserPermissions();
                    this.isNew = true;
                }
            };
            moduleAccessCreateEditComponentController.prototype.initCreateUserPermissions = function () {
                for (var module in this.userPermissions) {
                    this.modelUserPermissions[module] =
                        {
                            create: false,
                            read: false,
                            update: false,
                            delete: false,
                            disable: false
                        };
                }
            };
            moduleAccessCreateEditComponentController.prototype.initEditUserPermissions = function () {
                if (!angular.isDefined(this.moduleAccessItem)) {
                    return;
                }
                for (var module in this.userPermissions) {
                    var create = this.moduleAccessItem.permissions.indexOf(module + "-create") !== -1;
                    var read = this.moduleAccessItem.permissions.indexOf(module + "-read") !== -1;
                    var update = this.moduleAccessItem.permissions.indexOf(module + "-update") !== -1;
                    var del = this.moduleAccessItem.permissions.indexOf(module + "-delete") !== -1;
                    var disable = this.moduleAccessItem.permissions.indexOf(module + "-disable") !== -1;
                    this.modelUserPermissions[module] =
                        {
                            create: create,
                            read: read,
                            update: update,
                            delete: del,
                            disable: disable
                        };
                }
            };
            moduleAccessCreateEditComponentController.prototype.getModuleAccessInfo = function () {
                var that = this;
                that.moduleAccessService.getModuleAccessItem(that.id).then(function (item) {
                    that.moduleAccessItem = item;
                    that.initEditUserPermissions();
                }, function (response) {
                    that.alertService.show({
                        buttons: app.components.alert.AlertButtons.Accept,
                        title: "Error",
                        message: response.statusText,
                        dismissText: "Ok"
                    });
                    that.$location.path("/moduleAccess");
                });
            };
            moduleAccessCreateEditComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm)) {
                    if (!angular.isDefined(this.firm)) {
                        this.firm = this.$routeParams.firm;
                    }
                    this.moduleAccessItem.firm = this.firm;
                }
            };
            moduleAccessCreateEditComponentController.prototype.setModuleAccessId = function () {
                if (angular.isDefined(this.$routeParams.id)) {
                    this.id = this.$routeParams.id;
                }
            };
            moduleAccessCreateEditComponentController.prototype.validateFormFields = function () {
                if (this.moduleAccessItem.firm === null || !angular.isDefined(this.moduleAccessItem.firm) || this.moduleAccessItem.firm === "") {
                    this.errorMessage = "The member firm is required";
                    return false;
                }
                if (this.moduleAccessItem.group === null || !angular.isDefined(this.moduleAccessItem.group) || this.moduleAccessItem.group === "") {
                    this.errorMessage = "The AD Group is required";
                    return false;
                }
                if (this.moduleAccessItem.displayName === null || !angular.isDefined(this.moduleAccessItem.displayName) || this.moduleAccessItem.displayName === "") {
                    this.errorMessage = "The Permission set name is required";
                    return false;
                }
                this.getListPermissions();
                if (this.moduleAccessItem.permissions.length <= 0) {
                    this.errorMessage = "At least one permission is required";
                    return false;
                }
                this.errorMessage = "";
                return true;
            };
            moduleAccessCreateEditComponentController.prototype.getListPermissions = function () {
                var listPermissions = [];
                angular.forEach(this.modelUserPermissions, function (permissions, module) {
                    angular.forEach(permissions, function (access, permission) {
                        if (access === true) {
                            listPermissions.push(module + "-" + permission);
                        }
                    });
                });
                this.moduleAccessItem.permissions = listPermissions;
            };
            moduleAccessCreateEditComponentController.prototype.isAdGroupValid = function () {
                return this.moduleAccessItem.group;
            };
            moduleAccessCreateEditComponentController.prototype.saveModuleAccess = function () {
                var _this = this;
                var that = this;
                that.isSubmited = true;
                if (!that.validateFormFields() || !this.isAdGroupValid()) {
                    that.isSubmited = false;
                    return;
                }
                that.moduleAccessService.createModuleAccess(this.moduleAccessItem, this.isNew).then(function () {
                    that.$location.path("/moduleAccess");
                }, function (response) {
                    that.isSubmited = false;
                    if (response.status === 400) {
                        _this.errorMessage = response.data.message;
                    }
                    else {
                        that.alertService.show({
                            buttons: app.components.alert.AlertButtons.Accept,
                            title: response.statusText !== "" ? response.statusText : 'Server error',
                            message: response.data !== null ? response.data.message : 'Server error',
                            dismissText: "Ok"
                        });
                    }
                });
            };
            moduleAccessCreateEditComponentController.prototype.checkAllModulesPermissions = function (module) {
                var check = angular.element("#box_all_" + module)[0]["checked"];
                this.modelUserPermissions[module] =
                    {
                        create: check,
                        read: check,
                        update: check,
                        delete: check,
                        disable: check
                    };
            };
            return moduleAccessCreateEditComponentController;
        }());
        moduleAccessCreateEditComponentController.$inject = ["moduleAccessService", "securityService", "$routeParams", "alertService", "$location", "adGraphService"];
        moduleAccessCreateEditController.moduleAccessCreateEditComponentController = moduleAccessCreateEditComponentController;
    })(moduleAccessCreateEditController = app.moduleAccessCreateEditController || (app.moduleAccessCreateEditController = {}));
})(app || (app = {}));
//# sourceMappingURL=moduleAccess-create-edit.controller.js.map