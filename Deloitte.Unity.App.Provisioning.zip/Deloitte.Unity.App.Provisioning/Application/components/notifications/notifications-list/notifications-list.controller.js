var app;
(function (app) {
    var notificationsListComponentController;
    (function (notificationsListComponentController_1) {
        var notificationsListComponentController = (function () {
            function notificationsListComponentController(newsService, securityService, $location, alertService) {
                this.newsService = newsService;
                this.securityService = securityService;
                this.$location = $location;
                this.alertService = alertService;
                this.permissionName = 'systemNotifications';
            }
            notificationsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.itemsPerPage = 8;
                this.getNotifications();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            notificationsListComponentController.prototype.getNotifications = function () {
                var _this = this;
                var self = this;
                self.newsService.getNewsByFirmAndRegion(self.firm, "homepage-notifications", 1000, 0)
                    .then(function (response) {
                    self.allNotificationItems = response.items
                        .filter(function (n) {
                        return n.firm === self.firm && n.isEnabled === self.actives;
                    })
                        .map(function (n) {
                        for (var property in n.items[0]) {
                            if (n.items[0].hasOwnProperty(property)) {
                                n[property] = n.items[0][property];
                            }
                        }
                        return n;
                    });
                    _this.query = {
                        skip: 0, take: _this.itemsPerPage
                    };
                    self.totalCount = self.allNotificationItems.length;
                    self.getNotificationItems(0, self.itemsPerPage);
                });
            };
            notificationsListComponentController.prototype.getNotificationItems = function (skip, take) {
                this.query = {
                    skip: skip, take: take
                };
                this.notificationItems = this.allNotificationItems.slice(skip, skip + take);
            };
            notificationsListComponentController.prototype.disable = function (item) {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: "Disable an entry ",
                    message: "The selected entry will be disabled.",
                    dismissText: "Cancel",
                    confirmText: "Disable",
                    onConfirm: function () {
                        _this.onConfirmDisable(item);
                        _this.alertService.close();
                    }
                });
            };
            notificationsListComponentController.prototype.onConfirmDisable = function (item) {
                var _this = this;
                item.isEnabled = false;
                this.newsService.put(item).then(function () {
                    _this.notificationItems.splice(_this.notificationItems.indexOf(item), 1);
                    _this.allNotificationItems.splice(_this.allNotificationItems.indexOf(item), 1);
                    _this.totalCount = _this.allNotificationItems.length;
                    _this.getNotificationItems(0, _this.itemsPerPage);
                });
            };
            notificationsListComponentController.prototype.delete = function (item) {
                var _this = this;
                this.alertService.show({
                    buttons: app.components.alert.AlertButtons.AcceptCancel,
                    title: "Delete an entry ",
                    message: "The selected entry will be deleted.",
                    dismissText: "Cancel",
                    confirmText: "Delete",
                    onConfirm: function () {
                        _this.onConfirmDelete(item);
                        _this.alertService.close();
                    }
                });
            };
            notificationsListComponentController.prototype.onConfirmDelete = function (item) {
                var _this = this;
                this.newsService.delete(item.id).then(function () {
                    _this.notificationItems.splice(_this.notificationItems.indexOf(item), 1);
                    _this.allNotificationItems.splice(_this.allNotificationItems.indexOf(item), 1);
                    _this.totalCount = _this.allNotificationItems.length;
                    _this.getNotificationItems(0, _this.itemsPerPage);
                });
            };
            return notificationsListComponentController;
        }());
        notificationsListComponentController.$inject = ['newsService', 'securityService', '$location', "alertService"];
        notificationsListComponentController_1.notificationsListComponentController = notificationsListComponentController;
    })(notificationsListComponentController = app.notificationsListComponentController || (app.notificationsListComponentController = {}));
})(app || (app = {}));
//# sourceMappingURL=notifications-list.controller.js.map