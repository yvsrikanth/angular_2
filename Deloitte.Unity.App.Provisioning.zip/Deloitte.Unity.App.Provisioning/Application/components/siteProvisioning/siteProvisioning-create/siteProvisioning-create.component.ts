﻿module app.components.siteProvisioning {
    var siteProvisioningCreateComponentOptions: ng.IComponentOptions = {
        bindings: {},
        controller: siteProvisioningCreateController,
        templateUrl: "/Application/components/siteProvisioning/siteProvisioning-create/siteProvisioning-create.component.html",
        controllerAs: "vm"
    };

    angular.module("SPApp").component("siteProvisioningCreate", siteProvisioningCreateComponentOptions);
}