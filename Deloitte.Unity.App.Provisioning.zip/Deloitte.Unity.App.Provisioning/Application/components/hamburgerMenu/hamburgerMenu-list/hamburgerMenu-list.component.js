var app;
(function (app) {
    var directives;
    (function (directives) {
        var hamburgerMenuListComponent = (function () {
            function hamburgerMenuListComponent() {
                this.bindings = {
                    firmKey: '@'
                };
                this.controller = app.hamburgerMenuListController.hamburgerMenuListComponentController;
                this.templateUrl =
                    '/Application/components/hamburgerMenu/hamburgerMenu-list/hamburgerMenu-list.html';
                this.controllerAs = "hamburgerMenuList";
            }
            return hamburgerMenuListComponent;
        }());
        directives.hamburgerMenuListComponent = hamburgerMenuListComponent;
        angular.module('SPApp').component('hamburgerMenuListComponent', new hamburgerMenuListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=hamburgerMenu-list.component.js.map