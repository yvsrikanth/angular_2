var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedHeadlineNewsPreviewComponent = (function () {
            function expandedHeadlineNewsPreviewComponent() {
                this.bindings = {
                    id: "<"
                };
                this.controller = app.expandedHeadlineNewsPreviewController.headlineNewsPreviewComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/headlineNews/headlineNews-preview/headlineNews-preview.html";
                this.controllerAs = "headlinePreview";
            }
            return expandedHeadlineNewsPreviewComponent;
        }());
        angular.module("SPApp").component("expandedHeadlineNewsPreview", new expandedHeadlineNewsPreviewComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=headlineNews-preview.component.js.map