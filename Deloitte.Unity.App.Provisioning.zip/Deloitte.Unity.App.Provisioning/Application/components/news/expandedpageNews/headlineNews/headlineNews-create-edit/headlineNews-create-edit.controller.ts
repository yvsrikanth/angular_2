﻿module app.components.news.expandedpageNews.headlineNews {
    export class expandedHeadlineNewsCreateEditController extends genericNewsCreateEditController {

        static $inject = ["rearrangeUtils","$anchorScroll","$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
        constructor(
            rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            $anchorScroll: (id: string) => void,
            $q: ng.IQService,
            $location: any,
            $routeParams: any,
            contentTargetingService: services.contentTargetingService,
            newsService: services.newsService,
            hamburgerMenuService: services.hamburgerMenuService,
            alertService: components.alert.alertService
        ) {
            super(
                // Injected dependencies
                rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService,
                /*pageTitleOnEditAll*/ "Edit headline news layout",
                /*pageTitleOnEditById*/ "Edit headline news",
                /*pageTitleOnCreate*/ "Create headline news",
                /*maxItems*/ 10,
                /*region*/ "headline",
                /*listPath*/ "/news/expandedpageNews/headlineNews");
        }
        
        onPreview() {
            super.onPreview();
            this.previewBlockName = this.blockName;
        }
    }
}