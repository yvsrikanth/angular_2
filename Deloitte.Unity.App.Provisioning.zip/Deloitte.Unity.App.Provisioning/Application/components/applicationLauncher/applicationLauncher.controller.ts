﻿module app.applicationLauncherController {


    export class applicationLauncherComponentController {
        static $inject = ['$scope', '$rootScope', '$http', '$compile', 'securityService'];
        public firms: any;
        public memberFirmName: String;
        public firm: any;
        public memberFirm: String;
        public firmsList: any;
        public whenOneItem: any;
        public userPermissions: any;
        public firmWithPermissions: any;

        http: ng.IHttpService;

        constructor(private $scope, private $rootScope, $http: ng.IHttpService, private $compile, private securityService: security.shared.securityService) {
            let self = this;
            self.http = $http;
            self.memberFirmName = "Select";
            self.whenOneItem = 1;
        }

        $onInit() {

            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firmWithPermissions = Object.keys(permissions).sort();
                this.firms = Object.keys(this.userPermissions).sort();

            });
        }

        getMemberFirmItemData(data) {
            this.memberFirmName = data.name;
        }

    }
}