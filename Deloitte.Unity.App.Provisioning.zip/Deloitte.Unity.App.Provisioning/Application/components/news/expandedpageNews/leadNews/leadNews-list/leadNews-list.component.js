var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedLeadNewsListComponent = (function () {
            function expandedLeadNewsListComponent() {
                this.bindings = {
                    firm: "<"
                };
                this.controller = app.expandedLeadNewsListController.leadNewsListComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews-list/leadNews-list.component.html";
                this.controllerAs = "leadNewsList";
            }
            return expandedLeadNewsListComponent;
        }());
        directives.expandedLeadNewsListComponent = expandedLeadNewsListComponent;
        angular.module("SPApp").component("expandedLeadNewsList", new expandedLeadNewsListComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-list.component.js.map