var app;
(function (app) {
    var leadBannerSpotListController;
    (function (leadBannerSpotListController) {
        var leadBannerSpotListComponentController = (function () {
            function leadBannerSpotListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            leadBannerSpotListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setColumns();
                this.setMemberFirm();
                this.leadBannerSpot();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
            };
            leadBannerSpotListComponentController.prototype.leadBannerSpot = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "hiddenNews", take: 8 }).then(function (result) {
                    _this.leadBannerSpotItems = result.items;
                });
            };
            leadBannerSpotListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            leadBannerSpotListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return leadBannerSpotListComponentController;
        }());
        leadBannerSpotListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        leadBannerSpotListController.leadBannerSpotListComponentController = leadBannerSpotListComponentController;
    })(leadBannerSpotListController = app.leadBannerSpotListController || (app.leadBannerSpotListController = {}));
})(app || (app = {}));
//# sourceMappingURL=leadBannerSpot-list.controller.js.map