﻿module app.components.news.homepageNews.bannerAdNews {
    var bannerAdNewsThumbnailsPreviewComponent: ng.IComponentOptions = {
        bindings: {
            news: "<",
            selectedNew: "=?",
            showAll: "<",
            skipSort: "<"
},
        controller: genericNewsLayoutPreviewController,
        templateUrl: "/Application/components/news/homepageNews/bannerAdNews/bannerAdNews-thumbnailsPreview/bannerAdNews-thumbnailsPreview.html",
        controllerAs: "vm"
    }

    angular.module("SPApp").component("bannerAdNewsThumbnailsPreview", bannerAdNewsThumbnailsPreviewComponent);
}