﻿module app.directives {
    export class paginationComponent implements ng.IComponentController {
        bindings: any;
        controller: any;
        templateUrl: string;
        controllerAs: string;

        constructor() {
            this.bindings = {
                skip: '<',
                take: '<',
                totalCount: '<',
                onChangePage: '&',
                showFirstLastButtons: '@'
            };
            this.controller = app.components.pagination.paginationComponentController;
            this.templateUrl = '/Application/components/pagination/pagination.component.html';
            this.controllerAs = 'pagination';
        }
    }
    angular.module('SPApp').component('paginationComponent', new paginationComponent());
}