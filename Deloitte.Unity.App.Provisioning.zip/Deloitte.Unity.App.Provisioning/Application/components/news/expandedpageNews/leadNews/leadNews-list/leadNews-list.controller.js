var app;
(function (app) {
    var expandedLeadNewsListController;
    (function (expandedLeadNewsListController) {
        var leadNewsListComponentController = (function () {
            function leadNewsListComponentController($scope, $rootScope, newsService, securityService, $routeParams) {
                this.$scope = $scope;
                this.$rootScope = $rootScope;
                this.newsService = newsService;
                this.securityService = securityService;
                this.$routeParams = $routeParams;
            }
            leadNewsListComponentController.prototype.$onInit = function () {
                var _this = this;
                this.setMemberFirm();
                this.leadsNew();
                this.securityService.getUserPermissions().then(function (permissions) {
                    _this.userPermissions = permissions[_this.firm];
                });
                this.setColumns();
            };
            leadNewsListComponentController.prototype.leadsNew = function () {
                var _this = this;
                this.newsService.get({ firm: this.firm, region: "Lead", take: 4 }).then(function (result) {
                    _this.leadNewsItems = result.items;
                });
            };
            leadNewsListComponentController.prototype.setColumns = function () {
                this.columns = ["News title", "Audience", "Author", "Updated date"];
            };
            leadNewsListComponentController.prototype.setMemberFirm = function () {
                if (angular.isDefined(this.$routeParams.firm) && !angular.isDefined(this.firm)) {
                    this.firm = this.$routeParams.firm;
                }
            };
            return leadNewsListComponentController;
        }());
        leadNewsListComponentController.$inject = ["$scope", "$rootScope", "newsService", "securityService", "$routeParams"];
        expandedLeadNewsListController.leadNewsListComponentController = leadNewsListComponentController;
    })(expandedLeadNewsListController = app.expandedLeadNewsListController || (app.expandedLeadNewsListController = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews-list.controller.js.map