﻿module app.components.hamburgerMenu {
    export interface ICategoryBase<T> {
        title?: string;
        code?: string;
        position?: number;
        items?: T[];
    }

    export interface ICategory extends ICategoryBase<ISubcategory> {
        groups?: string[];
    }

    export interface ISubcategory extends ICategoryBase<ISubcategory> {
        groups?: string[];
        url?: string;
    }
}