﻿module app.contentTargetingController {

    const operator = ["Less than", "Equal", "Greater than", "Not Equal"];

    export class contentTargetingComponentController {
        static $inject = ['$scope', '$rootScope', '$http', '$compile', 'securityService'];
        public firms: any;
        public memberFirmName: String;
        public userPermissions: security.shared.IFirmPermissions;
        public firm: any;
        public memberFirm: String;
        public firmWithPermissions: any;
        public whenOneItem: any;

        http: ng.IHttpService;

        constructor(private $scope, private $rootScope,
            $http: ng.IHttpService, private $compile, private securityService: security.shared.securityService) {
            let self = this;
            self.http = $http;
            self.memberFirmName = "Select"; 
            self.whenOneItem = 1;          
        }

        $onInit() {
            this.securityService.getUserPermissions().then(permissions => {
                this.userPermissions = permissions;
                this.firmWithPermissions = Object.keys(permissions).sort();
                
            });
        }
       
        getMemberFirmItemData(data) {
            this.memberFirmName = data.name;
        }

    }
}