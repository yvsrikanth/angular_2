﻿module app.components.news {
    export class genericNewsCreateEditController {

        previewedItemsJson: string;
        saving = false;
        haveBeenPreviewed = false;
        imgPreviewed = false;

        originalItems = new Array<INewsArticleData>();
        items = new Array<INewsArticleResult>();
        previewItems = new Array<INewsArticleData>();
        audiences = new Array();
        selectedPreviewItem: INewsArticleData;
        ordinals = new Array<number>();
        firm: string;
        blockName: string;
        previewBlockName: string;
        firmDataFromHamburgerMenu: any;
        isSubmited: boolean = false;
        loaded = false;
        validateFormField: boolean = false;
        livePositionChange: boolean = true;

        public regex: any = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

        onFetchItems() {

        }

        constructor(
            protected rearrangeUtils: itemsWithOrdinal.RearrangeUtils,
            protected $anchorScroll: (id: string) => void,
            protected $q: ng.IQService,
            protected $location: any,
            protected $routeParams: any,
            protected contentTargetingService: services.contentTargetingService,
            protected newsService: services.newsService,
            protected hamburgerMenuService: services.hamburgerMenuService,
            protected alertService: components.alert.alertService,
            protected pageTitleOnEditAll: string,
            protected pageTitleOnEditById: string,
            protected pageTitleOnCreate: string,
            protected maxItems: number,
            protected region: string,
            protected listPath: string
        ) {

        }

        $onInit() {
            this.firm = this.$routeParams.firm;
            for (var itemIndex = 0; itemIndex < this.maxItems; itemIndex++) {
                this.items.push(this.getEmptyItem(itemIndex + 1));
            }

            for (var i = 0; i < this.items.length; i++) {
                this.ordinals.push(i + 1);
            }

            this.setItemsToPreview(this.items);
            this.fetchAudiences();
            this.fetchItems(this.$routeParams.id);
            if (this.region === 'headline') {
                this.getBlockName();
            }
        }

        getPageTitle() {
            var id = this.$routeParams.id;
            if (id) {
                if (id.toLowerCase() === "all") {
                    return this.pageTitleOnEditAll;
                } else {
                    return this.pageTitleOnEditById;
                }
            } else {
                return this.pageTitleOnCreate;
            }
        }

        fetchAudiences() {
            this.contentTargetingService.getAudiencesData(this.firm)
                .then((response: any) => {
                    this.audiences = response.items;
                });
        }

        checkUrlFilter(s: any) {
            if (s) {
                if (!s.match(/^[a-zA-Z]+:\/\//)) {
                    s = 'http://' + s;
                }
                return s;
            }
        }

        getBlockName() {
            this.hamburgerMenuService
                .getFirmByKey(this.firm)
                .then((response: any) => {
                    if (response.items.length > 0) {
                        this.firmDataFromHamburgerMenu = response.items[0];
                        this.blockName = response.items[0].newsHeadlineTitle !== "*" ? response.items[0].newsHeadlineTitle : "";
                        this.previewBlockName = this.blockName;
                    } else {
                        this.firmDataFromHamburgerMenu = null;
                    }
                });
        }

        getEmptyItem(ordinal: number, id?: string) {
            return genericNewsCreateEditController.getEmptyItem(ordinal, this.firm, this.region, id);
        }

        static getEmptyItem(ordinal: number, firm: string, region: string, id?: string) {
            return <INewsArticleResult>{
                audiences: new Array<string>(),
                ordinal: null,
                items: [<INewsArticleDataItem>{ language: "0", content: "...", description: "..." }],
                firm: firm,
                region: region,
                layout: "Layout",
                id: id,
                isEnabled: true
            };
        }

        goToList() {
            this.$location.path(this.listPath).search({});
        }

        fetchItems(id?: string) {
            if (!id)
                id = "all";

            var promise;
            if (id.toLowerCase() === "all") {
                promise = this.newsService
                    .get({ firm: this.firm, region: this.region, take: this.maxItems, include: "image" })
                    .then(result => {
                        for (var index = 0; index < result.items.length; index++) {
                            var item = result.items[index];
                            this.items[item.ordinal - 1] = item;
                        }
                        return result.items;
                    });
            } else {
                promise = this.newsService
                    .getById(id, "image")
                    .then(item => {
                        this.items = [item];
                        return this.items;
                    });
            }

            promise.then(() => {
                this.originalItems = angular.copy(this.items);
                this.onFetchItems();
                this.setItemsToPreview(this.items);
                this.loaded = true;
                ////Potential placeholer-ngModel Fix
                //setTimeout(() => {
                //    for (var i = 0; i < this.items.length; i++) {
                //        angular.element(`#title${i+1}`).val(this.items[i].items[0].title);
                //        angular.element(`#subtitle${i+1}`).val(this.items[i].items[0].subtitle);
                //        angular.element(`#url${i+1}`).val(this.items[i].items[0].url);
                //        angular.element(`#thumbnail${i+1}`).val(this.items[i].items[0].thumbnailTitle);
                //    }
                //}, 100);
            });
        }

        onClear(item: INewsArticleResult) {
            var index = this.items.indexOf(item);
            this.items[index] = this.getEmptyItem(item.ordinal, item.id);
        }

        onPreview() {
            if ($('.error-message').length > 0) {
                return;
            }
            this.setItemsToPreview(this.items);
            this.haveBeenPreviewed = true;
            this.imgPreviewed = true;
        }

        onChangeImg() {
            this.imgPreviewed = false;
        }


        getAvaliableOrdinal(news: INewsArticleData[]): number {
            return genericNewsCreateEditController.getAvaliableOrdinal(news);
        }

        onPositionChanged(changed: INewsArticleResult) {
            if (this.livePositionChange)
                this.rearrangeUtils.rearrangeOrdinals(changed, this.items);
        }
        static setItemsOnPositions(items: components.news.INewsArticleData[], target: components.news.INewsArticleData[]) {
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                target[item.ordinal - 1] = item;
            }
        }

        static getAvaliableOrdinal(news: INewsArticleData[]): number {
            var ordinal = 1;
            while (true) {
                if (news.filter(n => n.ordinal === ordinal).length) {
                    ordinal++;
                } else {
                    return ordinal;
                }
            }
        }

        static processOrdinalSoring(items: INewsArticleData[]) {
            var previewItems = angular.copy(items);
            var ordinalsToClear = [];
            for (var i = 0; i < previewItems.length; i++) {
                if (!previewItems[i].ordinal) {
                    var ordinal = this.getAvaliableOrdinal(previewItems);
                    ordinalsToClear.push(ordinal);
                    previewItems[i].ordinal = ordinal;
                }
            }

            previewItems.sort((a, b) => a.ordinal - b.ordinal);

            for (var i = 0; i < ordinalsToClear.length; i++) {
                previewItems.filter(n => n.ordinal === ordinalsToClear[i])[0].ordinal = undefined;
            }

            return previewItems;
        }

        setItemsToPreview(items: INewsArticleData[]) {
            this.previewItems = genericNewsCreateEditController.processOrdinalSoring(items);


            this.previewedItemsJson = angular.toJson(items);
            let ordinalId;

            for (let i = 0; i < this.previewItems.length; i++) {
                var item = this.previewItems[i];
                var image = item["image"];
                var thumb = item["thumbnail"];

                if (image && image.data) {
                    item.items[0].image = image.data;
                }
                if (thumb && thumb.data) {
                    item.items[0].thumbnail = thumb.data;
                }

                delete item["image"];
                delete item["thumbnail"];
            }

            if (this.previewItems.length === 1) {
                ordinalId = this.previewItems[0].ordinal - 1;
                let previewItemsUpdatedList = [];
                for (let i = 0; i < this.maxItems; i++) {
                    if (i === ordinalId) {
                        previewItemsUpdatedList.push(this.previewItems[0]);
                    } else {
                        previewItemsUpdatedList.push({});
                    }
                }

                this.previewItems = previewItemsUpdatedList;
            }

            this.selectedPreviewItem = this.previewItems[0];
        }

        onSelectAudience(audience: any, item: INewsArticleData) {
            if (item.audiences.indexOf(audience.id) === -1) {
                item.audiences.push(audience.id);
            }
        }

        onRemoveAudience(id: any, item: INewsArticleData) {
            var audIndex = item.audiences.indexOf(id);
            if (audIndex !== -1) {
                item.audiences.splice(audIndex, 1);
            }
        }

        onClearImage(item: INewsArticleResult, index: number) {
            item["image"] = {};
            item.items[0].image = null;
            item.items[0].imageUrl = null;
        }

        onClearThumbnail(item: INewsArticleResult, index: number) {
            item["thumbnail"] = {};
            item.items[0].thumbnail = null;
            item.items[0].thumbnailUrl = null;
        }

        getImageText(item: INewsArticleData, img: any) {
            return img && img.name ? img.name : ((item ? item.items[0].imageUrl : null) || "");
        }

        getImageThumbnailText(item: INewsArticleData, img: any) {
            return img && img.name ? img.name : ((item ? item.items[0].thumbnailUrl : null) || "");
        }

        getAudienceName(id: any) {
            for (var i = 0; i < this.audiences.length; i++) {
                var aud = this.audiences[i];
                if (aud.id === id) {
                    return aud.displayName;
                }
            }
            return id;
        }

        countOrdinal(ordinal: number, items: INewsArticleData[]) {
            var counter = 0;
            for (var i = 0; i < items.length; i++) {
                if (items[i] && items[i].ordinal === ordinal)
                    counter++;
            }
            return counter;
        }

        validateOrdinal(items: INewsArticleData[]) {
            for (var index = 0; index < items.length; index++) {
                if (items[index].ordinal && this.countOrdinal(items[index].ordinal, items) !== 1) {
                    return false;
                }
            }
            return true;
        }

        onCancel() {
            this.goToList();
        }

        hasChangedOrIsNew(item: INewsArticleResult, originals: INewsArticleResult[]) {
            if (!item) {
                return false;
            }

            if (!item.id) { // Is New
                return true;
            }

            // Is not new, should be in the originals
            var match = originals.filter(n => n.id === item.id);
            if (!match.length) { // Is not in the originals (?). This is not going to happen in a common scenario
                return true;
            }

            // Return if changed or not
            return !angular.equals(match[0], item);
        }

        previewed() {
            var currentItemsJson = angular.toJson(this.items);
            var dataPreviewed = currentItemsJson === this.previewedItemsJson;

            return dataPreviewed && this.imgPreviewed;
        }

        positionsAreValid(items: INewsArticleData[]) {
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (this.isValidForPublishing(item, true)) {
                    if (!item.ordinal)
                        return false;
                }
            }
            return true;
        }

        save(checkPreviewChange, skipCheckPositions?: boolean, invalid?: boolean) {
            if (invalid) {
                this.$anchorScroll("mainView");
                return;
            }

            if (checkPreviewChange && !this.previewed()) {
                return;
            }

            if (!skipCheckPositions && !this.positionsAreValid(this.previewItems)) {
                this.$anchorScroll("mainView");
                return;
            }

            this.isSubmited = true;

            var promises = [];
            if (this.region === "headline" && this.firmDataFromHamburgerMenu != null) {
                this.firmDataFromHamburgerMenu.newsHeadlineTitle = this.blockName !== "" ? this.blockName : "*";
                this.hamburgerMenuService.saveFirm(this.firmDataFromHamburgerMenu);
            }

            let error: any = {};
            for (var index = 0; index < this.previewItems.length; index++) {
                var item = <INewsArticleResult>this.previewItems[index];
                item.ordinal = index + 1;
               
                //Identify items to delete
                if (item.id && !this.isValidForPublishing(item, true)) {
                    promises.push(this.newsService.delete(item.id));
                } else if (this.isValidForPublishing(item)) {
                    //Identify items to skip
                    if (this.hasChangedOrIsNew(item, this.originalItems)) {
                        promises.push(this.newsService.save(item, !item.id));
                    }

                }
            }
            this.saving = true;
            this.$q.all(promises).then(() => {
                $("body").removeClass("modal-open");
                this.saving = false;
                this.goToList();
            }, result => {
                this.saving = false;
                error = result;
            });

            if (error.hasOwnProperty("statusText")) {
                this.showError(error);
            }

        }

        showError(error) {

            this.alertService.show({
                buttons: components.alert.AlertButtons.Accept,
                title: error.statusText !== "" ? error.statusText : 'Server error',
                message: error.data !== null ? error.data.message : 'Server error',
                dismissText: "Ok"
            });
        }

        setImageDataToItem(item): ng.IPromise<INewsArticleResult> {
            const self = this;
            return self.$q(resolve => {
                var isDatasetThumbnail = false;
                var isDatasetImage = false;
                if (item.items[0].thumbnailUrl != null && item.items[0].thumbnail == null) {
                    const fileExtension = item.items[0].thumbnailUrl
                        .substr(item.items[0].thumbnailUrl.lastIndexOf('.') + 1);
                    this.toDataUrl(item.items[0].thumbnailUrl,
                        baseImage => {
                            item.items[0].thumbnail = baseImage;
                            isDatasetThumbnail = true;

                            if (isDatasetThumbnail && isDatasetImage) {
                                resolve(item);
                            }
                        },
                        'image/' + fileExtension);

                } else {
                    isDatasetThumbnail = true;
                }

                if (item.items[0].imageUrl != null && item.items[0].image == null) {
                    const fileExtension = item.items[0].imageUrl
                        .substr(item.items[0].imageUrl.lastIndexOf('.') + 1);
                    this.toDataUrl(item.items[0].imageUrl,
                        baseImage => {
                            item.items[0].image = baseImage;
                            isDatasetImage = true;
                            if (isDatasetThumbnail && isDatasetImage) {
                                resolve(item);
                            }
                        },
                        'image/' + fileExtension);
                } else {
                    isDatasetImage = true;
                }
                if (isDatasetThumbnail && isDatasetImage) {
                    resolve(item);
                }
            });

        }

        toDataUrl(src, callback, outputFormat) {
            var img = new Image();
            img.crossOrigin = 'Anonymous';
            img.src = src;
            var self = this;
            img.onload = function () {
                var canvas: any = document.createElement('CANVAS');
                var ctx = canvas.getContext('2d');
                ctx.drawImage(self, 0, 0);
                var dataUrl = canvas.toDataURL(outputFormat);
                callback(dataUrl);
            };
        }

        isValidForPublishing(item: INewsArticleResult, excludeId?: boolean) {
            return genericNewsCreateEditController.isValidForPublishing(item, excludeId);
        }

        static isValidForPublishing(item: INewsArticleResult, excludeId?: boolean) {
            if (!excludeId && item.id || (item.audiences && item.audiences.length))
                return true;

            var child = (item && item.items) ? item.items[0] : {};
            var childAttrs = 0;
            for (var attr in child) {
                if (child.hasOwnProperty(attr) && child[attr])
                    childAttrs++;
            }

            if (childAttrs > 3)
                return true;

            return false;
        }

    }
}