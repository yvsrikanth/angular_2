var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var app;
(function (app) {
    var components;
    (function (components) {
        var news;
        (function (news) {
            var expandedpageNews;
            (function (expandedpageNews) {
                var headlineNews;
                (function (headlineNews) {
                    var externalResourcesCreateEditController = (function (_super) {
                        __extends(externalResourcesCreateEditController, _super);
                        function externalResourcesCreateEditController(rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService) {
                            return _super.call(this, 
                            // Injected dependencies
                            rearrangeUtils, $anchorScroll, $q, $location, $routeParams, contentTargetingService, newsService, hamburgerMenuService, alertService, 
                            /*pageTitleOnEditAll*/ "Edit external resource layout", 
                            /*pageTitleOnEditById*/ "Edit external resource", 
                            /*pageTitleOnCreate*/ "Create external resource", 
                            /*maxItems*/ 3, 
                            /*region*/ "external-links", 
                            /*listPath*/ "/news/expandedpageNews/externalResources") || this;
                        }
                        externalResourcesCreateEditController.prototype.save = function (checkPreviewChange) {
                            if ($('.error-message').length > 0) {
                                this.$anchorScroll("mainView");
                                return;
                            }
                            this.setItemsToPreview(this.items);
                            _super.prototype.save.call(this, checkPreviewChange, true);
                        };
                        return externalResourcesCreateEditController;
                    }(news.genericNewsCreateEditController));
                    externalResourcesCreateEditController.$inject = ["rearrangeUtils", "$anchorScroll", "$q", "$location", "$routeParams", "contentTargetingService", "newsService", "hamburgerMenuService", "alertService"];
                    headlineNews.externalResourcesCreateEditController = externalResourcesCreateEditController;
                })(headlineNews = expandedpageNews.headlineNews || (expandedpageNews.headlineNews = {}));
            })(expandedpageNews = news.expandedpageNews || (news.expandedpageNews = {}));
        })(news = components.news || (components.news = {}));
    })(components = app.components || (app.components = {}));
})(app || (app = {}));
//# sourceMappingURL=externalResources-create-edit.controller.js.map