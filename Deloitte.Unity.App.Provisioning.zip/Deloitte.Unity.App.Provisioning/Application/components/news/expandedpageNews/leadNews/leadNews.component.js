var app;
(function (app) {
    var directives;
    (function (directives) {
        var expandedLeadNewsComponent = (function () {
            function expandedLeadNewsComponent() {
                this.controller = app.components.expandedLeadNews.leadNewsComponentController;
                this.templateUrl = "/Application/components/news/expandedpageNews/leadNews/leadNews.component.html";
                this.controllerAs = "leadNews";
            }
            return expandedLeadNewsComponent;
        }());
        angular.module("SPApp").component("expandedLeadNews", new expandedLeadNewsComponent());
    })(directives = app.directives || (app.directives = {}));
})(app || (app = {}));
//# sourceMappingURL=leadNews.component.js.map